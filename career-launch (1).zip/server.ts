import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

import { Student, Job, Internship, Notification, MockTest, PreparationTopic, ResumeData } from "./src/types";
import {
  INITIAL_JOBS,
  INITIAL_INTERNSHIPS,
  INITIAL_NOTIFICATIONS,
  INITIAL_MOCK_TESTS,
  INITIAL_PREP_TOPICS,
  MOCK_INTERVIEW_HR_QUESTIONS,
  MOCK_INTERVIEW_TECH_QUESTIONS
} from "./src/mockData";

const app = express();
const PORT = 3000;

app.use(express.json());

// Path for server-side persistence
const DATA_DIR = path.join(process.cwd(), "data");
const STORE_FILE = path.join(DATA_DIR, "store.json");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-Memory Database State
interface DBStore {
  students: Student[];
  jobs: Job[];
  internships: Internship[];
  notifications: Notification[];
  mockTests: MockTest[];
  prepTopics: PreparationTopic[];
  passwords: Record<string, string>; // userId -> password (stored simply for mock database simulation)
}

let dbState: DBStore = {
  students: [],
  jobs: INITIAL_JOBS,
  internships: INITIAL_INTERNSHIPS,
  notifications: INITIAL_NOTIFICATIONS,
  mockTests: INITIAL_MOCK_TESTS,
  prepTopics: INITIAL_PREP_TOPICS,
  passwords: {}
};

// Load existing state if available
if (fs.existsSync(STORE_FILE)) {
  try {
    const raw = fs.readFileSync(STORE_FILE, "utf-8");
    const parsed = JSON.parse(raw);
    dbState = { ...dbState, ...parsed };
    console.log("Database successfully loaded from server filesystem.");
  } catch (e) {
    console.error("Could not parse existing database store, starting fresh.", e);
  }
} else {
  // Preload a default student account for testing
  const defaultStudentId = "student-123";
  const defaultStudent: Student = {
    id: defaultStudentId,
    registerNo: "2022CS1001",
    name: "Akshaya Sri",
    email: "akshayasriharini@gmail.com",
    department: "Computer Science & Engineering",
    cgpa: 8.5,
    skills: ["React", "JavaScript", "Python", "Data Structures"],
    graduationYear: 2026,
    profileCompleted: 85,
    role: "student",
    savedJobs: [],
    jobApplications: [],
    internshipApplications: [],
    progress: { "apt-num": true, "tech-arr": false },
    quizScores: {
      "apt-num": { score: 2, total: 2, date: "2026-06-08" }
    },
    resume: {
      title: "Full Stack Engineer Resume",
      name: "Akshaya Sri",
      email: "akshayasriharini@gmail.com",
      phone: "+91 9876543210",
      linkedin: "linkedin.com/in/akshaya-sri",
      github: "github.com/akshaya-sri",
      location: "Chennai, India",
      summary: "Aspiring software developer with core background in modern MERN stacks, data layouts, and algorithmic reasoning.",
      skills: ["React.js", "Node.js", "Express", "TypeScript", "Python", "Tailwind CSS"],
      education: [
        {
          id: "edu-1",
          institution: "Vellore Institute of Technology",
          degree: "B.Tech",
          fieldOfStudy: "Computer Science and Engineering",
          startYear: "2022",
          endYear: "2026",
          grade: "8.5 CGPA"
        }
      ],
      experience: [
        {
          id: "exp-1",
          company: "TechSolutions Corp",
          role: "Web Intern",
          startDate: "Jan 2025",
          endDate: "May 2025",
          description: "Engineered high-performance client dashboards and modular custom state forms.",
          location: "Chennai",
          isRemote: true
        }
      ],
      projects: [
        {
          id: "proj-1",
          title: "CourseLink Dashboard",
          description: "Interactive administrative platform mapping registration progress structures.",
          technologies: ["React", "Tailwind CSS", "Firebase"]
        }
      ],
      certifications: ["AWS Certified Cloud Practitioner", "Google Advanced Analytics Certificate"]
    }
  };

  dbState.students.push(defaultStudent);
  dbState.passwords[defaultStudentId] = "password123"; // default password

  // Preload a default admin account
  const defaultAdminId = "admin-999";
  const defaultAdmin: Student = {
    id: defaultAdminId,
    registerNo: "ADMIN999",
    name: "Placement Coordinator (Admin)",
    email: "admin@careerlaunch.edu",
    department: "Placement Office",
    cgpa: 10.0,
    skills: ["Management"],
    graduationYear: 2026,
    profileCompleted: 100,
    role: "admin"
  };
  dbState.students.push(defaultAdmin);
  dbState.passwords[defaultAdminId] = "admin123";

  // Save the initialized state
  fs.writeFileSync(STORE_FILE, JSON.stringify(dbState, null, 2));
}

function saveDB() {
  try {
    fs.writeFileSync(STORE_FILE, JSON.stringify(dbState, null, 2));
  } catch (e) {
    console.error("Failed saving dbState filesystem transaction:", e);
  }
}

// Ensure Gemini Client behaves safely
let ai: GoogleGenAI | null = null;
const geminiKey = process.env.GEMINI_API_KEY;

if (geminiKey && geminiKey !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: geminiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });
    console.log("Gemini API initialized successfully.");
  } catch (error) {
    console.error("Error setting up Gemini Client:", error);
  }
} else {
  console.log("No custom Gemini API key specified. Using simulated AI engines.");
}

// API: Setup custom logging
console.log(`CareerLaunch server active in: ${process.env.NODE_ENV || "development"}`);

/* ================== AUTH MIDDLEWARE / HELPERS ================== */
const activeSessions: Record<string, Student> = {};

function resolveStudent(req: express.Request): Student | null {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return null;
  // In a real app we decode JWT. For mock server simplicity, the token is simply the student ID!
  return dbState.students.find(s => s.id === token) || activeSessions[token] || null;
}

/* ================== API ENDPOINTS ================== */

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", persistence: fs.existsSync(STORE_FILE), geminiReady: !!ai });
});

// Authentication: Register
app.post("/api/auth/register", (req, res) => {
  const { registerNo, name, email, department, graduationYear, password } = req.body;

  if (!registerNo || !name || !email || !password || !department) {
    return res.status(400).json({ error: "Please provide all required registration fields." });
  }

  // Check if register number or email already exists
  const exists = dbState.students.find(s => s.registerNo === registerNo || s.email === email);
  if (exists) {
    return res.status(400).json({ error: "Student with this Register Number or Email already exists." });
  }

  const newStudent: Student = {
    id: `student-${Date.now()}`,
    registerNo,
    name,
    email,
    department,
    cgpa: 0,
    skills: [],
    graduationYear: Number(graduationYear) || 2026,
    profileCompleted: 20, // 20% for initial registry
    role: "student",
    savedJobs: [],
    jobApplications: [],
    internshipApplications: [],
    progress: {},
    quizScores: {},
    resume: {
      title: `${name} Resume`,
      name,
      email,
      phone: "",
      location: "",
      summary: "",
      skills: [],
      education: [],
      experience: [],
      projects: [],
      certifications: []
    }
  };

  dbState.students.push(newStudent);
  dbState.passwords[newStudent.id] = password;
  saveDB();

  res.json({ status: "success", student: newStudent, token: newStudent.id });
});

// Authentication: Login
app.post("/api/auth/login", (req, res) => {
  const { registerNo, password } = req.body;

  if (!registerNo || !password) {
    return res.status(400).json({ error: "Register Number and Password are required." });
  }

  const student = dbState.students.find(s => s.registerNo === registerNo);
  if (!student) {
    return res.status(400).json({ error: "Invalid Register Number." });
  }

  const savedPassword = dbState.passwords[student.id];
  if (savedPassword !== password) {
    return res.status(400).json({ error: "Incorrect password." });
  }

  // Token is simply the student ID for fully-functional client session matching
  res.json({ token: student.id, student });
});

// Authentication: Forgot Password Reset Simulation
app.post("/api/auth/forgot-password", (req, res) => {
  const { registerNo, email, newPassword } = req.body;

  if (!registerNo || !email || !newPassword) {
    return res.status(400).json({ error: "All inputs are required." });
  }

  const student = dbState.students.find(s => s.registerNo === registerNo && s.email === email);
  if (!student) {
    return res.status(404).json({ error: "No matching student registration found with these credentials." });
  }

  dbState.passwords[student.id] = newPassword;
  saveDB();

  res.json({ status: "success", message: "Password updated successfully! You can now log in." });
});

// Student: Profile retrieval
app.get("/api/student/profile", (req, res) => {
  const student = resolveStudent(req);
  if (!student) {
    return res.status(401).json({ error: "Unauthorized session token." });
  }
  res.json({ student });
});

// Student: Profile update
app.put("/api/student/profile", (req, res) => {
  const current = resolveStudent(req);
  if (!current) {
    return res.status(401).json({ error: "Unauthorized session." });
  }

  const { cgpa, skills, graduationYear, name, email, department } = req.body;

  // Find in original array to patch
  const idx = dbState.students.findIndex(s => s.id === current.id);
  if (idx !== -1) {
    if (name) dbState.students[idx].name = name;
    if (email) dbState.students[idx].email = email;
    if (department) dbState.students[idx].department = department;
    if (cgpa !== undefined) dbState.students[idx].cgpa = Number(cgpa);
    if (skills !== undefined) dbState.students[idx].skills = skills;
    if (graduationYear !== undefined) dbState.students[idx].graduationYear = Number(graduationYear);

    // Dynamic completion rating calculate helper
    let completion = 20;
    if (dbState.students[idx].cgpa > 0) completion += 20;
    if (dbState.students[idx].skills?.length > 0) completion += 20;
    if (dbState.students[idx].resume?.summary) completion += 20;
    if (dbState.students[idx].resume?.projects?.length > 0) completion += 20;

    dbState.students[idx].profileCompleted = Math.min(100, completion);
    saveDB();
    res.json({ student: dbState.students[idx] });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

// Resume: Save resume details
app.post("/api/student/resume", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const resumeData: ResumeData = req.body;

  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    dbState.students[idx].resume = resumeData;

    // Recalculate profile completion
    let completion = 40;
    if (dbState.students[idx].cgpa > 0) completion += 20;
    if (resumeData.summary) completion += 10;
    if (resumeData.projects && resumeData.projects.length > 0) completion += 15;
    if (resumeData.education && resumeData.education.length > 0) completion += 15;

    dbState.students[idx].profileCompleted = Math.min(100, completion);

    saveDB();
    res.json({ success: true, resume: dbState.students[idx].resume, profileCompleted: dbState.students[idx].profileCompleted });
  } else {
    res.status(404).json({ error: "Student profile not found." });
  }
});

/* ================== JOBS & INTERNSHIPS ================== */

// Get Jobs
app.get("/api/jobs", (req, res) => {
  const student = resolveStudent(req);
  const responseJobs = dbState.jobs.map(j => {
    let applied = false;
    let saved = false;
    if (student) {
      applied = student.jobApplications?.includes(j.id) || false;
      saved = student.savedJobs?.includes(j.id) || false;
    }
    return { ...j, applied, saved };
  });
  res.json({ jobs: responseJobs });
});

// Apply to Job
app.post("/api/jobs/:id/apply", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized session." });

  const jobId = req.params.id;
  const job = dbState.jobs.find(j => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job posting not found." });

  // Eligibility check
  if (student.cgpa < job.eligibilityCgpa) {
    return res.status(400).json({
      error: `Application blocked. You possess ${student.cgpa} CGPA, whereas ${job.company} requires a minimum CGPA of ${job.eligibilityCgpa} for this drive.`
    });
  }

  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].jobApplications) {
      dbState.students[idx].jobApplications = [];
    }
    if (!dbState.students[idx].jobApplications.includes(jobId)) {
      dbState.students[idx].jobApplications.push(jobId);
    }
    saveDB();
    res.json({ success: true, message: "Applied successfully!", student: dbState.students[idx] });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

// Toggle Save Job
app.post("/api/jobs/:id/save", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const jobId = req.params.id;
  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].savedJobs) {
      dbState.students[idx].savedJobs = [];
    }
    const sidx = dbState.students[idx].savedJobs.indexOf(jobId);
    if (sidx === -1) {
      dbState.students[idx].savedJobs.push(jobId);
    } else {
      dbState.students[idx].savedJobs.splice(sidx, 1);
    }
    saveDB();
    res.json({ success: true, savedJobs: dbState.students[idx].savedJobs });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

// Get Internships
app.get("/api/internships", (req, res) => {
  const student = resolveStudent(req);
  const responseInternships = dbState.internships.map(i => {
    let applied = false;
    if (student) {
      applied = student.internshipApplications?.includes(i.id) || false;
    }
    return { ...i, applied };
  });
  res.json({ internships: responseInternships });
});

// Apply to Internship
app.post("/api/internships/:id/apply", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const internId = req.params.id;
  const internship = dbState.internships.find(i => i.id === internId);
  if (!internship) return res.status(404).json({ error: "Internship not found." });

  // Eligibility check
  if (student.cgpa < internship.eligibilityCgpa) {
    return res.status(400).json({
      error: `Application blocked. Minimum CGPA required is ${internship.eligibilityCgpa}.`
    });
  }

  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].internshipApplications) {
      dbState.students[idx].internshipApplications = [];
    }
    if (!dbState.students[idx].internshipApplications.includes(internId)) {
      dbState.students[idx].internshipApplications.push(internId);
    }
    saveDB();
    res.json({ success: true, message: "Applied successfully!", student: dbState.students[idx] });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

/* ================== PREPARATION DRILLS ================== */

// Get Preparation Topics
app.get("/api/prep", (req, res) => {
  res.json({ topics: dbState.prepTopics });
});

// Update Prep Progress & Saved Quiz score
app.post("/api/prep/:id/toggle", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const topicId = req.params.id;
  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].progress) {
      dbState.students[idx].progress = {};
    }
    const currentStatus = dbState.students[idx].progress[topicId] || false;
    dbState.students[idx].progress[topicId] = !currentStatus;
    saveDB();
    res.json({ success: true, progress: dbState.students[idx].progress });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

// Submit Topic Quiz Score
app.post("/api/prep/:id/quiz", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const topicId = req.params.id;
  const { score, total } = req.body;

  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].quizScores) {
      dbState.students[idx].quizScores = {};
    }
    dbState.students[idx].quizScores[topicId] = {
      score: Number(score),
      total: Number(total),
      date: new Date().toISOString().split("T")[0]
    };

    // Auto mark as completed since they completed the quiz
    if (!dbState.students[idx].progress) {
      dbState.students[idx].progress = {};
    }
    dbState.students[idx].progress[topicId] = true;

    saveDB();
    res.json({ success: true, quizScores: dbState.students[idx].quizScores, progress: dbState.students[idx].progress });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

/* ================== MOCK TESTS ================== */

// Submit Mock Test Results
app.post("/api/mock-tests/:id/submit", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const testId = req.params.id;
  const { score, total } = req.body;

  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].quizScores) {
      dbState.students[idx].quizScores = {};
    }
    dbState.students[idx].quizScores[testId] = {
      score: Number(score),
      total: Number(total),
      date: new Date().toISOString().split("T")[0]
    };
    saveDB();
    res.json({ success: true, quizScores: dbState.students[idx].quizScores });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

// GET Notifications
app.get("/api/notifications", (req, res) => {
  res.json({ notifications: dbState.notifications });
});

// GET Preparation Topics (supporting /api/prep-topics as well)
app.get("/api/prep-topics", (req, res) => {
  res.json({ topics: dbState.prepTopics });
});

// GET Mock Tests
app.get("/api/mock-tests", (req, res) => {
  res.json({ mockTests: dbState.mockTests });
});

// GET Students ledger list (for non-admin and general loading)
app.get("/api/students", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });
  res.json({ students: dbState.students });
});

// POST Preparation topic completion / toggle alias endpoint
app.post("/api/prep/:id/complete", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const topicId = req.params.id;
  const { completed } = req.body;
  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].progress) {
      dbState.students[idx].progress = {};
    }
    const nextStatus = completed !== undefined ? !!completed : !(dbState.students[idx].progress[topicId] || false);
    dbState.students[idx].progress[topicId] = nextStatus;
    saveDB();
    res.json({ success: true, progress: dbState.students[idx].progress });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

// POST Topic Quiz Score alias endpoint
app.post("/api/prep/:id/quiz-score", (req, res) => {
  const student = resolveStudent(req);
  if (!student) return res.status(401).json({ error: "Unauthorized." });

  const topicId = req.params.id;
  const { score, total } = req.body;

  const idx = dbState.students.findIndex(s => s.id === student.id);
  if (idx !== -1) {
    if (!dbState.students[idx].quizScores) {
      dbState.students[idx].quizScores = {};
    }
    dbState.students[idx].quizScores[topicId] = {
      score: Number(score),
      total: Number(total),
      date: new Date().toISOString().split("T")[0]
    };

    if (!dbState.students[idx].progress) {
      dbState.students[idx].progress = {};
    }
    dbState.students[idx].progress[topicId] = true;

    saveDB();
    res.json({ success: true, quizScores: dbState.students[idx].quizScores, progress: dbState.students[idx].progress });
  } else {
    res.status(404).json({ error: "Student not found." });
  }
});

/* ================== AI PERSISTENCE FLOWS VIA GEMINI ================== */

// AI: Resume Analyzer
app.post("/api/ai/resume-analyzer", async (req, res) => {
  const { resume } = req.body;
  if (!resume) {
    return res.status(400).json({ error: "Resume payload required for AI analysis." });
  }

  const prompt = `You are an expert HR Manager and Technical Recruiter. Please analyze this college student resume:
  Name: ${resume.name}
  Summary: ${resume.summary}
  Skills: ${resume.skills?.join(", ")}
  Education: ${JSON.stringify(resume.education)}
  Experience: ${JSON.stringify(resume.experience)}
  Projects: ${JSON.stringify(resume.projects)}
  Certifications: ${resume.certifications?.join(", ")}

  Provide your assessment in RAW JSON strictly adhering to this schema:
  {
    "score": <number out of 100>,
    "strengths": ["list of key strengths"],
    "gaps": ["list of identified missing skill sets/details"],
    "formattingCorrections": ["specific improvements to wording or standard templates"],
    "matchingRoles": ["top 3 modern roles suitable for their profile"]
  }
  Do not return markdown wrappers or backticks. Return ONLY stringified JSON.`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json"
        }
      });
      const parsed = JSON.parse(response.text || "{}");
      return res.json(parsed);
    } catch (err) {
      console.error("Gemini Resume Analysis failed, using robust backup.", err);
    }
  }

  // Robust fallback logic
  const score = Math.min(95, 45 + (resume.skills?.length || 0) * 4 + (resume.projects?.length || 0) * 10 + (resume.experience?.length || 0) * 10);
  const parsedFallback = {
    score,
    strengths: [
      resume.summary ? "Has a dedicated professional summary." : "Understands basics of computer applications.",
      resume.skills?.length > 3 ? `Good initial stack containing: ${resume.skills?.slice(0, 3).join(", ")}` : "Demonstrates baseline programming awareness.",
      resume.projects?.length > 0 ? "Includes developer portfolio projects." : "Academic records are structured nicely."
    ],
    gaps: [
      resume.skills?.length < 8 ? "Missing deep specialization in cloud databases (PostgreSQL/MongoDB) or modern system engineering tools." : "Could expand on system architectural depth (OS, OSI model).",
      resume.summary?.length < 30 ? "Professional summary could be more outcome-oriented with metrics." : "Need stronger emphasis on quantitative achievements/metrics in project roles."
    ],
    formattingCorrections: [
      "Ensure action verbs are used extensively to detail technical experience tasks.",
      "Consider grouping technical stack into specific silos (Languages, Frameworks, Developer Tools) to assist applicant tracking databases."
    ],
    matchingRoles: [
      "Associate Web Developer (MERN)",
      "Technical Support Associate",
      "Systems Trainee Engineer"
    ]
  };
  res.json(parsedFallback);
});

// AI: Career Guidance
app.post("/api/ai/career-guidance", async (req, res) => {
  const { skills, cgpa, interests } = req.body;

  const prompt = `Suggest concrete career guidance pathways for a college student with:
  Skills: ${skills?.join(", ") || "None listed"}
  CGPA: ${cgpa || "0"}
  Interests: ${interests || "General Technology"}

  Provide your response in RAW JSON format:
  {
    "recommendedRoles": [{"role": "title", "reason": "why they fit", "demandLevel": "High/Medium/Low"}],
    "learningFocus": ["core technologies they should master in next 6 months"],
    "immediateAdvice": "A short, encouraging advice block."
  }`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });
      return res.json(JSON.parse(response.text || "{}"));
    } catch (e) {
      console.error("Gemini Guidance failed, utilizing local fallback.", e);
    }
  }

  // Backup heuristic model
  res.json({
    recommendedRoles: [
      {
        role: skills?.includes("React") ? "Full-Stack React Engineer" : "Software Trainee Trainee",
        reason: "Matches your background and interest in web paradigms.",
        demandLevel: "High"
      },
      {
        role: "DevOps Associate",
        reason: "Excellent expansion to coordinate infrastructure deployments easily.",
        demandLevel: "Medium"
      }
    ],
    learningFocus: [
      "Advance your current JS/Programming algorithms up to dynamic optimizations.",
      "Get hands-on exposure to cloud computing (AWS/Docker)."
    ],
    immediateAdvice: `With a solid CGPA of ${cgpa || "8.0"}, you are in a great position to cross-apply for elite placements. Focus heavily on DSA and clean responsive coding!`
  });
});

// AI: Skill Gap Analyzer
app.post("/api/ai/skill-gap", async (req, res) => {
  const { userSkills, targetCompany, targetRole } = req.body;

  const prompt = `Analyze the placement skill gaps between:
  Student Skills: ${userSkills?.join(", ")}
  Target Employer: ${targetCompany}
  Target Position: ${targetRole}

  Produce a rigorous, helpful audit in RAW JSON:
  {
    "matchingSkills": ["user skills matching target requirements"],
    "missingSkills": ["essential requirements currently absent/weak"],
    "actionSteps": ["course of action 1 with specific topics", "action 2", "action 3"],
    "estimatedPrepMonths": <number of months needed>
  }`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });
      return res.json(JSON.parse(response.text || "{}"));
    } catch (e) {
      console.error("Skill Gap Gemini check errover:", e);
    }
  }

  // Local fallback
  res.json({
    matchingSkills: userSkills ? userSkills.slice(0, 3) : [],
    missingSkills: ["System Design", "Cloud Databases", "Advanced Algorithmic optimizations", "Unit Testing models"],
    actionSteps: [
      `Deep dive into ${targetCompany || "partner company"} specialized stacks including transactional index patterns.`,
      "Resolve practice problems on Trees, Priority Heaps, and Dynamic Programming.",
      "Contribute to open source projects mapping basic web endpoints."
    ],
    estimatedPrepMonths: 3
  });
});

// AI: Study Planner
app.post("/api/ai/study-planner", async (req, res) => {
  const { weakTopics, daysToPlacement } = req.body;

  const prompt = `As a college preparation coach, construct a structured weekly calendar for a student with ${daysToPlacement || 30} days remaining until placement drives start.
  Weak Areas to target: ${weakTopics || "General Aptitude and Technical DSA"}

  Return JSON strictly:
  {
    "weeks": [
      {
        "weekNumber": 1,
        "focusTopic": "Main header focus",
        "dailySchedule": [
          {"day": "Day Name", "activities": "activities explanation"}
        ]
      }
    ]
  }`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });
      return res.json(JSON.parse(response.text || "{}"));
    } catch (e) {
      console.error("Gemini Study Planner failed:", e);
    }
  }

  // Heuristic Planner
  res.json({
    weeks: [
      {
        weekNumber: 1,
        focusTopic: `Targeting: ${weakTopics || "Quantitative Aptitude & Technical Algorithms"}`,
        dailySchedule: [
          { day: "Monday", activities: "Revise theory, practice basic questions mapping core quantitative parameters." },
          { day: "Tuesday", activities: "Write custom tests focusing on speed optimizations." },
          { day: "Wednesday", activities: "Study Technical OOPS concepts, encapsulation, and class relationships." },
          { day: "Thursday", activities: "Review previous quiz mistakes. Focus heavily on logical arrangement puzzles." },
          { day: "Friday", activities: "Solve 5 array-indexing problems on Leetcode or our platform." },
          { day: "Saturday", activities: "Conduct Mixed Mock Test to build exam threshold." },
          { day: "Sunday", activities: "Rest, organize notes, and review custom AI gap metrics." }
        ]
      }
    ]
  });
});

// AI: Interview Question Generator (Interactive Simulator)
app.post("/api/ai/interview-generator", async (req, res) => {
  const { role, category } = req.body;

  const prompt = `Generate a fresh, realistic mock interview question for a candidate applying to ${role || "Software Engineer"} in the '${category || "Technical"}' category.
  Include 1 main question, some context, and some evaluation criteria tips.

  Provide exact RAW JSON schema:
  {
    "questionId": "q-generated",
    "question": "The actual question text",
    "context": "Context or business problem background",
    "tips": "What recruiters look for in the candidate's response"
  }`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });
      return res.json(JSON.parse(response.text || "{}"));
    } catch (e) {
      console.error("Gemini Mock Interview failed, using localized mock.", e);
    }
  }

  // Localized generation
  if (category === "HR") {
    res.json({
      questionId: "q-gen-hr",
      question: "Describe a situation where you had a disagreement with a project teammate. How did you resolve it?",
      context: "Conflict resolution is crucial in collaborative developmental team setups.",
      tips: "Use the STAR method (Situation, Task, Action, Result). Highlight active empathy, objective reasoning, and constructive output."
    });
  } else if (category === "Behavioral") {
    res.json({
      questionId: "q-gen-beh",
      question: "Tell me about a time you had to meet a major coding deadline but faced unexpected bugs. How did you coordinate your priorities?",
      context: "Tests task management, critical thinking, and composure under pressure.",
      tips: "Recruiters look for analytical troubleshooting, risk-assessment, transparent communication, and efficient task triage hierarchies."
    });
  } else {
    res.json({
      questionId: "q-gen-tech",
      question: "How would you design a rate limiter middleware for a high-traffic API? What data structure and algorithm would you deploy?",
      context: "System architecture and low-level algorithms for scalability.",
      tips: "Address efficiency: discuss Token Bucket or Leaky Bucket algorithms, Redis or in-memory map storages, and O(1) transaction complexity thresholds."
    });
  }
});

// AI: Interview Answer Reviewer
app.post("/api/ai/interview-review", async (req, res) => {
  const { question, answer } = req.body;

  const prompt = `Review this candidate's mock interview response:
  Question: ${question}
  Answer: ${answer}

  Evaluate objectively and structure output in RAW JSON format:
  {
    "rating": <number out of 10>,
    "feedback": "constructive professional feedback summarizing strengths and weaknesses",
    "betterAlternative": "suggested optimized response wording"
  }`;

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: { responseMimeType: "application/json" }
      });
      return res.json(JSON.parse(response.text || "{}"));
    } catch (e) {
      console.error("Gemini Interview Reviewer failed", e);
    }
  }

  const matchesCount = answer?.toLowerCase().split(" ").filter((w: string) => ["i", "we", "then", "resolved", "project", "code", "design"].includes(w)).length || 0;
  const rating = Math.min(9, Math.max(4, 5 + matchesCount));

  res.json({
    rating,
    feedback: "Your response maps baseline criteria successfully, but could emphasize specific action metrics or quantifiable outcomes.",
    betterAlternative: "I structured this logically by first evaluating the dependencies list, communicating with stakeholders, and implementing optimized key indices which reduced lag time by 30%."
  });
});

/* ================== ADMIN PANEL ENDPOINTS ================== */

// Admin: Get Student list
app.get("/api/admin/students", (req, res) => {
  const student = resolveStudent(req);
  if (!student || student.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Admin role required." });
  }
  res.json({ students: dbState.students });
});

// Admin: Add Job directly
const addJobHandler = (req: express.Request, res: express.Response) => {
  const student = resolveStudent(req);
  if (!student || student.role !== "admin") {
    return res.status(403).json({ error: "Admin role required." });
  }

  const { company, role, location, type, salary, deadline, description, requirements, eligibilityCgpa } = req.body;
  const newJob: Job = {
    id: `job-${Date.now()}`,
    company,
    role,
    location: location || "Bangalore",
    type: type || "In-Office",
    salary: salary || "₹12 LPA",
    deadline: deadline || new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    description: description || "Responsible for writing clean Express APIs.",
    requirements: Array.isArray(requirements) ? requirements : (requirements ? [requirements] : []),
    eligibilityCgpa: Number(eligibilityCgpa) || 6.0
  };
  dbState.jobs.unshift(newJob);
  saveDB();
  res.json({ success: true, message: "Job posting added successfully!" });
};

// Admin: Add Internship directly
const addInternshipHandler = (req: express.Request, res: express.Response) => {
  const student = resolveStudent(req);
  if (!student || student.role !== "admin") {
    return res.status(403).json({ error: "Admin role required." });
  }

  const { company, role, location, type, stipend, duration, deadline, description, requirements, eligibilityCgpa } = req.body;
  const newIntern: Internship = {
    id: `intern-${Date.now()}`,
    company,
    role,
    location: location || "Remote",
    type: type || "Remote",
    stipend: stipend || "₹45,000 / month",
    duration: duration || "3 Months",
    deadline: deadline || new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    description: description || "Exclusive engineering position.",
    requirements: Array.isArray(requirements) ? requirements : (requirements ? [requirements] : []),
    eligibilityCgpa: Number(eligibilityCgpa) || 6.0
  };
  dbState.internships.unshift(newIntern);
  saveDB();
  res.json({ success: true, message: "Internship posting added successfully!" });
};

// Admin: Create notification directly
const createNotificationHandler = (req: express.Request, res: express.Response) => {
  const student = resolveStudent(req);
  if (!student || student.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Admin role required." });
  }

  const { title, content, category, important } = req.body;
  const newNot: Notification = {
    id: `not-${Date.now()}`,
    title,
    content,
    category: category || "General",
    important: !!important,
    date: new Date().toISOString().split("T")[0]
  };

  dbState.notifications.unshift(newNot);
  saveDB();
  res.json({ success: true, notifications: dbState.notifications });
};

// Admin: Add Job or Internship routes
app.post("/api/admin/job", addJobHandler);
app.post("/api/admin/jobs", (req, res) => {
  if (req.body.isInternship) {
    return addInternshipHandler(req, res);
  }
  return addJobHandler(req, res);
});

app.post("/api/admin/internship", addInternshipHandler);
app.post("/api/admin/internships", addInternshipHandler);

// Admin: Create notification routes
app.post("/api/admin/notification", createNotificationHandler);
app.post("/api/admin/notifications", createNotificationHandler);

/* ================== VITE MIDDLEWARE SETUP ================== */

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
