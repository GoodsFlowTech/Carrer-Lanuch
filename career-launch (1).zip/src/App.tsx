import React, { useState, useEffect } from "react";
import { 
  Sparkles, BookOpen, Briefcase, Award, GraduationCap, CheckCircle, Bell, 
  MapPin, Laptop, LogOut, Sun, Moon, Database, Settings, ShieldAlert,
  ListTodo, User, Compass, HelpCircle, Layers, Calendar, Eye, X, Mail, Phone, ExternalLink, Star,
  Check, AlertCircle, TrendingUp, Zap
} from "lucide-react";

import { Student, Job, Internship, Notification, PreparationTopic, MockTest, ResumeData } from "./types";
import { AuthPages } from "./components/AuthPages";
import { Dashboard } from "./components/Dashboard";
import { ResumeBuilder } from "./components/ResumeBuilder";
import { JobsSection } from "./components/JobsSection";
import { InternshipSection } from "./components/InternshipSection";
import { PrepSection } from "./components/PrepSection";
import { EligibilityChecker } from "./components/EligibilityChecker";
import { MockTestsSection } from "./components/MockTestsSection";
import { InterviewPrep } from "./components/InterviewPrep";
import { AdminPanel } from "./components/AdminPanel";

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem("careerlaunch_token"));
  const [student, setStudent] = useState<Student | null>(() => {
    try {
      const saved = localStorage.getItem("careerlaunch_student");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [activeTab, setActiveTab] = useState<string>("Home");
  const [theme, setTheme] = useState<"light" | "dark">("light");

  // DB datasets loaded from API
  const [jobs, setJobs] = useState<Job[]>([]);
  const [internships, setInternships] = useState<PremiumInternship[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [prepTopics, setPrepTopics] = useState<PreparationTopic[]>([]);
  const [mockTests, setMockTests] = useState<MockTest[]>([]);
  const [allStudents, setAllStudents] = useState<Student[]>([]); // for admin view

  // Profile Form states
  const [profileCgpa, setProfileCgpa] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("careerlaunch_student");
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.cgpa?.toString() || "8.0";
      }
    } catch {}
    return "8.0";
  });
  const [profileSkills, setProfileSkills] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("careerlaunch_student");
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.skills?.join(", ") || "";
      }
    } catch {}
    return "";
  });
  const [profileSavedMsg, setProfileSavedMsg] = useState(false);
  const [duplicateSkillAlert, setDuplicateSkillAlert] = useState<string | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Skill ratings state (1 to 5 stars) loaded from and saved to localStorage
  const [skillRatings, setSkillRatings] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem("careerlaunch_skill_ratings");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleSetSkillRating = (skillName: string, rating: number) => {
    const skillLower = skillName.toLowerCase().trim();
    const updated = { ...skillRatings, [skillLower]: rating };
    setSkillRatings(updated);
    localStorage.setItem("careerlaunch_skill_ratings", JSON.stringify(updated));
  };

  // AI Personalized Career roadmap state
  const [isGeneratingRoadmap, setIsGeneratingRoadmap] = useState(false);
  const [aiRoadmapResult, setAiRoadmapResult] = useState<string | null>(null);

  // Skill Gap Analysis states
  const [isAnalyzingGaps, setIsAnalyzingGaps] = useState(false);
  const [gapsAnalysis, setGapsAnalysis] = useState<{
    evaluatedJobsCount: number;
    savedJobsCount: number;
    isDemo: boolean;
    gaps: Array<{
      jobId: string;
      company: string;
      role: string;
      missingSkills: string[];
      matchedSkills: string[];
      matchPercentage: number;
    }>;
  } | null>(null);

  const handleAnalyzeSkillGaps = () => {
    setIsAnalyzingGaps(true);
    setGapsAnalysis(null);
    
    setTimeout(() => {
      const savedJobs = jobs.filter(j => j.saved);
      const isDemoFlag = savedJobs.length === 0;
      const jobsToEvaluate = isDemoFlag ? jobs.slice(0, 3) : savedJobs.slice(0, 3);
      
      const currentSkills = profileSkills
        .split(",")
        .map(s => s.trim().toLowerCase())
        .filter(Boolean);
        
      const results = jobsToEvaluate.map(job => {
        const reqs = job.requirements || [];
        const matched: string[] = [];
        const missing: string[] = [];
        
        reqs.forEach(req => {
          const reqClean = req.trim();
          const reqLower = reqClean.toLowerCase();
          
          const isMatched = currentSkills.some(mySkill => {
            const mySkillLower = mySkill.trim().toLowerCase();
            return mySkillLower.includes(reqLower) || reqLower.includes(mySkillLower);
          });
          
          if (isMatched) {
            matched.push(reqClean);
          } else {
            missing.push(reqClean);
          }
        });
        
        const matchPercentage = reqs.length > 0 
          ? Math.round((matched.length / reqs.length) * 100) 
          : 100;
          
        return {
          jobId: job.id,
          company: job.company,
          role: job.role,
          missingSkills: missing,
          matchedSkills: matched,
          matchPercentage
        };
      });
      
      setGapsAnalysis({
        evaluatedJobsCount: results.length,
        savedJobsCount: savedJobs.length,
        isDemo: isDemoFlag,
        gaps: results
      });
      setIsAnalyzingGaps(false);
    }, 700);
  };

  const handleQuickAddSkill = (skillToAdd: string) => {
    const current = profileSkills.trim();
    const skillsArr = current ? current.split(",").map(s => s.trim()) : [];
    
    const exists = skillsArr.some(s => s.toLowerCase() === skillToAdd.toLowerCase());
    if (!exists) {
      const updated = [...skillsArr, skillToAdd].join(", ");
      setProfileSkills(updated);
      
      setTimeout(() => {
        const savedJobs = jobs.filter(j => j.saved);
        const isDemoFlag = savedJobs.length === 0;
        const jobsToEvaluate = isDemoFlag ? jobs.slice(0, 3) : savedJobs.slice(0, 3);
        const currentSkillsLower = [...skillsArr, skillToAdd].map(s => s.toLowerCase().trim());
        
        const results = jobsToEvaluate.map(job => {
          const reqs = job.requirements || [];
          const matched: string[] = [];
          const missing: string[] = [];
          reqs.forEach(req => {
            const reqClean = req.trim();
            const isMatched = currentSkillsLower.some(mySkill => 
              mySkill.includes(reqClean.toLowerCase()) || reqClean.toLowerCase().includes(mySkill)
            );
            if (isMatched) matched.push(reqClean);
            else missing.push(reqClean);
          });
          return {
            jobId: job.id,
            company: job.company,
            role: job.role,
            missingSkills: missing,
            matchedSkills: matched,
            matchPercentage: reqs.length > 0 ? Math.round((matched.length / reqs.length) * 100) : 100
          };
        });
        
        setGapsAnalysis({
          evaluatedJobsCount: results.length,
          savedJobsCount: savedJobs.length,
          isDemo: isDemoFlag,
          gaps: results
        });
      }, 50);
    }
  };

  // On page mount, parse session from local token
  useEffect(() => {
    if (token) {
      fetchProfile();
      fetchStaticDatabase();
    }
  }, [token]);

  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/student/profile", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        const studentObj = data.student || data;
        setStudent(studentObj);
        localStorage.setItem("careerlaunch_student", JSON.stringify(studentObj));
        setProfileCgpa(studentObj.cgpa?.toString() || "8.0");
        setProfileSkills(studentObj.skills?.join(", ") || "");
      } else {
        console.warn("Backend profile returned unsuccess state, utilizing cached content.");
      }
    } catch (e) {
      console.warn("Backend profile fetch offline fallback used.", e);
    }
  };

  const fetchStaticDatabase = async () => {
    try {
      // Parallel requests mapping the "No Mock Data" real integration guidelines
      const [jobsRes, internRes, notsRes, topicsRes, testsRes, studentsRes] = await Promise.all([
        fetch("/api/jobs"),
        fetch("/api/internships"),
        fetch("/api/notifications"),
        fetch("/api/prep-topics"),
        fetch("/api/mock-tests"),
        fetch("/api/students", { headers: { "Authorization": `Bearer ${token}` } })
      ]);

      if (jobsRes.ok) {
        const data = await jobsRes.json();
        setJobs(Array.isArray(data) ? data : (data.jobs || []));
      }
      if (internRes.ok) {
        const data = await internRes.json();
        setInternships(Array.isArray(data) ? data : (data.internships || []));
      }
      if (notsRes.ok) {
        const data = await notsRes.json();
        setNotifications(Array.isArray(data) ? data : (data.notifications || []));
      }
      if (topicsRes.ok) {
        const data = await topicsRes.json();
        setPrepTopics(Array.isArray(data) ? data : (data.topics || []));
      }
      if (testsRes.ok) {
        const data = await testsRes.json();
        setMockTests(Array.isArray(data) ? data : (data.mockTests || []));
      }
      if (studentsRes.ok) {
        const data = await studentsRes.json();
        setAllStudents(Array.isArray(data) ? data : (data.students || []));
      }
    } catch (e) {
      console.error("Database sync failed", e);
    }
  };

  const handleLoginSuccess = (userObj: Student, receivedToken: string) => {
    localStorage.setItem("careerlaunch_token", receivedToken);
    localStorage.setItem("careerlaunch_student", JSON.stringify(userObj));
    setToken(receivedToken);
    setStudent(userObj);
    setProfileCgpa(userObj.cgpa?.toString() || "8.0");
    setProfileSkills(userObj.skills?.join(", ") || "");
    setActiveTab("Home");
  };

  const handleLogout = () => {
    localStorage.removeItem("careerlaunch_token");
    localStorage.removeItem("careerlaunch_student");
    setToken(null);
    setStudent(null);
  };

  // Toggle Dark/Light Theme on html node
  const handleToggleTheme = () => {
    const nextTheme = theme === "light" ? "dark" : "light";
    setTheme(nextTheme);
    const root = window.document.documentElement;
    if (nextTheme === "dark") {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  };

  // App API state helpers for child components
  const handleSaveResume = async (resumeData: ResumeData) => {
    if (!student) return false;

    // Recalculate local completion percentage
    let completion = 20;
    const cgVal = student.cgpa || parseFloat(profileCgpa) || 8.0;
    if (cgVal > 0) completion += 20;
    const skillList = student.skills?.length > 0 ? student.skills : profileSkills.split(",").map(s => s.trim()).filter(Boolean);
    if (skillList.length > 0) completion += 20;
    if (resumeData.summary) completion += 20;
    if (resumeData.projects && resumeData.projects.length > 0) completion += 20;

    const updatedStudent: Student = {
      ...student,
      resume: resumeData,
      profileCompleted: Math.min(100, completion)
    };

    localStorage.setItem("careerlaunch_student", JSON.stringify(updatedStudent));
    setStudent(updatedStudent);

    // Sync in global register lists
    try {
      const usersRaw = localStorage.getItem("careerlaunch_users");
      if (usersRaw) {
        const users = JSON.parse(usersRaw);
        const idx = users.findIndex((u: any) => u.student.id === student.id);
        if (idx !== -1) {
          users[idx].student = updatedStudent;
          localStorage.setItem("careerlaunch_users", JSON.stringify(users));
        }
      }
    } catch (err) {
      console.error("Local user db list sync err", err);
    }

    try {
      const res = await fetch("/api/student/resume", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ resume: resumeData })
      });
      if (res.ok) {
        fetchProfile();
      }
    } catch (e) {
      console.error("Server API resume sync failed", e);
    }
    return true;
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSavedMsg(false);
    if (!student) return;

    const parsedCgpa = parseFloat(profileCgpa) || 8.0;
    const parsedSkills = profileSkills.split(",").map(s => s.trim()).filter(Boolean);

    let completion = 20;
    if (parsedCgpa > 0) completion += 20;
    if (parsedSkills.length > 0) completion += 20;
    if (student.resume?.summary) completion += 20;
    if (student.resume?.projects && student.resume.projects.length > 0) completion += 20;

    const updatedStudent: Student = {
      ...student,
      cgpa: parsedCgpa,
      skills: parsedSkills,
      profileCompleted: Math.min(100, completion)
    };

    localStorage.setItem("careerlaunch_student", JSON.stringify(updatedStudent));
    setStudent(updatedStudent);
    setProfileSavedMsg(true);
    setTimeout(() => setProfileSavedMsg(false), 3000);

    // Sync back in register list
    try {
      const usersRaw = localStorage.getItem("careerlaunch_users");
      if (usersRaw) {
        const users = JSON.parse(usersRaw);
        const idx = users.findIndex((u: any) => u.student.id === student.id);
        if (idx !== -1) {
          users[idx].student = updatedStudent;
          localStorage.setItem("careerlaunch_users", JSON.stringify(users));
        }
      }
    } catch (err) {
      console.error("Local list profile save sync error", err);
    }

    try {
      const res = await fetch("/api/student/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          cgpa: parsedCgpa,
          skills: parsedSkills
        })
      });
      if (res.ok) {
        fetchProfile();
        fetchStaticDatabase();
      }
    } catch (e) {
      console.error("API Profile Update Fail fallback to Local", e);
    }
  };

  const handleToggleCompleteIndex = async (topicId: string) => {
    try {
      const isCurrentlyCompleted = student?.progress?.[topicId] || false;
      const res = await fetch(`/api/prep/${topicId}/complete`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ completed: !isCurrentlyCompleted })
      });
      if (res.ok) {
        fetchProfile();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveQuizScore = async (topicId: string, score: number, total: number) => {
    try {
      const res = await fetch(`/api/prep/${topicId}/quiz-score`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ score, total })
      });
      if (res.ok) {
        fetchProfile();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubmitMockTest = async (testId: string, score: number, total: number) => {
    try {
      const res = await fetch(`/api/mock-tests/${testId}/submit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ score, total })
      });
      if (res.ok) {
        fetchProfile();
        fetchStaticDatabase();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleSaveJob = async (jobId: string) => {
    try {
      const res = await fetch(`/api/jobs/${jobId}/save`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      return res.ok;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  // Generate Personalized Career Guidance Map
  const handleAIRequestRoadmap = async () => {
    setIsGeneratingRoadmap(true);
    setAiRoadmapResult(null);
    try {
      const res = await fetch("/api/ai/career-guidance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          skills: student?.skills || ["React", "SQL"],
          cgpa: student?.cgpa || 8.0,
          interests: "Software Dev and Advanced Engineering placements"
        })
      });
      const data = await res.json();
      if (res.ok) {
        setAiRoadmapResult(
          `🚀 AI Personalized Learning Roadmap:
1. Immediate Focus Checklist:
${data.learningFocus?.map((item: string, i: number) => `   - [Step ${i+1}]: ${item}`).join("\n")}
2. Recommended Career Focus: ${data.recommendedRoles?.[0]?.role || "Cloud / SDE"} at ${data.recommendedRoles?.[0]?.suitabilityScore || "90"}% suitability score rating.
3. Preparation Tip: ${data.immediateAdvice || "Master discrete math concepts."}`
        );
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingRoadmap(false);
    }
  };

  if (!token || !student) {
    return <AuthPages onLoginSuccess={handleLoginSuccess} />;
  }

  // Determine if student user has admin privileges based on mock credentials bypass
  const isAdmin = student.registerNo === "ADMIN999";

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-950 dark:text-gray-100 transition-colors duration-200" id="main_layout">
      
      {/* 1. Header Branded Navbar */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700/80 sticky top-0 z-40 px-6 py-4 flex items-center justify-between shadow-sm print:hidden">
        <div className="flex items-center space-x-3">
          <div className="h-9 w-9 bg-indigo-600 rounded-lg flex items-center justify-center text-white shadow-md shadow-indigo-600/15">
            <GraduationCap className="h-5.5 w-5.5" />
          </div>
          <div>
            <h1 className="text-sm font-extrabold tracking-tight font-sans">CareerLaunch</h1>
            <p className="text-[10px] text-gray-500 dark:text-gray-400 font-mono">Roll-No: {student.registerNo} • {student.department}</p>
          </div>
        </div>

        {/* Global togglers & controls */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleToggleTheme}
            id="theme_toggler"
            className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-750 border border-gray-150 dark:border-gray-600 rounded-lg text-gray-500 dark:text-gray-400 transition"
          >
            {theme === "light" ? <Moon className="h-4.5 w-4.5" /> : <Sun className="h-4.5 w-4.5" />}
          </button>
          
          <button
            onClick={handleLogout}
            id="student_logout_btn"
            className="bg-gray-50 dark:bg-gray-750 hover:bg-indigo-50 hover:text-indigo-650 px-3 py-1.5 border dark:border-gray-600 rounded-xl text-xs font-semibold font-sans flex items-center space-x-1 transition text-red-500"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* 2. Page split layouts: Sidebar grid navigation + Content board */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Navigation panel */}
        <aside className="lg:col-span-3 space-y-4 print:hidden">
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-4 shadow-sm space-y-1">
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest pl-2 block pb-1.5">GENERAL PORTAL MENU</span>
            
            {[
              { id: "Home", label: "Home / Analytics", icon: Compass },
              { id: "Resume Builder", label: "Resume Builder", icon: Layers },
              { id: "Jobs", label: "Jobs Drive Hub", icon: Briefcase },
              { id: "Internships", label: "Internships Hub", icon: Laptop },
              { id: "Placement Preparation", label: "Placement Preparation", icon: BookOpen },
              { id: "Learning Roadmap", label: "Learning Roadmap", icon: ListTodo },
              { id: "Company Eligibility Checker", label: "Company Eligibility", icon: Award },
              { id: "Mock Tests", label: "Mock Tests Room", icon: AuditIcon || CheckCircle },
              { id: "Interview Preparation", label: "Interview Simulator", icon: Sparkles },
              { id: "Profile", label: "Manage Profile", icon: User }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  id={`nav_tab_${tab.id.replace(/\s+/g, "_")}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold transition flex items-center space-x-2.5 ${
                    activeTab === tab.id
                      ? "bg-indigo-600 text-white"
                      : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-750"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}

            {/* Admin only bypass tab option */}
            {isAdmin && (
              <div className="pt-2 border-t mt-2">
                <button
                  id="nav_tab_Admin_Panel"
                  onClick={() => setActiveTab("Admin Panel")}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-extrabold transition flex items-center space-x-2.5 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 ${
                    activeTab === "Admin Panel" ? "border-2 border-red-500" : ""
                  }`}
                >
                  <Settings className="h-4 w-4" />
                  <span>ADMINISTRATOR PANEL</span>
                </button>
              </div>
            )}
          </div>

          {/* Quick status progress in Sidebar */}
          <div className="bg-white dark:bg-gray-800 border p-4 rounded-xl shadow-sm text-xs space-y-2">
            <h4 className="font-bold text-gray-900 dark:text-white">Active Placement Status</h4>
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-gray-500">GPA Minimum</span>
                <span className="font-semibold text-gray-800 dark:text-white">{student.cgpa} CGPA</span>
              </div>
              <div className="flex justify-between text-[10px]">
                <span className="text-gray-500">Resume Status</span>
                <span className="text-emerald-500 font-semibold">{student.resume?.summary ? "Draft Ready" : "Incomplete"}</span>
              </div>
              <div className="flex justify-between text-[10px]">
                <span className="text-gray-500">Enrolled drives</span>
                <span className="font-semibold">{student.jobApplications?.length || 0} applications</span>
              </div>
            </div>
          </div>
        </aside>

        {/* 3. Main Dynamic views router panels */}
        <main className="lg:col-span-9" id="main_content_window">
          
          {activeTab === "Home" && (
            <Dashboard 
              student={student} 
              jobs={jobs} 
              internships={internships} 
              notifications={notifications} 
              topics={prepTopics} 
              onNavigate={setActiveTab}
            />
          )}

          {activeTab === "Resume Builder" && (
            <ResumeBuilder 
              student={student} 
              onSave={handleSaveResume}
            />
          )}

          {activeTab === "Jobs" && (
            <JobsSection 
              student={student} 
              jobs={jobs} 
              onApply={() => Promise.resolve(true)}
              onToggleSave={handleToggleSaveJob}
              onReload={fetchStaticDatabase}
            />
          )}

          {activeTab === "Internships" && (
            <InternshipSection 
              student={student} 
              internships={internships} 
              onApplyIntern={() => Promise.resolve(true)}
              onReload={fetchStaticDatabase}
            />
          )}

          {activeTab === "Placement Preparation" && (
            <PrepSection 
              student={student} 
              topics={prepTopics} 
              onToggleCompleteIndex={handleToggleCompleteIndex}
              onSaveQuizScore={handleSaveQuizScore}
            />
          )}

          {/* Tab: Learning Roadmap timeline logic check */}
          {activeTab === "Learning Roadmap" && (
            <div className="bg-white dark:bg-gray-800 border border-gray-150 dark:border-gray-700 rounded-xl p-6 shadow-sm space-y-6" id="learning_roadmap_panel">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white flex items-center space-x-1.5">
                    <ListTodo className="h-5.5 w-5.5 text-indigo-600" />
                    <span>Structured Placement Roadmap</span>
                  </h3>
                  <p className="text-xs text-gray-400">Master essential milestones sequentially to qualifies for corporate interviews</p>
                </div>

                <button
                  id="btn_ai_roadmap"
                  onClick={handleAIRequestRoadmap}
                  disabled={isGeneratingRoadmap}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-1.5 px-4 rounded-lg shadow-sm transition inline-flex items-center space-x-1"
                >
                  <Sparkles className="h-4 w-4 text-indigo-300" />
                  <span>{isGeneratingRoadmap ? "Formulating plan..." : "AI Generate Personal Plan"}</span>
                </button>
              </div>

              {/* Display AI Roadmap response output wrapper */}
              {aiRoadmapResult && (
                <div className="p-4 bg-slate-900 border border-gray-800 text-xs rounded-xl relative">
                  <span className="text-[10px] bg-indigo-600 text-white font-mono font-bold px-2 py-0.5 rounded absolute right-3 top-3">
                    GEMINI ROADMAP PLAN
                  </span>
                  <pre className="text-indigo-300 whitespace-pre-wrap font-sans leading-relaxed text-xs">
                    {aiRoadmapResult}
                  </pre>
                </div>
              )}

              {/* Graphical Timeline list */}
              <div className="space-y-6 font-sans relative pl-6 border-l border-indigo-100 dark:border-gray-700 ml-4 py-2">
                
                {/* Step 1 */}
                <div className="relative">
                  <span className={`absolute -left-[30px] top-1 h-5 w-5 rounded-full border-2 bg-white flex items-center justify-center font-bold text-[10px] ${
                    student.cgpa >= 7.5 ? "border-emerald-500 text-emerald-500" : "border-indigo-600 text-indigo-600"
                  }`}>
                    1
                  </span>
                  <div>
                    <h4 className="font-bold text-gray-950 dark:text-white text-sm">Prerequisite Verification - Satisfy CGPA barriers</h4>
                    <p className="text-xs text-gray-400 leading-normal">Maintain minimum GPA targets. Minimum eligibility thresholds generally span &gt;= 7.0 CGPA on campus.</p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="relative">
                  <span className={`absolute -left-[30px] top-1 h-5 w-5 rounded-full border-2 bg-white flex items-center justify-center font-bold text-[10px] ${
                    student.resume?.summary ? "border-emerald-500 text-emerald-500" : "border-indigo-600 text-indigo-600"
                  }`}>
                    2
                  </span>
                  <div>
                    <h4 className="font-bold text-gray-950 dark:text-white text-sm">Portfolio Integrity Check - Build and Audit Resume</h4>
                    <p className="text-xs text-gray-400 leading-normal">Construct professional resumes mapping credentials, relevant projects, and certifications.</p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="relative">
                  <span className="absolute -left-[30px] top-1 h-5 w-5 rounded-full border-2 bg-indigo-600 flex items-center justify-center text-white font-mono font-bold text-[10px]">
                    3
                  </span>
                  <div>
                    <h4 className="font-bold text-gray-950 dark:text-white text-sm">Module Roadmaps - Complete Preparation topics</h4>
                    <p className="text-xs text-gray-400 leading-normal">Go through Aptitude (Quantitative), Coding and Logic Reasoning roadmaps. Take module quizzes.</p>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="relative">
                  <span className="absolute -left-[30px] top-1 h-5 w-5 rounded-full border-2 bg-indigo-200 text-indigo-600 flex items-center justify-center font-bold text-[10px]">
                    4
                  </span>
                  <div>
                    <h4 className="font-bold text-gray-950 dark:text-white text-sm">Diagnostic assessments & mock tests</h4>
                    <p className="text-xs text-gray-400 leading-normal">Take general diagnostic examinations matching recruiter specific logical and DBMS assessments.</p>
                  </div>
                </div>

                {/* Step 5 */}
                <div className="relative">
                  <span className="absolute -left-[30px] top-1 h-5 w-5 rounded-full border-2 bg-indigo-200 text-indigo-600 flex items-center justify-center font-bold text-[10px]">
                    5
                  </span>
                  <div>
                    <h4 className="font-bold text-gray-950 dark:text-white text-sm">Simulated Interview boards</h4>
                    <p className="text-xs text-gray-400 leading-normal">Train in mock behavioral environments, audit customized phrased answers using Gemini.</p>
                  </div>
                </div>

              </div>
            </div>
          )}

          {activeTab === "Company Eligibility Checker" && (
            <EligibilityChecker 
              student={student} 
              jobs={jobs} 
              internships={internships}
            />
          )}

          {activeTab === "Mock Tests" && (
            <MockTestsSection 
              student={student} 
              mockTests={mockTests} 
              onSubmitTest={handleSubmitMockTest}
            />
          )}

          {activeTab === "Interview Preparation" && (
            <InterviewPrep 
              student={student}
            />
          )}

          {/* Tab: Student profile parameters */}
          {activeTab === "Profile" && (
            <div className="bg-white dark:bg-gray-800 border border-gray-150 dark:border-gray-700/80 rounded-xl p-6 shadow-sm space-y-6">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b dark:border-gray-700/80 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-950 dark:text-white flex items-center space-x-1.5">
                    <User className="h-5.5 w-5.5 text-indigo-600" />
                    <span>Complete Student Profile credentials</span>
                  </h3>
                  <p className="text-xs text-gray-500">Edit core academic parameters to automate your qualifying eligibility validations</p>
                </div>
                <button
                  id="preview_resume_profile_bttn"
                  type="button"
                  onClick={() => setIsPreviewOpen(true)}
                  className="bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-extrabold px-4 py-2.5 rounded-xl border border-indigo-150 dark:border-indigo-900/50 text-[11px] uppercase tracking-wider flex items-center space-x-1.5 shadow-sm transition self-start sm:self-center cursor-pointer"
                >
                  <Eye className="h-4 w-4" />
                  <span>Preview Resume</span>
                </button>
              </div>

              {profileSavedMsg && (
                <div className="p-3 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded-lg text-xs font-semibold text-center flex items-center justify-center space-x-1">
                  <CheckCircle className="h-4 w-4" />
                  <span>Profile updated cleanly in persistent datastore!</span>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pt-2" id="profile_interactive_grid">
                {/* Left side: Profile parameters editing form */}
                <div className="lg:col-span-6 space-y-4">
                  {/* Form editing profile parameters */}
                  <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs" id="profile_update_form">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-400 font-semibold mb-1">REGISTER NUMBER</label>
                        <input
                          type="text"
                          className="w-full bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded-xl text-gray-400 border font-mono tracking-wider"
                          value={student.registerNo}
                          disabled
                        />
                      </div>
                      <div>
                        <label className="block text-gray-400 font-semibold mb-1">FULL NAME</label>
                        <input
                          type="text"
                          className="w-full bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded-xl text-gray-400 border"
                          value={student.name}
                          disabled
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-400 font-semibold mb-1">DEPARTMENT</label>
                        <input
                          type="text"
                          className="w-full bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded-xl text-gray-400 border"
                          value={student.department}
                          disabled
                        />
                      </div>
                      <div>
                        <label className="block text-gray-400 font-semibold mb-1">GRADUATION YEAR</label>
                        <input
                          type="text"
                          className="w-full bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded-xl text-gray-400 border font-mono"
                          value={student.graduationYear}
                          disabled
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] text-gray-500 font-bold mb-1">ACTIVE COLLEGE CGPA</label>
                      <input
                        id="profile_cgpa_field"
                        type="number"
                        step="0.01"
                        min="1"
                        max="10"
                        placeholder="e.g. 8.25"
                        className="w-full bg-[#f8fafc] dark:bg-[#334155] text-[#1e293b] dark:text-[#f8fafc] border border-gray-200 dark:border-gray-600 px-3 py-2.5 rounded-xl font-mono text-sm font-extrabold focus:ring-2 focus:ring-indigo-500"
                        value={profileCgpa}
                        onChange={e => setProfileCgpa(e.target.value)}
                      />
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[11px] text-gray-500 font-bold">KEY TECHNICAL SKILLS (Comma Separated)</label>
                        <div className="text-[10px] text-gray-400 dark:text-gray-500 font-semibold font-sans flex items-center space-x-2">
                          <span id="skills_live_count" className="bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-300 px-2 py-0.5 rounded font-bold font-mono">
                            {profileSkills.split(",").map(s => s.trim()).filter(Boolean).length} skills
                          </span>
                          <span id="skills_char_counter" className="font-mono text-gray-400 dark:text-gray-500">
                            {profileSkills.length} chars
                          </span>
                          {profileSkills.length > 0 && (
                            <button
                              type="button"
                              id="clear_skills_btn"
                              onClick={() => setProfileSkills("")}
                              className="text-[10px] text-red-500 hover:text-red-600 font-bold hover:underline cursor-pointer"
                            >
                              Clear All
                            </button>
                          )}
                        </div>
                      </div>
                      <input
                        id="profile_skills_field"
                        type="text"
                        placeholder="e.g. React, Python, C++, SQL"
                        className={`w-full bg-[#f8fafc] dark:bg-[#334155] text-[#1e293b] dark:text-[#f8fafc] border px-3 py-2.5 rounded-xl text-xs focus:ring-2 transition-colors duration-200 ${
                          profileSkills.length > 150 
                            ? "border-red-500 dark:border-red-400 focus:ring-red-500" 
                            : "border-gray-200 dark:border-gray-600 focus:ring-indigo-500"
                        }`}
                        value={profileSkills}
                        onChange={e => {
                          const inputVal = e.target.value;
                          // Detect duplicates on comma separator
                          const skills = inputVal.split(",").map(s => s.trim().toLowerCase());
                          const seen = new Set();
                          let duplicateFound = null;
                          
                          for (const skill of skills) {
                            if (skill) {
                              if (seen.has(skill)) {
                                duplicateFound = skill;
                                break;
                              }
                              seen.add(skill);
                            }
                          }

                          if (duplicateFound) {
                            setDuplicateSkillAlert(`Skill "${duplicateFound}" is already present in your list!`);
                            // Automatically strip the duplicate, but preserve formatting/commas
                            const uniqueSkills: string[] = [];
                            const parsedSeen = new Set();
                            inputVal.split(",").forEach(item => {
                              const trim = item.trim();
                              if (trim) {
                                if (!parsedSeen.has(trim.toLowerCase())) {
                                  parsedSeen.add(trim.toLowerCase());
                                  uniqueSkills.push(trim);
                                }
                              } else {
                                uniqueSkills.push(""); // Keep trailing comma layout
                              }
                            });
                            setProfileSkills(uniqueSkills.join(", "));
                            setTimeout(() => setDuplicateSkillAlert(null), 3500);
                          } else {
                            setProfileSkills(inputVal);
                          }
                        }}
                      />
                      {duplicateSkillAlert && (
                        <div id="skills_duplicate_toast" className="p-2.5 mt-1.5 bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-250 dark:border-amber-900 rounded-lg text-xs font-semibold flex items-center space-x-1.5">
                          <ShieldAlert className="h-4 w-4 shrink-0 text-amber-500 animate-bounce" />
                          <span>{duplicateSkillAlert}</span>
                        </div>
                      )}
                      {profileSkills.length > 150 && (
                        <p id="skills_warning_msg" className="text-[11px] text-red-500 dark:text-red-400 font-semibold font-sans mt-1">
                          ⚠️ Note: Your list exceeds 150 characters. We recommend keeping descriptors succinct for cleaner alignment.
                        </p>
                      )}
                      <div className="mt-4 space-y-3 bg-gray-50/50 dark:bg-gray-750/20 p-4 rounded-xl border border-gray-150 dark:border-gray-750/80">
                        <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono mb-2">
                          Skills Proficiency & Metric Progress
                        </h4>
                        {(!student.skills || student.skills.length === 0) ? (
                          <p className="text-[11px] text-gray-400 italic font-sans">No skills listed yet. Add skills comma-separated above and click save changes.</p>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="profile_skills_proficiency_grid">
                            {student.skills.map((sk, index) => {
                              const skillLower = sk.toLowerCase().trim();
                              const currentRating = skillRatings[skillLower] || 3;
                              const ratingPercentage = currentRating * 20;
                              const lengthFactor = Math.min(100, Math.max(15, sk.length * 6));

                              return (
                                <div 
                                  key={index}
                                  className="bg-white dark:bg-gray-800 p-3 rounded-lg border border-gray-100 dark:border-gray-700/60 shadow-sm flex flex-col justify-between space-y-2.5 transition duration-150 hover:shadow"
                                  id={`profile_skill_item_${index}`}
                                >
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="font-mono font-bold text-xs text-gray-900 dark:text-white truncate">
                                      {sk}
                                    </span>
                                    
                                    {/* 1-5 Star Selection for Proficiency */}
                                    <div className="flex items-center space-x-0.5" id={`skill_rating_stars_${index}`}>
                                      {[1, 2, 3, 4, 5].map((star) => {
                                        const active = star <= currentRating;
                                        return (
                                          <button
                                            key={star}
                                            type="button"
                                            onClick={() => handleSetSkillRating(sk, star)}
                                            className="p-0.5 focus:outline-none transition group cursor-pointer animate-none"
                                            title={`Rate ${star} stars`}
                                          >
                                            <Star 
                                              className={`h-3.5 w-3.5 transition-all ${
                                                active 
                                                  ? "fill-amber-400 text-amber-400 scale-105" 
                                                  : "text-gray-200 dark:text-gray-600 hover:text-amber-300"
                                              }`} 
                                            />
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>

                                  <div className="space-y-1.5 pt-1">
                                    {/* Visual Progress Bar for Star Rating */}
                                    <div className="space-y-0.5">
                                      <div className="flex justify-between items-center text-[9px] font-mono font-extrabold">
                                        <span className="text-gray-400">PROFICIENCY</span>
                                        <span className="text-indigo-600 dark:text-indigo-400">{ratingPercentage}%</span>
                                      </div>
                                      <div className="w-full bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all duration-300 shadow-sm"
                                          style={{ width: `${ratingPercentage}%` }}
                                        />
                                      </div>
                                    </div>

                                    {/* String Length Metric Indicator & Bar */}
                                    <div className="space-y-0.5">
                                      <div className="flex justify-between items-center text-[9px] font-mono font-extrabold">
                                        <span className="text-gray-400">STRING COMPLEXITY</span>
                                        <span className="text-emerald-500">{lengthFactor}% ({sk.length} chars)</span>
                                      </div>
                                      <div className="w-full bg-gray-150 dark:bg-gray-700/40 h-1 rounded-full overflow-hidden">
                                        <div 
                                          className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                                          style={{ width: `${lengthFactor}%` }}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        id="save_profile_details"
                        type="submit"
                        className="bg-indigo-600 hover:bg-indigo-500 font-semibold text-white px-5 py-2 rounded-xl shadow-sm shadow-indigo-600/10 transition cursor-pointer"
                      >
                        Save Changes
                      </button>
                    </div>
                  </form>
                </div>

                {/* Right side: Live Skill Gap Analysis */}
                <div className="lg:col-span-6 space-y-4 border-t lg:border-t-0 lg:border-l border-gray-150 dark:border-gray-700/80 pt-6 lg:pt-0 lg:pl-6" id="skill_gaps_analyzer_container">
                  <div className="space-y-2">
                    <h3 className="text-sm font-bold text-gray-950 dark:text-white uppercase tracking-wider flex items-center space-x-2">
                      <Zap className="h-4 w-4 text-amber-500 fill-amber-500" />
                      <span>Skill Gaps Analyzer</span>
                    </h3>
                    <p className="text-xs text-gray-400 leading-relaxed font-sans">
                      Align your portfolio with current company requirements. We will compare your skills against the **top 3 saved/bookmarked jobs** or fallback active campus criteria.
                    </p>
                  </div>

                  <div className="pt-1">
                    <button
                      id="analyze_skill_gaps_button"
                      type="button"
                      onClick={handleAnalyzeSkillGaps}
                      disabled={isAnalyzingGaps}
                      className="bg-slate-900 border border-slate-900 hover:bg-slate-800 text-white dark:bg-indigo-600 dark:border-indigo-600 dark:hover:bg-indigo-500 font-medium px-4 py-2.5 rounded-xl text-xs uppercase tracking-wider flex items-center space-x-2 transition duration-150 cursor-pointer shadow-sm disabled:opacity-50"
                    >
                      {isAnalyzingGaps ? (
                        <>
                          <div className="h-3.5 w-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>Evaluating matching...</span>
                        </>
                      ) : (
                        <>
                          <TrendingUp className="h-4 w-4 text-indigo-200" />
                          <span>Analyze Skill Gaps</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Results Display */}
                  {gapsAnalysis ? (
                    <div className="space-y-4 animate-in fade-in slide-in-from-top-1 bg-white dark:bg-gray-800/20" id="gaps_analysis_results">
                      <div className="bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100/60 dark:border-indigo-900/50 rounded-xl p-3.5 space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold text-indigo-900 dark:text-indigo-200">
                          <span>Match Evaluation Report</span>
                          <span className="text-[10px] bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded-full font-mono">
                            {gapsAnalysis.isDemo ? "Sample Active Jobs" : `Based on ${gapsAnalysis.savedJobsCount} Bookmarks`}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-400 dark:text-indigo-200/60 leading-normal font-sans">
                          {gapsAnalysis.isDemo 
                            ? "Save/bookmark specific jobs in the Campus Placement Hub to generate your personalized gap report! Below is a sample analysis against general campus openings."
                            : `Successfully analyzed differences against up to 3 of your bookmarked job specifications.`}
                        </p>
                      </div>

                      <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1 scrollbar-thin">
                        {gapsAnalysis.gaps.map((gapItem, idx) => (
                          <div 
                            key={gapItem.jobId} 
                            id={`gap_analysis_job_card_${idx}`}
                            className="bg-[#fafafa] dark:bg-gray-850 border border-gray-150 dark:border-gray-700/85 rounded-xl p-4 space-y-3"
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <h4 className="font-extrabold text-xs text-gray-950 dark:text-white leading-tight">
                                  {gapItem.role}
                                </h4>
                                <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-450 block mt-0.5">
                                  {gapItem.company}
                                </span>
                              </div>
                              <div className="text-right shrink-0">
                                <span className={`text-[11px] font-extrabold font-mono px-2 py-0.5 rounded-full ${
                                  gapItem.matchPercentage >= 70 
                                    ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-350"
                                    : gapItem.matchPercentage >= 40
                                      ? "bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-300"
                                      : "bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-350"
                                }`}>
                                  {gapItem.matchPercentage}% Match
                                </span>
                              </div>
                            </div>

                            {/* Match rate visual thin progress bar */}
                            <div className="w-full bg-gray-250 dark:bg-gray-700 h-1.5 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all duration-300 ${
                                  gapItem.matchPercentage >= 70 
                                    ? "bg-emerald-500" 
                                    : gapItem.matchPercentage >= 40 
                                      ? "bg-amber-500" 
                                      : "bg-rose-500"
                                }`}
                                style={{ width: `${gapItem.matchPercentage}%` }}
                              />
                            </div>

                            {/* Gaps / Missing list */}
                            <div className="space-y-1.5 pt-1">
                              <span className="text-[10px] font-mono tracking-widest text-gray-400 block uppercase">
                                Missing Required Skills ({gapItem.missingSkills.length})
                              </span>
                              {gapItem.missingSkills.length === 0 ? (
                                <div className="text-[11px] text-emerald-600 dark:text-emerald-450 font-bold flex items-center space-x-1 font-sans">
                                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                                  <span>Perfect alignment! No skills missing.</span>
                                </div>
                              ) : (
                                <div className="flex flex-wrap gap-1.5 pt-0.5">
                                  {gapItem.missingSkills.map((missingSk, mIdx) => (
                                    <button
                                      key={mIdx}
                                      type="button"
                                      onClick={() => handleQuickAddSkill(missingSk)}
                                      className="group/btn bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 text-rose-700 dark:text-rose-300 px-2 py-1 rounded text-[10px] font-mono border border-rose-105 dark:border-rose-900/50 flex items-center space-x-1.5 transition cursor-pointer"
                                      title="Click to instantly insert this skill to your key skills profile list on the left!"
                                    >
                                      <span>{missingSk}</span>
                                      <span className="text-[9px] text-rose-500 dark:text-rose-450 opacity-60 group-hover/btn:opacity-100 transition-all font-sans font-bold">
                                        + Quick Add
                                      </span>
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>

                            {/* Matched skills list */}
                            {gapItem.matchedSkills.length > 0 && (
                              <div className="space-y-1.5 pt-2 border-t border-gray-150/50 dark:border-gray-750/30">
                                <span className="text-[9px] font-mono tracking-widest text-[#a1a1aa] dark:text-gray-500 block uppercase">
                                  Satisfied Capabilities ({gapItem.matchedSkills.length})
                                </span>
                                <div className="flex flex-wrap gap-1">
                                  {gapItem.matchedSkills.map((matchedSk, sIdx) => (
                                    <span 
                                      key={sIdx} 
                                      className="bg-slate-100/50 dark:bg-gray-800 text-gray-500 dark:text-gray-400 px-1.5 py-0.5 rounded text-[10px] font-mono border border-gray-200/40 dark:border-gray-700/55 flex items-center space-x-0.5"
                                    >
                                      <Check className="h-3 w-3 text-emerald-500 mr-0.5 shrink-0" />
                                      <span>{matchedSk}</span>
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    /* Initial callout state when no analysis is run yet */
                    <div className="border border-dashed border-gray-200 dark:border-gray-700 rounded-xl p-6 text-center space-y-3 bg-gray-50/20 dark:bg-gray-900/10">
                      <div className="h-10 w-10 rounded-full bg-slate-50 dark:bg-gray-800 flex items-center justify-center mx-auto text-gray-400">
                        <AlertCircle className="h-5 w-5 text-gray-400 animate-pulse" />
                      </div>
                      <div className="space-y-1 font-sans">
                        <h4 className="text-xs font-bold text-gray-950 dark:text-white uppercase tracking-wider">
                          Ready for live analysis
                        </h4>
                        <p className="text-xs text-gray-400 leading-normal max-w-sm mx-auto">
                          Click **Analyze Skill Gaps** to compile a live difference matrix between your portfolio skills and active company requirements.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "Admin Panel" && isAdmin && (
            <AdminPanel 
              students={allStudents} 
              jobs={jobs} 
              internships={internships} 
              notifications={notifications}
              adminToken={token}
              onRefresh={fetchStaticDatabase}
            />
          )}

          {/* Resume Preview Modal */}
          {isPreviewOpen && (
            <div 
              id="resume_preview_modal_overlay"
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4 transition duration-300"
              onClick={() => setIsPreviewOpen(false)}
            >
              <div 
                id="resume_preview_modal_card"
                className="bg-white dark:bg-gray-800 border dark:border-gray-700 w-full max-w-4xl max-h-[85vh] rounded-2xl overflow-hidden shadow-2xl flex flex-col animate-in fade-in zoom-in-95 duration-200"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Modal Header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50">
                  <div>
                    <h3 className="text-sm font-extrabold text-gray-900 dark:text-white uppercase tracking-wider flex items-center space-x-2">
                      <Eye className="h-4.5 w-4.5 text-indigo-650 text-indigo-600" />
                      <span>Resume Portfolio Live Preview</span>
                    </h3>
                    <p className="text-[10px] text-gray-400 mt-0.5 font-sans">Template Format: Elegant placement dispatch card</p>
                  </div>
                  <button 
                    onClick={() => setIsPreviewOpen(false)}
                    className="p-1.5 rounded-lg text-gray-400 hover:text-gray-550 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-750 transition cursor-pointer"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {/* Modal Content - Scrollable paper template */}
                <div className="flex-1 overflow-y-auto p-6 md:p-8 bg-gray-50 dark:bg-gray-900/50 scrollbar-thin">
                  {student?.resume && (student.resume.summary || student.resume.skills?.length > 0 || student.resume.experience?.length > 0 || student.resume.projects?.length > 0) ? (
                    <div 
                      id="resume_preview_paper"
                      className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-6 md:p-8 rounded-xl shadow-sm text-xs font-sans max-w-3xl mx-auto space-y-6 text-[#1e293b] dark:text-[#f3f4f6]"
                    >
                      {/* Paper Header */}
                      <div className="border-b dark:border-gray-700 pb-5 text-center sm:text-left flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        <div className="space-y-1">
                          <h2 className="text-2xl font-extrabold text-gray-950 dark:text-white tracking-tight">
                            {student.resume.name || student.name}
                          </h2>
                          <p className="text-indigo-600 dark:text-indigo-400 font-bold tracking-wider uppercase text-[10px]">
                            {student.resume.title || "STUDENT PORTFOLIO"}
                          </p>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-[11px] text-gray-500 dark:text-gray-400 font-medium">
                          {student.resume.email && (
                            <div className="flex items-center space-x-1.5">
                              <Mail className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                              <span>{student.resume.email}</span>
                            </div>
                          )}
                          {student.resume.phone && (
                            <div className="flex items-center space-x-1.5">
                              <Phone className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                              <span>{student.resume.phone}</span>
                            </div>
                          )}
                          {student.resume.location && (
                            <div className="flex items-center space-x-1.5">
                              <MapPin className="h-3.5 w-3.5 text-indigo-600 shrink-0" />
                              <span>{student.resume.location}</span>
                            </div>
                          )}
                          {student.resume.github && (
                            <a 
                              href={student.resume.github.startsWith("http") ? student.resume.github : `https://${student.resume.github}`} 
                              target="_blank" 
                              rel="noopener noreferrer" 
                              className="flex items-center space-x-1.5 text-indigo-600 dark:text-indigo-400 hover:underline"
                            >
                              <ExternalLink className="h-3.5 w-3.5 shrink-0 text-indigo-600" />
                              <span>GitHub Portfolio</span>
                            </a>
                          )}
                          {student.resume.linkedin && (
                            <a 
                              href={student.resume.linkedin.startsWith("http") ? student.resume.linkedin : `https://${student.resume.linkedin}`} 
                              target="_blank" 
                              rel="noopener noreferrer" 
                              className="flex items-center space-x-1.5 text-indigo-600 dark:text-indigo-400 hover:underline"
                            >
                              <ExternalLink className="h-3.5 w-3.5 shrink-0 text-indigo-600" />
                              <span>LinkedIn Connect</span>
                            </a>
                          )}
                        </div>
                      </div>

                      {/* Summary Section */}
                      {student.resume.summary && (
                        <div className="space-y-1.5">
                          <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono">
                            Professional Summary
                          </h4>
                          <p className="text-[11.5px] leading-relaxed text-gray-650 dark:text-gray-300 font-sans">
                            {student.resume.summary}
                          </p>
                        </div>
                      )}

                      {/* Technical Skills & Certifications Side-by-Side */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                        {/* Skills column */}
                        {student.resume.skills && student.resume.skills.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono">
                              Core Competencies & Skills
                            </h4>
                            <div className="flex flex-wrap gap-1.5">
                              {student.resume.skills.map((skill, i) => (
                                <span key={i} className="bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded font-mono font-semibold text-[10px]">
                                  {skill}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Certifications column */}
                        {student.resume.certifications && student.resume.certifications.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono">
                              Acquired Certifications
                            </h4>
                            <div className="flex flex-wrap gap-1.5">
                              {student.resume.certifications.map((cert, i) => (
                                <span key={i} className="bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-350 px-2 py-0.5 rounded font-mono font-semibold text-[10px] border border-emerald-100 dark:border-emerald-950">
                                  {cert}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Education Section */}
                      {student.resume.education && student.resume.education.length > 0 && (
                        <div className="space-y-3.5 border-t dark:border-gray-700 pt-4">
                          <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono">
                            Education Profile
                          </h4>
                          <div className="space-y-4">
                            {student.resume.education.map((edu) => (
                              <div key={edu.id} className="flex flex-col sm:flex-row sm:items-start justify-between gap-1.5">
                                <div>
                                  <span className="font-extrabold text-gray-900 dark:text-white text-xs">{edu.institution}</span>
                                  <p className="text-[11px] text-gray-500 font-medium">
                                    {edu.degree} in {edu.fieldOfStudy}
                                  </p>
                                </div>
                                <div className="sm:text-right font-mono text-[10px] text-gray-400 shrink-0">
                                  <span>{edu.startYear} - {edu.endYear}</span>
                                  <span className="block text-indigo-600 dark:text-indigo-400 font-bold">{edu.grade}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Experience Section */}
                      {student.resume.experience && student.resume.experience.length > 0 && (
                        <div className="space-y-3.5 border-t dark:border-gray-700 pt-4">
                          <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono">
                            Work & Internship Experience
                          </h4>
                          <div className="space-y-4">
                            {student.resume.experience.map((exp) => (
                              <div key={exp.id} className="space-y-1.5">
                                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-1.5">
                                  <div>
                                    <span className="font-extrabold text-gray-900 dark:text-white text-xs">{exp.role}</span>
                                    <p className="text-[11px] text-indigo-600 dark:text-indigo-400 font-bold">
                                      {exp.company} • <span className="font-normal text-gray-400 font-mono text-[10px]">{exp.location} {exp.isRemote && "(Remote)"}</span>
                                    </p>
                                  </div>
                                  <span className="font-mono text-[10px] text-gray-400 shrink-0 sm:text-right">
                                    {exp.startDate} - {exp.endDate}
                                  </span>
                                </div>
                                <p className="text-[11px] text-gray-500 dark:text-gray-300 leading-relaxed pl-3 border-l-2 border-gray-150 dark:border-gray-700 font-sans">
                                  {exp.description}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Projects Section */}
                      {student.resume.projects && student.resume.projects.length > 0 && (
                        <div className="space-y-3.5 border-t dark:border-gray-700 pt-4">
                          <h4 className="text-[10px] font-bold tracking-widest text-[#64748b] dark:text-[#94a3b8] uppercase font-mono">
                            Technical Projects Portfolio
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {student.resume.projects.map((proj) => (
                              <div key={proj.id} className="p-3 border border-gray-150 dark:border-gray-700/60 rounded-xl space-y-2 bg-gray-50/20 dark:bg-gray-800/10 font-sans">
                                <div className="flex items-start justify-between gap-2">
                                  <span className="font-bold text-gray-900 dark:text-white text-xs">{proj.title}</span>
                                  {proj.link && (
                                    <a 
                                      href={proj.link.startsWith("http") ? proj.link : `https://${proj.link}`} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center space-x-0.5 text-[9px] font-bold uppercase shrink-0"
                                    >
                                      <span>Repo</span>
                                      <ExternalLink className="h-3 w-3 text-indigo-600" />
                                    </a>
                                  )}
                                </div>
                                <p className="text-[10.5px] text-gray-500 dark:text-gray-300 leading-normal">
                                  {proj.description}
                                </p>
                                <div className="flex flex-wrap gap-1 pt-1">
                                  {proj.technologies?.map((tech, i) => (
                                    <span key={i} className="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-1.5 py-0.5 rounded font-mono text-[9px]">
                                      {tech}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* Elegant missing state fallback */
                    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-8 rounded-xl shadow-sm text-center max-w-lg mx-auto my-6 space-y-4">
                      <div className="h-12 w-12 bg-amber-50 dark:bg-amber-950/20 text-text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center mx-auto">
                        <ShieldAlert className="h-6 w-6 text-amber-550 animate-pulse" />
                      </div>
                      <div className="space-y-1.5 font-sans">
                        <h4 className="text-sm font-extrabold text-gray-950 dark:text-white uppercase tracking-wider">
                          No Saved Resume Portfolio Details
                        </h4>
                        <p className="text-xs text-gray-400 leading-relaxed">
                          A beautiful resume portfolio template compilation requires you to formulate, draft and save credentials under the Resume Builder tab first!
                        </p>
                      </div>
                      <button
                        id="redirect_to_resume_builder_btn"
                        onClick={() => {
                          setActiveTab("Resume Builder");
                          setIsPreviewOpen(false);
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-[11px] px-4 py-2.5 rounded-xl shadow-sm shadow-indigo-600/10 transition uppercase tracking-wider inline-flex items-center space-x-1.5 cursor-pointer"
                      >
                        <BookOpen className="h-4 w-4 text-indigo-200" />
                        <span>Go to Resume Builder</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Modal Footer */}
                <div className="bg-gray-50/50 dark:bg-gray-850 px-6 py-4 border-t border-gray-100 dark:border-gray-700 flex justify-end">
                  <button
                    onClick={() => setIsPreviewOpen(false)}
                    className="bg-slate-100 hover:bg-slate-200 dark:bg-gray-700 dark:hover:bg-gray-650 text-gray-750 dark:text-gray-200 font-extrabold px-4 py-2 rounded-xl text-xs transition uppercase tracking-wider cursor-pointer"
                  >
                    Close Preview
                  </button>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}

// Temporary audit helper for typescript validation
const AuditIcon = null;
type PremiumInternship = Internship;

