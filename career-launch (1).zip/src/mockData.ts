import { Job, Internship, PreparationTopic, MockTest, Notification } from './types';

export const INITIAL_JOBS: Job[] = [
  {
    id: "job-1",
    company: "Google",
    logoUrl: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=100&h=100&fit=crop&q=80",
    role: "Associate Software Engineer",
    location: "Bangalore, India",
    type: "Full-time",
    salary: "₹18,00,000 - ₹24,00,000 PA",
    deadline: "2026-07-15",
    description: "Join our Core Engineering team to develop next-generation search systems, cloud architectures, and highly scalable distributed systems. You will work on software development, algorithmic design, and architectural scalability.",
    requirements: [
      "B.Tech/B.E in Computer Science, IT, or related fields",
      "CGPA > 8.0/10.0 (No active backlogs)",
      "Strong proficiency in Java, C++, or Python",
      "Exceptional understanding of Data Structures and Algorithms"
    ],
    eligibilityCgpa: 8.0
  },
  {
    id: "job-2",
    company: "Microsoft",
    logoUrl: "https://images.unsplash.com/photo-1625014020903-e329f586c990?w=100&h=100&fit=crop&q=80",
    role: "Cloud Support Engineer",
    location: "Hyderabad, India (Hybrid)",
    type: "Full-time",
    salary: "₹14,50,000 - ₹18,00,000 PA",
    deadline: "2026-06-30",
    description: "Responsible for designing, developing, and optimizing Azure cloud components. Help our global scale partners migrate, troubleshoot, and build resilient architectures.",
    requirements: [
      "B.Tech/M.Tech candidates graduating in 2026",
      "CGPA > 7.5/10.0",
      "Good understanding of Computer Networks, OS (Linux/Windows), and public cloud paradigms",
      "Strong communication and collaborative skills"
    ],
    eligibilityCgpa: 7.5
  },
  {
    id: "job-3",
    company: "Accenture",
    logoUrl: "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=100&h=100&fit=crop&q=80",
    role: "Associate Software Engineer",
    location: "Chennai, India",
    type: "Full-time",
    salary: "₹4,50,000 - ₹6,50,000 PA",
    deadline: "2026-08-01",
    description: "Design, build, test, and deploy applications to solve real-world industry pain-points. Work in agile delivery squads using cloud computing, enterprise frameworks, and mobile tech.",
    requirements: [
      "All branches of B.E/B.Tech/MCA/M.Sc (CS/IT) eligible",
      "CGPA > 6.5/10.0",
      "Excellent logical ability, analytical skills, and coding basics",
      "Knowledge of database systems is a plus"
    ],
    eligibilityCgpa: 6.5
  },
  {
    id: "job-4",
    company: "Amazon Web Services",
    logoUrl: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=100&h=100&fit=crop&q=80",
    role: "Cloud Associate",
    location: "Bangalore, India",
    type: "Full-time",
    salary: "₹12,00,000 - ₹15,00,000 PA",
    deadline: "2026-07-10",
    description: "Support AWS hyper-scale infrastructures. Build automation, optimize operations, and configure networking protocols alongside our operations experts.",
    requirements: [
      "B.Tech in CS/IT/ECE",
      "CGPA > 7.0/10.0",
      "Familiarity with Shell scripting, Python, and TCP/IP networking",
      "Exemplary problem-solving skills"
    ],
    eligibilityCgpa: 7.0
  },
  {
    id: "job-5",
    company: "Tata Consultancy Services (TCS)",
    logoUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=100&h=100&fit=crop&q=80",
    role: "Ninja & Digital Developer",
    location: "Mumbai, India",
    type: "Full-time",
    salary: "₹3,36,000 - ₹7,00,000 PA",
    deadline: "2026-06-25",
    description: "Placement support for TCS Digital and Ninja tiers. Roles cover enterprise software engineering, web development, big data engineering, and tech consultancy roles across key industrial sectors.",
    requirements: [
      "B.E/B.Tech/M.E/M.Tech/MCA candidates of 2026 batch",
      "CGPA > 6.0/10.0",
      "Working knowledge of Web languages, Python, Java, or C++",
      "Aptitude test qualification is mandatory"
    ],
    eligibilityCgpa: 6.0
  }
];

export const INITIAL_INTERNSHIPS: Internship[] = [
  {
    id: "intern-1",
    company: "Google",
    logoUrl: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=100&h=100&fit=crop&q=80",
    role: "Software Engineering Intern",
    location: "Bangalore, India (On-site)",
    duration: "3 Months (Summer 2026)",
    stipend: "₹80,000 / Month",
    type: "In-Office",
    deadline: "2026-06-20",
    description: "Work directly on live products alongside senior engineers. Write clean, reliable code, refine database queries, and contribute to scaling cloud functions.",
    requirements: [
      "Currently pursuing B.Tech in Computer Science / Mathematics & Computing",
      "CGPA > 8.0/10.0",
      "Expected graduation in 2027 (Pre-Final Year Students)"
    ],
    eligibilityCgpa: 8.0
  },
  {
    id: "intern-2",
    company: "Cisco Systems",
    logoUrl: "https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=100&h=100&fit=crop&q=80",
    role: "Technical Intern – Networking",
    location: "Bangalore, India",
    duration: "6 Months",
    stipend: "₹45,000 / Month",
    type: "Hybrid",
    deadline: "2026-07-01",
    description: "Gain hands-on training with network virtualization, core routers, load balancers, and system engineering.",
    requirements: [
      "B.Tech ECE/EEE/IT",
      "Good familiarity with packet tracing, routing protocols, and basic C coding",
      "CGPA > 7.0/10.0"
    ],
    eligibilityCgpa: 7.0
  },
  {
    id: "intern-3",
    company: "Razorpay",
    logoUrl: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=100&h=100&fit=crop&q=80",
    role: "Frontend Developer Intern",
    location: "Remote (Work from Home)",
    duration: "4 Months",
    stipend: "₹35,000 / Month",
    type: "Remote",
    deadline: "2026-06-18",
    description: "Support our core payments experience team. Code elegant, pixel-perfect reactive interfaces using React, Tailwind CS, and dynamic layout systems.",
    requirements: [
      "Open to all branches with strong frontend skills",
      "Proficiency in React.js, modern CSS, and state management",
      "CGPA > 6.5/10.0"
    ],
    eligibilityCgpa: 6.5
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: "not-1",
    title: "Google Software Developer Hiring Drive Opened!",
    content: "Google India is officially launching its campus registration for Associate Software Engineers. Minimum eligibility: 8.0 CGPA on graduation. Last date to register through this portal is July 15, 2026.",
    date: "2026-06-09",
    category: "placement",
    important: true
  },
  {
    id: "not-2",
    title: "Aptitude Mock Test Live Session",
    content: "The weekly Aptitude Mock test focusing on Quantitative and Logical Reasoning is now active. This test contains 20 core questions inspired by TCS Digital, Accenture, and Microsoft placement exam models.",
    date: "2026-06-08",
    category: "mock-test",
    important: false
  },
  {
    id: "not-3",
    title: "Razorpay Remote Internships Now Hiring",
    content: "Razorpay has opened remote applications for Frontend Developer Interns. Recommended for outstanding UI students. Stipend is ₹35,000/month. Apply under the Internships section.",
    date: "2026-06-07",
    category: "internship",
    important: false
  }
];

export const INITIAL_MOCK_TESTS: MockTest[] = [
  {
    id: "test-apt",
    title: "Aptitude Assessment Test 1",
    category: "Aptitude",
    durationMinutes: 15,
    questions: [
      {
        id: "apt-q1",
        question: "A train running at the speed of 60 km/hr crosses a pole in 9 seconds. What is the length of the train?",
        options: ["120 meters", "180 meters", "324 meters", "150 meters"],
        correctOptionIndex: 3,
        explanation: "Speed = 60 * (5/18) m/sec = 50/3 m/sec. Length of train = Speed * Time = (50/3) * 9 = 150 meters."
      },
      {
        id: "apt-q2",
        question: "Find the missing number in the series: 4, 9, 20, 43, 90, ?",
        options: ["185", "180", "150", "175"],
        correctOptionIndex: 0,
        explanation: "Each term is twice the preceding term plus an increasing integer starting with 1. 2*4+1=9. 2*9+2=20. 2*20+3=43. 2*43+4=90. 2*90+5=185."
      },
      {
        id: "apt-q3",
        question: "A, B and C can do a piece of work in 20, 30 and 60 days respectively. In how many days can A do the work if he is assisted by B and C on every third day?",
        options: ["12 days", "15 days", "16 days", "18 days"],
        correctOptionIndex: 1,
        explanation: "A's 2 day work = (1/20)*2 = 1/10. Work on 3rd day by A+B+C = 1/20 + 1/30 + 1/60 = 6/60 = 1/10. Work done in 3 days = 1/10 + 1/10 = 1/5. Hence, 5 * 3 days = 15 days total."
      },
      {
        id: "apt-q4",
        question: "What is the probability of drawing an Ace or a King from a well-shuffled pack of 52 cards?",
        options: ["1/13", "2/13", "4/13", "1/26"],
        correctOptionIndex: 1,
        explanation: "Total cases = 52. Ace cards = 4, King cards = 4. Number of favorable cards = 8. Probability = 8/52 = 2/13."
      },
      {
        id: "apt-q5",
        question: "If a light flash occurs every 6 seconds and another occurs every 15 seconds, starting at the same time, when will they flash together next?",
        options: ["21 seconds", "45 seconds", "30 seconds", "60 seconds"],
        correctOptionIndex: 2,
        explanation: "The LCM of 6 and 15 is 30. So they will flash together next at 30 seconds."
      }
    ]
  },
  {
    id: "test-tech",
    title: "Core Technical Mastery Test",
    category: "Technical",
    durationMinutes: 20,
    questions: [
      {
        id: "tech-q1",
        question: "Which data structure is mainy used inside real-time Operating Systems to schedule processes based on priorities?",
        options: ["Stack", "Queue", "Priority Queue (Heap)", "Linked List"],
        correctOptionIndex: 2,
        explanation: "Priority queue / Heaps are highly efficient for dynamic retrieve operations for minimum or maximum element keys in O(1) retrieval time and O(log n) modifications."
      },
      {
        id: "tech-q2",
        question: "In database systems, which of the following is correct regarding ACID properties?",
        options: [
          "A stands for Association",
          "C stands for Consistency, guaranteeing legal transaction states",
          "I stands for Indexing",
          "D stands for Dependency"
        ],
        correctOptionIndex: 1,
        explanation: "ACID: Atomicity, Consistency, Isolation, Durability. Consistency ensures that database constraints are preserved during transaction lifetimes."
      },
      {
        id: "tech-q3",
        question: "What is the time complexity of searching an element in a balanced binary search tree (BST) of N nodes?",
        options: ["O(N)", "O(1)", "O(N log N)", "O(log N)"],
        correctOptionIndex: 3,
        explanation: "For balanced trees, the depth is logarithmic, hence search takes root-to-leaf comparison paths yielding O(log N) worst-case metrics."
      },
      {
        id: "tech-q4",
        question: "Which of the following describes Encapsulation in Object-Oriented Programming?",
        options: [
          "Creating multiple subclasses from a master parent",
          "Hiding implementation details and mapping direct client requests",
          "Bundling data attributes and operating methods within a single class, gating access via getters/setters",
          "Declaring interfaces of virtual functions"
        ],
        correctOptionIndex: 2,
        explanation: "Encapsulation is the core paradigm of binding internal variables (data state) and methods together, shielding elements from unapproved external interference."
      },
      {
        id: "tech-q5",
        question: "In Computer Networks, what is the layer in the OSI model responsible for encryption, compression, and translation of encoding format frameworks?",
        options: ["Session Layer", "Presentation Layer", "Application Layer", "Network Layer"],
        correctOptionIndex: 1,
        explanation: "The Presentation Layer handles syntax and semantic conversions, including data compression, text-encoding mapping, and cryptographic encryption schemas."
      }
    ]
  }
];

export const INITIAL_PREP_TOPICS: PreparationTopic[] = [
  // 1. Aptitude - Number System
  {
    id: "apt-num",
    title: "Number System",
    category: "Aptitude",
    subCategory: "Quantitative",
    theory: `The Number System is the fundamental baseline of quantitative aptitude. It involves understanding numbers, their classifications, properties, and relationships.

Key Concepts:
1. Classification: Natural Numbers (N), Whole Numbers (W), Integers (Z), Rational, Irrational, and Prime Numbers.
2. Divisibility Rules: Helps to quickly check if a number can be factorized. For example, a number is divisible by 3 if the sum of its digits is divisible by 3.
3. Unit Digits: Cyclic rules of power factors (e.g. cyclicity of 2 is 4: 2^1=2, 2^2=4, 2^3=8, 2^4=16, 2^5 finishes at 2).
4. HCF & LCM: Highest Common Factor and Least Common Multiple. Invariant: Product of two numbers = HCF * LCM.
5. Remainder Theorems: Fermat's Little Theorem and Euler's Totient Theorem for exponential remainders.`,
    notes: [
      "Formula: Co-prime numbers always have an HCF of 1.",
      "Units digit cyclicity repeats every 4 powers for integers ending in 2, 3, 7, 8.",
      "To find trailing zeros of N!, sum the floors of N divided by powers of 5: [N/5] + [N/25] + [N/125] + ..."
    ],
    videoLinks: [
      { title: "Number System Aptitude Course", url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }
    ],
    practiceQuestions: [
      {
        question: "Find the remainder when 2^31 is divided by 5.",
        answer: "3",
        hint: "Note cyclic powers of 2 mod 5: 2^1=2, 2^2=4, 2^3=3, 2^4=1. It repeats every 4 powers. Since 31 = 4 * 7 + 3, the remainder matches 2^3 which is 8 = 3 mod 5."
      },
      {
        question: "What is the HCF of two numbers if their product is 360 and LCM is 60?",
        answer: "6",
        hint: "Use formula: HCF = Product / LCM"
      }
    ],
    quiz: [
      {
        id: "apt-num-q1",
        question: "What is the unit digit in the product (3^65 * 6^59 * 7^71)?",
        options: ["2", "4", "6", "8"],
        correctOptionIndex: 1,
        explanation: "Cyclicity of 3 is 4, 65 = 4*16+1, so 3^1 unit digit = 3. Unit digit of any power of 6 is 6. Cyclicity of 7 is 4, 71 = 4*17+3, so 7^3 unit digit = 3. Product: 3*6*3 = 54. The unit digit is 4."
      },
      {
        id: "apt-num-q2",
        question: "How many positive integer factors does 120 have?",
        options: ["12", "16", "20", "24"],
        correctOptionIndex: 1,
        explanation: "Prime factorization of 120 = 2^3 * 3^1 * 5^1. Total factors = (3+1) * (1+1) * (1+1) = 4 * 2 * 2 = 16."
      }
    ]
  },
  // APTITUDE - Percentage
  {
    id: "apt-pct",
    title: "Percentage",
    category: "Aptitude",
    subCategory: "Quantitative",
    theory: `Percentages define values per hundred, forming the basis of computation for profit/loss, data analysis, and ratio scaling.

Key Formulas:
1. Expressing X as percentage of Y: (X / Y) * 100
2. If A is R% more than B, then B is less than A by: [R / (100 + R)] * 100%
3. If A is R% less than B, then B is more than A by: [R / (100 - R)] * 100%
4. Consecutive changes of X% and Y%: Net increase/decrease = (X + Y + XY/100)%`,
    notes: [
      "Convert common fractions to percentages: 1/2=50%, 1/3=33.3%, 1/4=25%, 1/5=20%, 1/6=16.6%, 1/8=12.5%.",
      "Multiply by positive decimals for increases (e.g., increase of 15% is multiplying by 1.15)."
    ],
    videoLinks: [
      { title: "Percentages Concept Booster", url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }
    ],
    practiceQuestions: [
      {
        question: "If salary of A is 25% more than B, how much percentage is B's salary less than A?",
        answer: "20%",
        hint: "Apply R/(100+R)*100 = 25/125 * 100 = 20%."
      }
    ],
    quiz: [
      {
        id: "apt-pct-q1",
        question: "The population of a town increases by 10% in the first year and decreases by 10% in the second year. What is the net change after two years?",
        options: ["No change", "1% increase", "1% decrease", "2% decrease"],
        correctOptionIndex: 2,
        explanation: "Net change = (+10) + (-10) + (10 * -10)/100 = -100/100 = -1%. Net decrease of 1%."
      }
    ]
  },
  // TECHNICAL - DSA - Arrays
  {
    id: "tech-arr",
    title: "Arrays",
    category: "Technical",
    subCategory: "Data Structures & Algorithms",
    theory: `An Array is a collection of contiguous memory locations storing elements of the same type. It is the most elementary data structure.

Properties:
- Indexing: O(1) random retrieval
- Insertion/Deletion: O(N) in worst case as rest elements require shifting
- Static sizes: Fixed size at allocation in languages like C/C++; Dynamic wrappers like std::vector in C++ or ArrayList in Java.

Common Interview Patterns:
1. Two Pointers: E.g., reversing values, finding pairs in a sorted array.
2. Sliding Window: Keeping track of subarray sums/properties within a dynamic boundary.
3. Kadane's Algorithm: For maximum subarray sum.
4. Dutch National Flag algorithm: Sorting arrays consisting of zeros, ones, and twos in O(N).`,
    notes: [
      "Always verify edge cases: Empty arrays, arrays with size 1, arrays with all negative numbers.",
      "Prefix Sum helper arrays are ideal for continuous range queries."
    ],
    videoLinks: [
      { title: "Array Data Structure Complete Guide", url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }
    ],
    practiceQuestions: [
      {
        question: "Find the maximum sum subarray in [-2, 1, -3, 4, -1, 2, 1, -5, 4].",
        answer: "6 (Subarray: [4, -1, 2, 1])",
        hint: "Apply Kadane's Algorithm: Maintain running localSum and globalMax."
      }
    ],
    quiz: [
      {
        id: "tech-arr-q1",
        question: "Which of the following array operations has O(1) time complexity?",
        options: [
          "Inserting an element in the middle of the array",
          "Searching for an unsorted value",
          "Accessing an element at index K",
          "Deleting an element from the beginning"
        ],
        correctOptionIndex: 2,
        explanation: "Contiguous storage allows direct address calculation (BaseAddress + K * ElementSize) which is computed in constant CPU cycles."
      },
      {
        id: "tech-arr-q2",
        question: "What is the optimal time complexity to find the element that appears more than floor(N/2) times in an array of size N (Majority Element)?",
        options: ["O(N^2)", "O(N log N)", "O(N)", "O(1)"],
        correctOptionIndex: 2,
        explanation: "Using Boyer-Moore Majority Voting Algorithm, we scan the array in a single pass holding a candidate and balance counter, completing in O(N) time with O(1) space."
      }
    ]
  },
  // TECHNICAL - DBMS - Normalization
  {
    id: "tech-norm",
    title: "Normalization",
    category: "Technical",
    subCategory: "Database Management Systems",
    theory: `Normalization is the database design technique of organizing tables to minimize redundancy and prevent Insertion, Deletion, and Update anomalies.

Normal Forms:
1. First Normal Form (1NF): Values in each column must be atomic (no arrays/multivalued lists).
2. Second Normal Form (2NF): Must be in 1NF, and all non-prime attributes must possess full functional dependency on the entire primary key (no partial dependencies on composite keys).
3. Third Normal Form (3NF): Must be in 2NF, and no non-prime attribute is transitively dependent on the primary key (no non-prime -> non-prime dependencies).
4. Boyce-Codd Normal Form (BCNF): For every functional dependency X -> Y, X must be a superkey. BCNF is stricter than 3NF.`,
    notes: [
      "Partial dependency exists when a non-key column depends on only part of a composite primary key.",
      "Transitive dependency represents a dependency chain: Key -> A and A -> B, where B is a non-prime field."
    ],
    videoLinks: [
      { title: "Database Normalization Tutorials", url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }
    ],
    practiceQuestions: [
      {
        question: "If a relation has key (A, B) and functional dependency B -> C, which Normal Form is violated first?",
        answer: "2NF",
        hint: "Since C depends on only B (part of composite primary key (A, B)), a Partial Dependency is present, violating 2NF."
      }
    ],
    quiz: [
      {
        id: "tech-db-q1",
        question: "In standard DBMS normalization, BCNF is defined by what absolute constraint on every functional dependency X -> Y?",
        options: [
          "Y must be subset of X",
          "X must be a candidate superkey",
          "X must be prime attribute",
          "Y must be prime attribute"
        ],
        correctOptionIndex: 1,
        explanation: "Boyce-Codd Normal Form requires that for any functional dependency X -> Y, the determinant X must invariably be a Super Key."
      }
    ]
  }
];

export const MOCK_INTERVIEW_HR_QUESTIONS = [
  {
    id: "hr-1",
    question: "Tell me about yourself.",
    category: "HR",
    tips: "Focus on your academic background, core projects, programming skills, and keep it under 2 minutes. Structure with Past, Present, Future."
  },
  {
    id: "hr-2",
    question: "Why do you want to join this particular company?",
    category: "HR",
    tips: "Connect your career goals with the company's products/services, scale, culture of learning, and recent achievements."
  },
  {
    id: "hr-3",
    question: "What are your greatest strengths and weaknesses?",
    category: "HR",
    tips: "Highlight active problem solving or rapid learning as a strength. For weakness, choose a minor, genuine skill you are actively working to improve (e.g., getting nervous at public speaking, resolving it through presentations)."
  }
];

export const MOCK_INTERVIEW_TECH_QUESTIONS = [
  {
    id: "tech-1",
    question: "Explain the differences between SQL and NoSQL databases. When would you use which?",
    category: "Technical",
    tips: "Mention relational schemas, ACID compliance, and vertical scaling for SQL. Contrast with flexible schemas, horizontal scaling (sharding), and eventual consistency paradigms for NoSQL."
  },
  {
    id: "tech-2",
    question: "What happens in the background when you type a URL like 'https://google.com' in a browser and hit Enter?",
    category: "Technical",
    tips: "Explain: 1. DNS Lookup (retrieves IP via cache/root servers), 2. TCP Handshake (3-way SYN-ACK), 3. SSL/TLS Negotiation, 4. HTTP GET Request, 5. Server Processing/Response, 6. Browser rendering (DOM parsing, layout paint)."
  },
  {
    id: "tech-3",
    question: "What is garbage collection in programming languages like Java? How does it differ from memory control in C++?",
    category: "Technical",
    tips: "Java uses automatic heap management (JVM identifies unreachable parent reference paths). C++ gives complete control, requiring manual allocation (new/delete) or smart pointer ownership patterns."
  }
];
