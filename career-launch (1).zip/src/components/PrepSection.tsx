import React, { useState } from "react";
import { BookOpen, Video, FileText, CheckCircle, Award, Volume2, HelpCircle, ArrowRight, Play, Sparkles, AlertCircle } from "lucide-react";
import { Student, PreparationTopic, Question } from "../types";

interface PrepSectionProps {
  student: Student;
  topics: PreparationTopic[];
  onToggleCompleteIndex: (topicId: string) => Promise<void>;
  onSaveQuizScore: (topicId: string, score: number, total: number) => Promise<void>;
}

export function PrepSection({ student, topics, onToggleCompleteIndex, onSaveQuizScore }: PrepSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<"Aptitude" | "Reasoning" | "Verbal" | "Technical">("Aptitude");
  const [selectedSub, setSelectedSub] = useState<string>("Quantitative"); // or DSA etc.
  const [activeTopicId, setActiveTopicId] = useState<string>("apt-num");

  // Quiz running states
  const [quizRunning, setQuizRunning] = useState(false);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswerIdx, setSelectedAnswerIdx] = useState<number | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [quizFinished, setQuizFinished] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Practice question state tracker
  const [revealedPractice, setRevealedPractice] = useState<Record<number, boolean>>({});

  // Dynamic AI study expander states
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiExpandedNotes, setAiExpandedNotes] = useState<string | null>(null);

  // Topic classification definitions matching standard outlines
  const ROADMAPS: Record<string, { subs: string[]; topics: { id: string; title: string; sub: string }[] }> = {
    Aptitude: {
      subs: ["Quantitative"],
      topics: [
        { id: "apt-num", title: "Number System", sub: "Quantitative" },
        { id: "apt-pct", title: "Percentage", sub: "Quantitative" },
        { id: "apt-pl", title: "Profit and Loss", sub: "Quantitative" },
        { id: "apt-rp", title: "Ratio and Proportion", sub: "Quantitative" },
        { id: "apt-tw", title: "Time and Work", sub: "Quantitative" },
        { id: "apt-td", title: "Time and Distance", sub: "Quantitative" },
        { id: "apt-pb", title: "Probability", sub: "Quantitative" },
        { id: "apt-pc", title: "Permutation and Combination", sub: "Quantitative" },
        { id: "apt-di", title: "Data Interpretation", sub: "Quantitative" },
        { id: "apt-lp", title: "Logical Puzzles", sub: "Quantitative" }
      ]
    },
    Reasoning: {
      subs: ["Logical reasoning"],
      topics: [
        { id: "re-br", title: "Blood Relations", sub: "Logical reasoning" },
        { id: "re-cd", title: "Coding Decoding", sub: "Logical reasoning" },
        { id: "re-ds", title: "Direction Sense", sub: "Logical reasoning" },
        { id: "re-sa", title: "Seating Arrangement", sub: "Logical reasoning" },
        { id: "re-sy", title: "Syllogism", sub: "Logical reasoning" },
        { id: "re-sp", title: "Series Problems", sub: "Logical reasoning" }
      ]
    },
    Verbal: {
      subs: ["English verbal"],
      topics: [
        { id: "ve-gr", title: "Grammar", sub: "English verbal" },
        { id: "ve-vo", title: "Vocabulary", sub: "English verbal" },
        { id: "ve-rc", title: "Reading Comprehension", sub: "English verbal" },
        { id: "ve-sc", title: "Sentence Correction", sub: "English verbal" },
        { id: "ve-ed", title: "Error Detection", sub: "English verbal" }
      ]
    },
    Technical: {
      subs: ["DSA", "DBMS", "OOPS", "OS", "CN"],
      topics: [
        // DSA
        { id: "tech-arr", title: "Arrays", sub: "DSA" },
        { id: "tech-str", title: "Strings", sub: "DSA" },
        { id: "tech-ll", title: "Linked List", sub: "DSA" },
        { id: "tech-stk", title: "Stack", sub: "DSA" },
        { id: "tech-que", title: "Queue", sub: "DSA" },
        { id: "tech-tree", title: "Trees", sub: "DSA" },
        { id: "tech-grp", title: "Graphs", sub: "DSA" },
        { id: "tech-rec", title: "Recursion", sub: "DSA" },
        { id: "tech-dp", title: "Dynamic Programming", sub: "DSA" },
        { id: "tech-search", title: "Searching", sub: "DSA" },
        { id: "tech-sort", title: "Sorting", sub: "DSA" },
        // DBMS
        { id: "tech-er", title: "ER Diagram", sub: "DBMS" },
        { id: "tech-keys", title: "Keys", sub: "DBMS" },
        { id: "tech-norm", title: "Normalization", sub: "DBMS" },
        { id: "tech-sql", title: "SQL Queries", sub: "DBMS" },
        { id: "tech-tx", title: "Transactions & ACID", sub: "DBMS" },
        { id: "tech-idx", title: "Indexing", sub: "DBMS" },
        { id: "tech-join", title: "Joins", sub: "DBMS" },
        // OOPS
        { id: "oops-cls", title: "Class & Object", sub: "OOPS" },
        { id: "oops-enc", title: "Encapsulation", sub: "OOPS" },
        { id: "oops-inh", title: "Inheritance", sub: "OOPS" },
        { id: "oops-poly", title: "Polymorphism", sub: "OOPS" },
        { id: "oops-abs", title: "Abstraction", sub: "OOPS" },
        // OS
        { id: "os-proc", title: "Process & Thread", sub: "OS" },
        { id: "os-sched", title: "CPU Scheduling", sub: "OS" },
        { id: "os-dead", title: "Deadlock", sub: "OS" },
        { id: "os-mem", title: "Memory Management", sub: "OS" },
        // CN
        { id: "cn-osi", title: "OSI Model", sub: "CN" },
        { id: "cn-tcp", title: "TCP/IP & HTTP", sub: "CN" },
        { id: "cn-dns", title: "DNS", sub: "CN" },
        { id: "cn-route", title: "Routing Protocols", sub: "CN" }
      ]
    }
  };

  // Find active topic details from db
  const currentCategoryObj = ROADMAPS[selectedCategory];
  const activeTopicRegistry = currentCategoryObj.topics.find(t => t.id === activeTopicId) || currentCategoryObj.topics[0];
  const activeTopicDb = topics.find(t => t.id === activeTopicId);

  // Heuristic mock topic builder in case topic data is missing in predefined lists
  const activeTopic: PreparationTopic = activeTopicDb || {
    id: activeTopicRegistry.id,
    title: activeTopicRegistry.title,
    category: selectedCategory,
    subCategory: activeTopicRegistry.sub,
    theory: `Welcome to the learning module for ${activeTopicRegistry.title}.

Overview:
This section covers foundational principles, industry application models, and quick logic puzzles associated with ${activeTopicRegistry.title}. Mastering these parameters will streamline your screening performance during live campus placements.

Core Concepts:
1. Core Definition: Understanding structure limits and memory/logical overhead.
2. Direct Applications: Solving real-world developer problems (time and space complexities).
3. Formulas: Standard equations and algorithms.`,
    notes: [
      `Key Equation: Always double check boundary scenarios or empty states.`,
      `Practice Tip: Practice writing out code logic on paper before compiling.`,
      `Important Limit: Optimize loops in nested conditions.`
    ],
    videoLinks: [
      { title: `Mastering ${activeTopicRegistry.title} Complete tutorial`, url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }
    ],
    practiceQuestions: [
      {
        question: `What is the key approach to optimize ${activeTopicRegistry.title} tasks?`,
        answer: "By utilizing dynamic caches or memoized structures to skip duplicate computations.",
        hint: "Consider using hash maps or array lookup tables."
      }
    ],
    quiz: [
      {
        id: `q-mock-${activeTopicRegistry.id}-1`,
        question: `Which of the following describes the optimal state management for ${activeTopicRegistry.title}?`,
        options: ["Static linear allocation", "Dynamic caching", "Bypassing index memory completely", "Recursive stack loading"],
        correctOptionIndex: 1,
        explanation: "Dynamic caching tracks previous branches, reducing duplicate lookups."
      }
    ]
  };

  // Trigger AI Expanded study planner helper
  const handleAIExpandStudyNotes = async () => {
    setAiGenerating(true);
    setAiExpandedNotes(null);
    try {
      const response = await fetch("/api/ai/career-guidance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          skills: student.skills,
          cgpa: student.cgpa,
          interests: `Detailed notes study guide on ${activeTopic.title} (${selectedCategory})`
        })
      });
      const data = await response.json();
      if (response.ok && data.learningFocus) {
        setAiExpandedNotes(`💡 AI Generated Focus Guide for ${activeTopic.title}:
1. Recommended Prep: ${data.immediateAdvice || "Master core foundations."}
2. Key Areas to Target:
${data.learningFocus.map((f: string, idx: number) => `   - ${idx + 1}. ${f}`).join("\n")}
3. Placement Suitability: Suitable for core roles like ${data.recommendedRoles?.[0]?.role || "Software Engineer"}.`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setAiGenerating(false);
    }
  };

  // Start Topic Quiz
  const startQuiz = () => {
    setQuizRunning(true);
    setCurrentQuestionIdx(0);
    setSelectedAnswerIdx(null);
    setQuizAnswers([]);
    setQuizFinished(false);
    setQuizScore(0);
  };

  const handleSelectAnswer = (idx: number) => {
    setSelectedAnswerIdx(idx);
  };

  const navigateNextQuestion = async () => {
    if (selectedAnswerIdx === null) return;

    // Check accuracy
    const activeQuestion = activeTopic.quiz[currentQuestionIdx];
    const isCorrect = selectedAnswerIdx === activeQuestion.correctOptionIndex;
    const nextScore = isCorrect ? quizScore + 1 : quizScore;
    setQuizScore(nextScore);

    const updatedAnswers = [...quizAnswers, selectedAnswerIdx];
    setQuizAnswers(updatedAnswers);

    if (currentQuestionIdx + 1 < activeTopic.quiz.length) {
      setCurrentQuestionIdx(currentQuestionIdx + 1);
      setSelectedAnswerIdx(null);
    } else {
      // Quiz completed! Save score on server
      setQuizFinished(true);
      setQuizRunning(false);
      await onSaveQuizScore(activeTopic.id, nextScore, activeTopic.quiz.length);
    }
  };

  const completed = student.progress?.[activeTopic.id] || false;

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6" id="prep_dashboard">
      
      {/* Tab: Left sidebar navigation mapping Categories */}
      <div className="xl:col-span-3 space-y-4 print:hidden">
        
        {/* Category buttons */}
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-4 shadow-sm space-y-1">
          {["Aptitude", "Reasoning", "Verbal", "Technical"].map((cat: any) => (
            <button
              key={cat}
              id={`cat_tab_${cat}`}
              onClick={() => {
                setSelectedCategory(cat);
                const subForCat = ROADMAPS[cat].subs[0];
                setSelectedSub(subForCat);
                // Auto focus first topic
                const firstId = ROADMAPS[cat].topics[0].id;
                setActiveTopicId(firstId);
                setQuizRunning(false);
                setQuizFinished(false);
                setAiExpandedNotes(null);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-lg text-xs font-bold transition flex items-center justify-between ${
                selectedCategory === cat
                  ? "bg-indigo-600 text-white"
                  : "text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60"
              }`}
            >
              <span>{cat} Prep Roadmap</span>
              <ArrowRight className="h-3.5 w-3.5 opacity-60" />
            </button>
          ))}
        </div>

        {/* Nested Topic Selector Lists based on focused Categories */}
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-4 shadow-sm space-y-3">
          <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-1">Roadmap Modules</h4>
          
          <div className="space-y-1 max-h-[50vh] overflow-y-auto custom-scrollbar">
            {ROADMAPS[selectedCategory].topics.map(topic => {
              const isCurrent = topic.id === activeTopicId;
              const isTopicCompleted = student.progress?.[topic.id];
              const scoreCard = student.quizScores?.[topic.id];

              return (
                <button
                  key={topic.id}
                  id={`topic_btn_${topic.id}`}
                  onClick={() => {
                    setActiveTopicId(topic.id);
                    setQuizRunning(false);
                    setQuizFinished(false);
                    setRevealedPractice({});
                    setAiExpandedNotes(null);
                  }}
                  className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition flex items-center justify-between ${
                    isCurrent
                      ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 font-bold border-l-4 border-indigo-600"
                      : "text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/30"
                  }`}
                >
                  <div className="flex items-center space-x-2 truncate">
                    <CheckCircle className={`h-4 w-4 shrink-0 ${isTopicCompleted ? "text-emerald-500" : "text-gray-300"}`} />
                    <span className="truncate">{topic.title}</span>
                  </div>
                  {scoreCard && (
                    <span className="text-[9px] font-mono bg-indigo-100/50 dark:bg-indigo-950 px-1 rounded text-indigo-700 dark:text-indigo-300 font-bold">
                      {scoreCard.score}/{scoreCard.total}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Panel: Center/Right Study Content boards */}
      <div className="xl:col-span-9 space-y-6">
        
        {/* Dynamic Quiz modal interface */}
        {quizRunning ? (
          <div className="bg-white dark:bg-gray-800 border border-indigo-200 dark:border-indigo-950 rounded-xl p-6 shadow-md space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-2 py-0.5 rounded-full font-mono">
                  TOPIC QUIZ ACTIVE
                </span>
                <h3 className="font-bold text-gray-950 dark:text-white text-base mt-1">
                  Question {currentQuestionIdx + 1} of {activeTopic.quiz.length}
                </h3>
              </div>
              <button
                id="quit_quiz_btn"
                onClick={() => setQuizRunning(false)}
                className="text-xs text-gray-400 hover:text-gray-600 underline font-sans"
              >
                Quit Quiz
              </button>
            </div>

            {/* Range Progress */}
            <div className="w-full bg-gray-150 dark:bg-gray-700 h-1 rounded-full">
              <div
                className="bg-indigo-600 h-1 rounded-full transition-all"
                style={{ width: `${((currentQuestionIdx + 1) / activeTopic.quiz.length) * 100}%` }}
              ></div>
            </div>

            <div className="space-y-4">
              <p className="font-semibold text-gray-900 dark:text-white text-sm leading-snug">
                {activeTopic.quiz[currentQuestionIdx].question}
              </p>

              <div className="space-y-2">
                {activeTopic.quiz[currentQuestionIdx].options.map((option, oidx) => {
                  const isSelected = selectedAnswerIdx === oidx;
                  return (
                    <button
                      key={oidx}
                      id={`quiz_opt_${oidx}`}
                      onClick={() => handleSelectAnswer(oidx)}
                      className={`w-full text-left p-3 rounded-xl border text-xs transition flex items-center justify-between ${
                        isSelected
                          ? "bg-indigo-50/60 dark:bg-indigo-950/30 border-indigo-300 text-indigo-900 dark:text-indigo-300 font-semibold"
                          : "bg-gray-50/50 dark:bg-gray-750 border-gray-150 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50"
                      }`}
                    >
                      <span>{option}</span>
                      <div className={`h-4.5 w-4.5 rounded-full border-2 flex items-center justify-center ${
                        isSelected ? "border-indigo-600 bg-indigo-600 text-white" : "border-gray-300"
                      }`}>
                        {isSelected && <span className="h-1.5 w-1.5 bg-white rounded-full"></span>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                id="quiz_next_btn"
                onClick={navigateNextQuestion}
                disabled={selectedAnswerIdx === null}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white font-semibold text-xs py-2 px-5 rounded-lg transition"
              >
                {currentQuestionIdx + 1 === activeTopic.quiz.length ? "Submit & Finish" : "Next Question"}
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-6 shadow-sm space-y-6">
            
            {/* Header: Topic Title & controls */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-3 border-b border-gray-50 dark:border-gray-750">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-[9px] bg-slate-100 dark:bg-gray-750 text-gray-500 font-sans px-2 py-0.5 rounded-full uppercase tracking-wider font-bold">
                    {selectedCategory} Roadmap • {activeTopic.subCategory}
                  </span>
                  <span className="text-[9px] text-indigo-600 dark:text-indigo-400 font-semibold">
                    Estimated 45m Study
                  </span>
                </div>
                <h2 className="text-xl font-bold tracking-tight text-gray-950 dark:text-white">{activeTopic.title}</h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  id="toggle_complete_topic"
                  onClick={async () => {
                    await onToggleCompleteIndex(activeTopic.id);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition inline-flex items-center space-x-1.5 ${
                    completed
                      ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border-emerald-200"
                      : "bg-white hover:bg-gray-50 text-gray-600 border-gray-100 dark:bg-gray-750 dark:hover:bg-gray-700 dark:text-white"
                  }`}
                >
                  <CheckCircle className={`h-4 w-4 ${completed ? "text-emerald-500 fill-emerald-500/20" : "text-gray-300"}`} />
                  <span>{completed ? "Completed module" : "Mark Completed"}</span>
                </button>

                <button
                  id="launch_topic_quiz"
                  onClick={startQuiz}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold py-1.5 px-3 rounded-lg shadow-sm font-sans flex items-center space-x-1"
                >
                  <Award className="h-4 w-4" />
                  <span>Take Module Quiz</span>
                </button>
              </div>
            </div>

            {/* Score alerts if already took quiz */}
            {student.quizScores?.[activeTopic.id] && (
              <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/10 border border-emerald-200/50 dark:border-emerald-800/20 rounded-xl flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-400 font-sans">
                <div className="flex items-center space-x-2">
                  <Award className="h-4 w-4" />
                  <span>You took the {activeTopic.title} quiz successfully!</span>
                </div>
                <span className="font-extrabold text-sm">{student.quizScores[activeTopic.id].score} / {student.quizScores[activeTopic.id].total} Correct</span>
              </div>
            )}

            {/* Quick action: AI expanded note builder */}
            <div className="p-4 bg-indigo-50/40 dark:bg-indigo-950/20 rounded-xl border border-indigo-150/40 dark:border-indigo-900/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1 flex-1">
                <h4 className="font-bold text-indigo-900 dark:text-indigo-400 text-xs flex items-center space-x-1.5">
                  <Sparkles className="h-4 w-4 text-indigo-600 animate-pulse" />
                  <span>AI Learning Optimizer</span>
                </h4>
                <p className="text-[11px] text-indigo-950/70 dark:text-indigo-200/80 leading-relaxed font-sans">
                  Generate customized placement study notes, focus topics, and cheat-sheets powered by Gemini based on your skills.
                </p>
              </div>
              <button
                id="btn_ai_study_expand"
                onClick={handleAIExpandStudyNotes}
                disabled={aiGenerating}
                className="bg-white text-indigo-950 text-xs font-bold py-1.5 px-3.5 border rounded-lg transition shrink-0 flex items-center space-x-1"
              >
                <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
                <span>{aiGenerating ? "Generating Guide..." : "AI Generate Notes"}</span>
              </button>
            </div>

            {/* Display AI Expanded planner response */}
            {aiExpandedNotes && (
              <div className="p-4 bg-slate-900 dark:bg-gray-800 border border-gray-800 dark:border-gray-700 rounded-xl text-xs space-y-2 relative">
                <span className="text-[9px] bg-indigo-600 text-white font-mono font-bold px-2 py-0.5 rounded absolute right-3 top-3">
                  AI NOTES INSIGHT
                </span>
                <pre className="text-indigo-300 whitespace-pre-wrap font-sans leading-relaxed text-xs">
                  {aiExpandedNotes}
                </pre>
              </div>
            )}

            {/* Theory panel */}
            <div className="space-y-3 font-sans">
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 text-gray-400" />
                <h3 className="font-bold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Concept Theory</h3>
              </div>
              <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap bg-gray-50 dark:bg-gray-750/30 p-4 rounded-xl border dark:border-gray-700/60 pl-4">
                {activeTopic.theory}
              </p>
            </div>

            {/* Quick formulas Notes */}
            <div className="space-y-3 font-sans">
              <h3 className="font-bold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Quick cheat notes</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                {activeTopic.notes?.map((note, i) => (
                  <li key={i} className="p-3 bg-gray-50/50 dark:bg-gray-750 border rounded-lg pl-3 relative border-l-4 border-l-indigo-600 text-gray-600 dark:text-gray-300">
                    {note}
                  </li>
                ))}
              </ul>
            </div>

            {/* Practice problems */}
            <div className="space-y-3 font-sans">
              <h3 className="font-bold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Practice Exercise</h3>
              <div className="space-y-3">
                {activeTopic.practiceQuestions?.map((pq, i) => {
                  const revealed = revealedPractice[i] || false;
                  return (
                    <div key={i} className="p-4 border border-gray-100 dark:border-gray-700 rounded-xl space-y-3">
                      <div className="flex items-start justify-between">
                        <span className="font-semibold text-xs text-gray-900 dark:text-white leading-relaxed">
                          Q{i+1}: {pq.question}
                        </span>
                        <button
                          id={`reveal_ans_${i}`}
                          onClick={() => setRevealedPractice(prev => ({ ...prev, [i]: !revealed }))}
                          className="text-xs text-indigo-600 hover:underline font-semibold pr-1 shrink-0"
                        >
                          {revealed ? "Hide Solution" : "Reveal Solution"}
                        </button>
                      </div>

                      {revealed && (
                        <div className="p-3 bg-indigo-50/30 dark:bg-indigo-950/20 border-l-4 border-l-indigo-600 rounded text-xs space-y-1 pl-3 transition-all">
                          <p className="font-bold text-indigo-950 dark:text-indigo-400">Answer:</p>
                          <p className="text-gray-700 dark:text-gray-300 font-semibold">{pq.answer}</p>
                          {pq.hint && (
                            <p className="text-[11px] text-gray-400 italic pt-1">💡 Hint: {pq.hint}</p>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Embedded video links */}
            {activeTopic.videoLinks?.length > 0 && (
              <div className="space-y-3 border-t dark:border-gray-750 pt-5 font-sans">
                <h4 className="font-bold text-gray-900 dark:text-white text-xs uppercase tracking-wider flex items-center space-x-1.5 text-gray-500">
                  <Video className="h-4 w-4 shrink-0 text-red-500" />
                  <span>Curated Video Lessons</span>
                </h4>
                <div className="flex flex-wrap gap-2 pt-1">
                  {activeTopic.videoLinks.map((link, idx) => (
                    <a
                      key={idx}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-red-50 dark:bg-red-950/20 hover:bg-red-100 border border-red-200/50 dark:border-red-900/30 text-red-600 dark:text-red-400 text-xs px-3.5 py-2 rounded-xl transition inline-flex items-center space-x-1.5"
                    >
                      <Play className="h-3.5 w-3.5 fill-red-600" />
                      <span className="font-medium">{link.title}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
