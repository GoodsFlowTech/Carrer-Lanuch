import React, { useState } from "react";
import { Search, MapPin, Briefcase, Calendar, Check, Star, Lock, AlertTriangle, RefreshCw, Layers } from "lucide-react";
import { Job, Student } from "../types";

interface JobsSectionProps {
  student: Student;
  jobs: Job[];
  onApply: (jobId: string) => Promise<boolean>;
  onToggleSave: (jobId: string) => Promise<boolean>;
  onReload: () => void;
}

export function JobsSection({ student, jobs, onApply, onToggleSave, onReload }: JobsSectionProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [locFilter, setLocFilter] = useState("");
  const [showAppliedOnly, setShowAppliedOnly] = useState(false);
  
  const [selectedJob, setSelectedJob] = useState<Job | null>(jobs[0] || null);
  const [submitting, setSubmitting] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Derive unique companies & locations for dropdown filters
  const uniqueLocations = Array.from(new Set(jobs.map(j => j.location)));

  // Filter logic
  const filteredJobs = jobs.filter(j => {
    const matchesSearch = j.company.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          j.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          j.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === "" || j.role.toLowerCase().includes(roleFilter.toLowerCase());
    const matchesLoc = locFilter === "" || j.location.includes(locFilter);
    const matchesApplied = !showAppliedOnly || j.applied;

    return matchesSearch && matchesRole && matchesLoc && matchesApplied;
  });

  const handleApply = async (jobId: string) => {
    setSubmitting(jobId);
    setErrorMessage(null);
    try {
      const res = await fetch(`/api/jobs/${jobId}/apply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${student.id}`
        }
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.error || "Failed to submit application.");
      } else {
        onReload();
        // Update selected job details with applied state
        if (selectedJob && selectedJob.id === jobId) {
          setSelectedJob({ ...selectedJob, applied: true });
        }
      }
    } catch (e) {
      setErrorMessage("Network error during application process.");
    } finally {
      setSubmitting(null);
    }
  };

  const handleSave = async (jobId: string) => {
    try {
      const success = await onToggleSave(jobId);
      if (success) {
        onReload();
        if (selectedJob && selectedJob.id === jobId) {
          setSelectedJob({ ...selectedJob, saved: !selectedJob.saved });
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6" id="jobs_view_section">
      {/* Header and filters */}
      <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 p-5 rounded-xl shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
              <Briefcase className="h-5 w-5 text-indigo-600" />
              <span>Campus Placement Hub</span>
            </h2>
            <p className="text-xs text-gray-400">Apply to verified college recruitment drives and internships</p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => { onReload(); setErrorMessage(null); }}
              className="p-1.5 hover:bg-gray-50 border rounded-lg dark:hover:bg-gray-750 text-gray-500"
              title="Refresh jobs panel"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            <label className="flex items-center space-x-1 text-xs text-gray-500 cursor-pointer">
              <input
                type="checkbox"
                checked={showAppliedOnly}
                onChange={() => setShowAppliedOnly(!showAppliedOnly)}
                className="rounded text-indigo-600 focus:ring-indigo-500 font-sans"
              />
              <span>Show Applied Only</span>
            </label>
          </div>
        </div>

        {/* Filters Panel Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Search bar */}
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
            <input
              id="job_search_input"
              type="text"
              placeholder="Search roles, skills, companies..."
              className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 pl-9 pr-4 py-2 rounded-xl text-sm leading-tight focus:ring-2 focus:ring-indigo-500 text-gray-900 dark:text-white"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Location Selector */}
          <select
            id="job_loc_filter"
            className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 text-gray-900 dark:text-white"
            value={locFilter}
            onChange={e => setLocFilter(e.target.value)}
          >
            <option value="">All Locations</option>
            {uniqueLocations.map((loc, i) => (
              <option key={i} value={loc}>{loc}</option>
            ))}
          </select>

          {/* Role Filter presets */}
          <select
            id="job_role_filter"
            className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 text-gray-900 dark:text-white"
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
          >
            <option value="">All Roles</option>
            <option value="software">Software Engineer</option>
            <option value="cloud">Cloud Support</option>
            <option value="consultant">Technical Consultant</option>
          </select>
        </div>
      </div>

      {/* Main Splits Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Job Cards Grid (List) */}
        <div className="lg:col-span-5 space-y-3">
          {filteredJobs.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-gray-800 border rounded-xl">
              <Briefcase className="h-10 w-10 text-gray-300 mx-auto" />
              <p className="text-sm text-gray-500 mt-2 font-sans">No matching placement openings found.</p>
            </div>
          ) : (
            filteredJobs.map(job => {
              const eligible = student.cgpa >= job.eligibilityCgpa;
              const isSelected = selectedJob?.id === job.id;

              return (
                <div
                  key={job.id}
                  onClick={() => { setSelectedJob(job); setErrorMessage(null); }}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 relative ${
                    isSelected
                      ? "bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-300 dark:border-indigo-950"
                      : "bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700 hover:shadow-sm"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex space-x-3">
                      <img
                        src={job.logoUrl || "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=100&h=100&fit=crop&q=80"}
                        className="h-9 w-9 rounded-lg object-cover bg-gray-50 dark:bg-gray-700"
                        alt={job.company}
                      />
                      <div>
                        <h4 className="font-bold text-gray-950 dark:text-white text-sm leading-tight">{job.role}</h4>
                        <p className="text-xs text-gray-500">{job.company}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); handleSave(job.id); }}
                      className="p-1 text-gray-400 hover:text-amber-500"
                    >
                      <Star className={`h-4.5 w-4.5 ${job.saved ? "fill-amber-400 text-amber-400" : ""}`} />
                    </button>
                  </div>

                  {/* Badges row */}
                  <div className="flex flex-wrap items-center gap-1.5 text-[9px] font-mono">
                    <span className="bg-slate-100 dark:bg-gray-750 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-full font-semibold">
                      {job.salary}
                    </span>
                    <span className="bg-indigo-100/50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 px-2 py-0.5 rounded-full">
                      {job.location}
                    </span>
                    {job.applied ? (
                      <span className="bg-emerald-500 text-white font-semibold tracking-wide px-2 py-0.5 rounded-full flex items-center space-x-0.5">
                        <Check className="h-2.5 w-2.5" />
                        <span>APPLIED</span>
                      </span>
                    ) : eligible ? (
                      <span className="bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
                        CGPA ok
                      </span>
                    ) : (
                      <span className="bg-red-50 dark:bg-red-950/20 text-red-600 px-2 py-0.5 rounded-full font-bold flex items-center space-x-0.5">
                        <Lock className="h-2.5 w-2.5" />
                        <span>CGPA &lt; {job.eligibilityCgpa}</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Active Job Details (Focused Preview) */}
        <div className="lg:col-span-7">
          {selectedJob ? (
            <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-6 shadow-sm space-y-6">
              
              {/* Error messages if ineligible */}
              {errorMessage && (
                <div className="p-4 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-xl text-xs flex items-start space-x-2">
                  <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Company banner area */}
              <div className="flex justify-between items-start gap-4">
                <div className="flex space-x-4">
                  <img
                    src={selectedJob.logoUrl || "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=100&h=100&fit=crop&q=80"}
                    className="h-14 w-14 rounded-xl object-cover bg-gray-50 border shadow-sm"
                    alt={selectedJob.company}
                  />
                  <div className="space-y-1">
                    <h3 className="font-extrabold text-gray-900 dark:text-white text-lg tracking-tight leading-tight">{selectedJob.role}</h3>
                    <p className="text-sm text-gray-500 font-sans">{selectedJob.company} • {selectedJob.location}</p>
                    <div className="flex items-center space-x-4 text-xs font-mono text-gray-400 pt-1">
                      <span className="bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded text-[10px]">
                        {selectedJob.salary}
                      </span>
                      <span>CTC Package</span>
                    </div>
                  </div>
                </div>

                {/* Apply/Saved controls */}
                <div className="flex flex-col items-end space-y-2">
                  <button
                    id={`apply_btn_${selectedJob.id}`}
                    onClick={() => handleApply(selectedJob.id)}
                    disabled={selectedJob.applied || submitting === selectedJob.id}
                    className={`px-5 py-2 rounded-xl text-xs font-bold shadow-sm transition ${
                      selectedJob.applied
                        ? "bg-slate-100 dark:bg-gray-750 text-gray-400 cursor-not-allowed"
                        : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/10"
                    }`}
                  >
                    {submitting === selectedJob.id ? "Applying..." : selectedJob.applied ? "Applied Successfully" : "Apply Drive"}
                  </button>
                  <p className="text-[10px] text-gray-400 font-mono">Deadline: {selectedJob.deadline}</p>
                </div>
              </div>

              <hr className="border-gray-100 dark:border-gray-750" />

              {/* Eligibility stats */}
              <div className="grid grid-cols-2 gap-4 bg-gray-50 dark:bg-gray-750/50 rounded-xl p-4 text-xs">
                <div>
                  <span className="text-gray-400 font-mono block">Required Performance</span>
                  <span className="font-bold text-gray-800 dark:text-white font-mono text-sm">
                    {selectedJob.eligibilityCgpa || 6.0} CGPA Minimal
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 font-mono block">Your Active GPA</span>
                  <span className={`font-extrabold font-mono text-sm ${student.cgpa >= selectedJob.eligibilityCgpa ? "text-emerald-500" : "text-red-500"}`}>
                    {student.cgpa || 0} CGPA
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 dark:text-white text-sm">Role Summary</h4>
                <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed font-sans">
                  {selectedJob.description}
                </p>
              </div>

              {/* Requirements */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 dark:text-white text-sm">Key Requirements</h4>
                <ul className="list-disc list-inside text-xs text-gray-600 dark:text-gray-300 leading-relaxed space-y-1 pl-1 font-sans">
                  {selectedJob.requirements?.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>

              {/* Application Tracking Pipeline */}
              {selectedJob.applied && (
                <div className="border-t dark:border-gray-750 pt-5 space-y-3">
                  <h4 className="font-bold text-gray-900 dark:text-white text-sm flex items-center space-x-1.5">
                    <Layers className="h-4 w-4 text-indigo-600" />
                    <span>Hiring Progress Status</span>
                  </h4>
                  <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-sans font-semibold pt-1">
                    <div className="p-2 border rounded-lg bg-indigo-50 dark:bg-indigo-950/30 border-indigo-200 dark:border-indigo-900 text-indigo-700 dark:text-indigo-400">
                      Step 1: Applied
                    </div>
                    <div className="p-2 border rounded-lg bg-gray-50 dark:bg-gray-750 text-gray-400">
                      Step 2: Resume Review
                    </div>
                    <div className="p-2 border rounded-lg bg-gray-50 dark:bg-gray-750 text-gray-400">
                      Step 3: Interview Call
                    </div>
                    <div className="p-2 border rounded-lg bg-gray-50 dark:bg-gray-750 text-gray-400">
                      Step 4: Final Offer
                    </div>
                  </div>
                </div>
              )}

            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 border p-12 text-center rounded-xl">
              <Briefcase className="h-12 w-12 text-gray-350 mx-auto" />
              <p className="text-sm text-gray-500 mt-2 font-sans">Select any recruitment drive on the left to inspect details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
