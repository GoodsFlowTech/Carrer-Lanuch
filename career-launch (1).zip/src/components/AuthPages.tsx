import React, { useState } from "react";
import { LogIn, UserPlus, HelpCircle, KeyRound, Sparkles, CheckCircle, AlertCircle, Laptop } from "lucide-react";
import { Student } from "../types";

interface AuthPagesProps {
  onLoginSuccess: (student: Student, token: string) => void;
}

function getLocalUsers(): any[] {
  const stored = localStorage.getItem("careerlaunch_users");
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {
      // fallback
    }
  }
  
  // Set up initial list
  const initial = [
    {
      registerNo: "2022CS1001",
      password: "password123",
      student: {
        id: "student-123",
        registerNo: "2022CS1001",
        name: "Akshaya Sri",
        email: "akshayasriharini@gmail.com",
        department: "Computer Science & Engineering",
        cgpa: 8.5,
        skills: ["React", "JavaScript", "Python", "Data Structures"],
        graduationYear: 2026,
        profileCompleted: 85,
        role: "student",
        savedJobs: [],
        jobApplications: [],
        internshipApplications: [],
        progress: { "apt-num": true, "tech-arr": false },
        quizScores: {
          "apt-num": { score: 2, total: 2, date: "2026-06-08" }
        },
        resume: {
          title: "Full Stack Engineer Resume",
          name: "Akshaya Sri",
          email: "akshayasriharini@gmail.com",
          phone: "+91 9876543210",
          linkedin: "linkedin.com/in/akshaya-sri",
          github: "github.com/akshaya-sri",
          location: "Chennai, India",
          summary: "Aspiring software developer with core background in modern MERN stacks, data layouts, and algorithmic reasoning.",
          skills: ["React.js", "Node.js", "Express", "TypeScript", "Python", "Tailwind CSS"],
          education: [
            {
              id: "edu-1",
              institution: "Vellore Institute of Technology",
              degree: "B.Tech",
              fieldOfStudy: "Computer Science and Engineering",
              startYear: "2022",
              endYear: "2026",
              grade: "8.5 CGPA"
            }
          ],
          experience: [
            {
              id: "exp-1",
              company: "TechSolutions Corp",
              role: "Web Intern",
              startDate: "Jan 2025",
              endDate: "May 2025",
              description: "Engineered high-performance client dashboards and modular custom state forms.",
              location: "Chennai",
              isRemote: true
            }
          ],
          projects: [
            {
              id: "proj-1",
              title: "CourseLink Dashboard",
              description: "Interactive administrative platform mapping registration progress structures.",
              technologies: ["React", "Tailwind CSS", "Firebase"]
            }
          ],
          certifications: ["AWS Certified Cloud Practitioner", "Google Advanced Analytics Certificate"]
        }
      }
    },
    {
      registerNo: "ADMIN999",
      password: "admin123",
      student: {
        id: "admin-999",
        registerNo: "ADMIN999",
        name: "Placement Coordinator (Admin)",
        email: "admin@careerlaunch.edu",
        department: "Placement Office",
        cgpa: 10.0,
        skills: ["Management"],
        graduationYear: 2026,
        profileCompleted: 100,
        role: "admin",
        savedJobs: [],
        jobApplications: [],
        internshipApplications: []
      }
    }
  ];
  localStorage.setItem("careerlaunch_users", JSON.stringify(initial));
  return initial;
}

export function AuthPages({ onLoginSuccess }: AuthPagesProps) {
  const [view, setView] = useState<"login" | "register" | "forgot">("login");
  
  // Login States
  const [loginRegNo, setLoginRegNo] = useState("");
  const [loginPwd, setLoginPwd] = useState("");
  
  // Register States
  const [regNo, setRegNo] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [dept, setDept] = useState("Computer Science & Engineering");
  const [gradYear, setGradYear] = useState("2026");
  const [regPwd, setRegPwd] = useState("");
  const [regConfirmPwd, setRegConfirmPwd] = useState("");

  // Forgot Password States
  const [forgotReg, setForgotReg] = useState("");
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotNewPwd, setForgotNewPwd] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!loginRegNo || !loginPwd) {
      setError("Please fill in both Register Number and Password.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      try {
        const users = getLocalUsers();
        const matched = users.find(
          (u) =>
            u.registerNo.trim().toUpperCase() === loginRegNo.trim().toUpperCase()
        );
        
        if (!matched) {
          setError("Invalid Register Number.");
          setLoading(false);
          return;
        }
        
        if (matched.password !== loginPwd) {
          setError("Incorrect password.");
          setLoading(false);
          return;
        }
        
        // Success! Pass back student object and use student id as core token matching
        onLoginSuccess(matched.student, matched.student.id);
      } catch (err: any) {
        setError(err.message || "An error occurred during authentication.");
      } finally {
        setLoading(false);
      }
    }, 400);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!regNo || !name || !email || !regPwd || !regConfirmPwd) {
      setError("All fields are strictly required.");
      return;
    }
    if (regPwd !== regConfirmPwd) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      try {
        const users = getLocalUsers();
        const exists = users.some(
          (u) => u.registerNo.trim().toUpperCase() === regNo.trim().toUpperCase()
        );
        if (exists) {
          setError("Register Number is already registered.");
          setLoading(false);
          return;
        }

        const newStudent: Student = {
          id: `student-${Date.now()}`,
          registerNo: regNo.trim(),
          name: name.trim(),
          email: email.trim(),
          department: dept,
          cgpa: 8.0,
          skills: [],
          graduationYear: parseInt(gradYear) || 2026,
          profileCompleted: 20,
          role: "student",
          savedJobs: [],
          jobApplications: [],
          internshipApplications: []
        };

        const updatedUsers = [...users, { registerNo: regNo, password: regPwd, student: newStudent }];
        localStorage.setItem("careerlaunch_users", JSON.stringify(updatedUsers));

        setSuccess("Account registered successfully! Redirecting you into Login view...");
        setTimeout(() => {
          setLoginRegNo(regNo);
          setLoginPwd(regPwd);
          setView("login");
          setSuccess(null);
        }, 1500);
      } catch (err: any) {
        setError(err.message || "Something went wrong.");
      } finally {
        setLoading(false);
      }
    }, 400);
  };

  const handleForgot = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!forgotReg || !forgotEmail || !forgotNewPwd) {
      setError("Please complete all recovery parameters.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      try {
        const users = getLocalUsers();
        const idx = users.findIndex(
          (u) =>
            u.registerNo.trim().toUpperCase() === forgotReg.trim().toUpperCase() &&
            u.student.email.trim().toLowerCase() === forgotEmail.trim().toLowerCase()
        );

        if (idx === -1) {
          setError("No matching credentials.");
          setLoading(false);
          return;
        }

        users[idx].password = forgotNewPwd;
        users[idx].student.email = forgotEmail; // preserve or set
        localStorage.setItem("careerlaunch_users", JSON.stringify(users));

        setSuccess("Password updated cleanly! Going to login view...");
        setTimeout(() => {
          setLoginRegNo(forgotReg);
          setLoginPwd(forgotNewPwd);
          setView("login");
          setSuccess(null);
        }, 1500);
      } catch (err: any) {
        setError(err.message || "No matching credentials.");
      } finally {
        setLoading(false);
      }
    }, 400);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 transition-colors duration-200 px-4 py-12" id="auth_view">
      <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700 p-8 space-y-6">
        
        {/* Portal Branding */}
        <div className="flex flex-col items-center space-y-2 text-center">
          <div className="h-12 w-12 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-600/20 text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold font-sans text-gray-900 dark:text-white tracking-tight">CareerLaunch</h1>
          <p className="text-xs text-gray-500 dark:text-gray-400 font-mono">University Placement Portal</p>
        </div>

        {/* Dynamic State Status Lines */}
        {error && (
          <div className="flex items-center space-x-2 bg-red-50 dark:bg-red-900/20 p-3 rounded-lg border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-sm">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
        {success && (
          <div className="flex items-center space-x-2 bg-green-50 dark:bg-green-900/20 p-3 rounded-lg border border-green-200 dark:border-green-800 text-green-600 dark:text-green-400 text-sm">
            <CheckCircle className="h-4 w-4 shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {/* 1. LOGIN VIEW */}
        {view === "login" && (
          <form className="space-y-4" onSubmit={handleLogin} id="login_form">
            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                REGISTER NUMBER
              </label>
              <input
                id="login_regNo_input"
                type="text"
                placeholder="e.g. 2022CS1001 (or ADMIN999)"
                className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-4 py-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono"
                value={loginRegNo}
                onChange={e => setLoginRegNo(e.target.value)}
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 font-sans">
                  PASSWORD
                </label>
                <button
                  type="button"
                  id="forgot_pwd_btn"
                  onClick={() => { setView("forgot"); setError(null); setSuccess(null); }}
                  className="text-xs font-medium text-indigo-600 hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <input
                id="login_pwd_input"
                type="password"
                placeholder="••••••••"
                className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-4 py-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                value={loginPwd}
                onChange={e => setLoginPwd(e.target.value)}
              />
            </div>

            <button
              id="submit_login_btn"
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-medium py-2.5 px-4 rounded-xl text-sm transition shadow-lg shadow-indigo-600/10 flex items-center justify-center space-x-2"
            >
              <LogIn className="h-4 w-4" />
              <span>{loading ? "Authenticating..." : "Sign In"}</span>
            </button>

            <div className="text-center pt-2 text-xs text-gray-500 dark:text-gray-400">
              New to the portal?{" "}
              <button
                type="button"
                id="to_register_btn"
                onClick={() => { setView("register"); setError(null); setSuccess(null); }}
                className="font-semibold text-indigo-600 hover:underline"
              >
                Register Account
              </button>
              <div className="mt-4 p-2.5 bg-yellow-50 dark:bg-yellow-900/10 rounded-lg text-yellow-700 dark:text-yellow-400 border border-yellow-100 dark:border-yellow-900/30 font-mono text-[10px]">
                💡 Setup accounts: Student (2022CS1001 | password123) or Admin (ADMIN999 | admin123)
              </div>
            </div>
          </form>
        )}

        {/* 2. REGISTER VIEW */}
        {view === "register" && (
          <form className="space-y-4" onSubmit={handleRegister} id="register_form">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                  REGISTER NUMBER
                </label>
                <input
                  id="reg_regNo_input"
                  type="text"
                  placeholder="2022CSXXXX"
                  className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-lg text-xs font-mono"
                  value={regNo}
                  onChange={e => setRegNo(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                  FULL NAME
                </label>
                <input
                  id="reg_name_input"
                  type="text"
                  placeholder="Enter Name"
                  className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-lg text-xs"
                  value={name}
                  onChange={e => setName(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                EMAIL ADDRESS
              </label>
              <input
                id="reg_email_input"
                type="email"
                placeholder="name@college.edu"
                className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-lg text-xs"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#475569] dark:text-[#cbd5e1] text-[10px] font-bold tracking-wider mb-1 font-sans">
                  DEPARTMENT
                </label>
                <select
                  id="reg_dept_select"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] text-[#1e293b] dark:text-[#f8fafc] border border-[#e2e8f0] dark:border-[#475569] px-2.5 py-1.5 rounded-lg text-xs"
                  value={dept}
                  onChange={e => setDept(e.target.value)}
                >
                  <option>Computer Science & Engineering</option>
                  <option>Information Technology</option>
                  <option>Electrical & Electronics</option>
                  <option>Electronics & Communication</option>
                  <option>Mechanical Engineering</option>
                </select>
              </div>
              <div>
                <label className="block text-[#475569] dark:text-[#cbd5e1] text-[10px] font-bold tracking-wider mb-1 font-sans">
                  GRAD YEAR
                </label>
                <select
                  id="reg_grad_select"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] text-[#1e293b] dark:text-[#f8fafc] border border-[#e2e8f0] dark:border-[#475569] px-2.5 py-1.5 rounded-lg text-xs font-mono"
                  value={gradYear}
                  onChange={e => setGradYear(e.target.value)}
                >
                  <option>2026</option>
                  <option>2027</option>
                  <option>2028</option>
                  <option>2025</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                  PASSWORD
                </label>
                <input
                  id="reg_pwd_input"
                  type="password"
                  placeholder="••••••••"
                  className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-lg text-xs"
                  value={regPwd}
                  onChange={e => setRegPwd(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                  CONFIRM
                </label>
                <input
                  id="reg_conpwd_input"
                  type="password"
                  placeholder="••••••••"
                  className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-lg text-xs"
                  value={regConfirmPwd}
                  onChange={e => setRegConfirmPwd(e.target.value)}
                />
              </div>
            </div>

            <button
              id="submit_register_btn"
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-medium py-2 px-4 rounded-lg text-xs transition flex items-center justify-center space-x-2"
            >
              <UserPlus className="h-4 w-4" />
              <span>{loading ? "Registering account..." : "Complete Registration"}</span>
            </button>

            <div className="text-center pt-2 text-xs text-gray-500 dark:text-gray-400">
              Already possess an account?{" "}
              <button
                type="button"
                id="back_to_login_btn"
                onClick={() => { setView("login"); setError(null); setSuccess(null); }}
                className="font-semibold text-indigo-600 hover:underline"
              >
                Sign In
              </button>
            </div>
          </form>
        )}

        {/* 3. FORGOT PASSWORD VIEW */}
        {view === "forgot" && (
          <form className="space-y-4" onSubmit={handleForgot} id="forgot_form">
            <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed font-sans mt-1">
              Verify your Register Number and associated Email below to instantly update your password.
            </p>

            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                REGISTER NUMBER
              </label>
              <input
                id="forgot_regNo_input"
                type="text"
                placeholder="2022CS1001"
                className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-4 py-2 rounded-xl text-sm font-mono"
                value={forgotReg}
                onChange={e => setForgotReg(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                REGISTERED EMAIL ADDRESS
              </label>
              <input
                id="forgot_email_input"
                type="email"
                placeholder="akshayasriharini@gmail.com"
                className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-4 py-2 rounded-xl text-sm"
                value={forgotEmail}
                onChange={e => setForgotEmail(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1 font-sans">
                CHOOSE NEW PASSWORD
              </label>
              <input
                id="forgot_newpwd_input"
                type="password"
                placeholder="New Password (min 6 chars)"
                className="w-full bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 px-4 py-2 rounded-xl text-sm"
                value={forgotNewPwd}
                onChange={e => setForgotNewPwd(e.target.value)}
              />
            </div>

            <button
              id="submit_forgot_btn"
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-medium py-2.5 px-4 rounded-xl text-sm transition flex items-center justify-center space-x-2"
            >
              <KeyRound className="h-4 w-4" />
              <span>{loading ? "Verifying..." : "Reset Password"}</span>
            </button>

            <div className="text-center pt-2 text-xs text-gray-500 dark:text-gray-400">
              Remember your details?{" "}
              <button
                type="button"
                id="cancel_forgot_btn"
                onClick={() => { setView("login"); setError(null); setSuccess(null); }}
                className="font-semibold text-indigo-600 hover:underline"
              >
                Back to Sign In
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
}
