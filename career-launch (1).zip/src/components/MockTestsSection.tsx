import React, { useState, useEffect } from "react";
import { Sparkles, Play, Award, Clock, AlertCircle, RefreshCw, CheckCircle, Flag, ChevronLeft, ChevronRight, Check } from "lucide-react";
import { Student, MockTest, Question } from "../types";

interface MockTestsSectionProps {
  student: Student;
  mockTests: MockTest[];
  onSubmitTest: (testId: string, score: number, total: number) => Promise<any>;
}

export function MockTestsSection({ student, mockTests, onSubmitTest }: MockTestsSectionProps) {
  const [activeTestId, setActiveTestId] = useState<string | null>(null);
  
  // Active test states
  const [testQuestions, setTestQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({}); // q_idx -> option_idx
  const [flags, setFlags] = useState<Record<number, boolean>>({});     // q_idx -> flagged
  const [timeRemaining, setTimeRemaining] = useState(0); // in seconds
  
  // Completion states
  const [finished, setFinished] = useState(false);
  const [gradeScore, setGradeScore] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Active ticking timer
  useEffect(() => {
    if (activeTestId && timeRemaining > 0 && !finished) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            // Auto-submit test!
            triggerAutoSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [activeTestId, timeRemaining, finished]);

  const activeTest = mockTests.find(t => t.id === activeTestId);

  const startTestRunner = (testId: string) => {
    const target = mockTests.find(t => t.id === testId);
    if (!target) return;
    
    setActiveTestId(testId);
    setTestQuestions(target.questions);
    setCurrentIdx(0);
    setAnswers({});
    setFlags({});
    setTimeRemaining(target.durationMinutes * 60);
    setFinished(false);
    setGradeScore(0);
  };

  const handleSelectOption = (oidx: number) => {
    setAnswers(prev => ({
      ...prev,
      [currentIdx]: oidx
    }));
  };

  const toggleFlag = () => {
    setFlags(prev => ({
      ...prev,
      [currentIdx]: !prev[currentIdx]
    }));
  };

  const triggerAutoSubmit = async () => {
    setFinished(true);
    let correctCount = 0;
    testQuestions.forEach((q, idx) => {
      if (answers[idx] === q.correctOptionIndex) {
        correctCount += 1;
      }
    });

    setGradeScore(correctCount);
    setIsSubmitting(true);
    try {
      if (activeTestId) {
        await onSubmitTest(activeTestId, correctCount, testQuestions.length);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSubmitting(false);
    }
  };

  const exitRunner = () => {
    setActiveTestId(null);
    setFinished(false);
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="space-y-6" id="mock_tests_view">
      
      {activeTestId ? (
        // ACTIVE TEST RUNNER PANEL
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6" id="mock_test_active_runner">
          
          {/* Question selection sidebar navigator */}
          <div className="xl:col-span-4 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-4 font-sans h-fit">
            <div className="flex items-center justify-between pb-2 border-b">
              <div>
                <h4 className="font-bold text-gray-900 dark:text-white text-sm truncate max-w-[150px]">{activeTest?.title}</h4>
                <p className="text-[10px] text-gray-400">Total {testQuestions.length} questions</p>
              </div>
              <div className="flex items-center space-x-1.5 bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 px-3 py-1 px-1.5 rounded-lg border border-amber-200/50 dark:border-amber-900 font-mono text-xs font-semibold">
                <Clock className="h-4.5 w-4.5 animate-pulse" />
                <span>{finished ? "CLOSED" : formatTimer(timeRemaining)}</span>
              </div>
            </div>

            {/* Questions list grids */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Question navigator</span>
              <div className="grid grid-cols-5 gap-2">
                {testQuestions.map((_, idx) => {
                  const answered = answers[idx] !== undefined;
                  const flagged = flags[idx] || false;
                  const isCurrent = currentIdx === idx;

                  let cardStyle = "bg-gray-50 text-gray-500 border-gray-200";
                  if (answered) cardStyle = "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400";
                  if (flagged) cardStyle = "bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/30 dark:text-amber-400";
                  if (isCurrent) cardStyle = "bg-indigo-600 text-white border-indigo-600 shadow-sm font-bold";

                  return (
                    <button
                      key={idx}
                      id={`nav_q_${idx}`}
                      onClick={() => setCurrentIdx(idx)}
                      className={`h-10 text-xs border rounded-lg transition font-mono ${cardStyle}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Submitter actions checklist */}
            <div className="pt-4 border-t dark:border-gray-750">
              {finished ? (
                <button
                  id="exit_runner_btn"
                  onClick={exitRunner}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 rounded-xl transition"
                >
                  Exit Exam Screen
                </button>
              ) : (
                <button
                  id="final_submit_exam_btn"
                  onClick={triggerAutoSubmit}
                  className="w-full bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold py-2.5 rounded-xl transition shadow shadow-red-600/10"
                >
                  End Exam & Grade
                </button>
              )}
            </div>
          </div>

          {/* Active Question body */}
          <div className="xl:col-span-8 space-y-6">
            
            {finished ? (
              // GRADING RESULTS BOARD
              <div className="bg-white dark:bg-gray-800 border border-emerald-100 rounded-xl p-6 shadow-sm space-y-6" id="test_results_grade_board">
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="h-14 w-14 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
                    <Award className="h-8 w-8" />
                  </div>
                  <h3 className="font-extrabold text-gray-900 dark:text-white text-xl">Assessment Results Finalized!</h3>
                  <p className="text-xs text-gray-500 font-sans max-w-md">Your test scorecard is recorded instantly to your student ledger. Review answers sheet below.</p>
                  
                  <div className="grid grid-cols-3 gap-4 bg-gray-50 dark:bg-gray-750/50 p-4 rounded-xl text-center text-xs w-full max-w-md font-mono">
                    <div>
                      <span className="text-gray-400 block pb-1">Percentage</span>
                      <span className="text-base font-extrabold text-emerald-500">
                        {Math.round((gradeScore / testQuestions.length) * 100)}%
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-400 block pb-1">Scorecard</span>
                      <span className="text-base font-extrabold text-emerald-500">{gradeScore}/{testQuestions.length}</span>
                    </div>
                    <div>
                      <span className="text-gray-400 block pb-1">Status</span>
                      <span className="text-base font-extrabold text-indigo-500 uppercase">COMPLETED</span>
                    </div>
                  </div>
                </div>

                {/* Explanations index */}
                <div className="space-y-4 border-t dark:border-gray-750 pt-5 font-sans">
                  <h4 className="font-bold text-gray-900 dark:text-white text-sm">Exam Explanation & Analytics Review</h4>

                  <div className="space-y-4">
                    {testQuestions.map((q, idx) => {
                      const userAns = answers[idx];
                      const correctAns = q.correctOptionIndex;
                      const isCorrect = userAns === correctAns;

                      return (
                        <div key={idx} className="p-4 border border-gray-100 dark:border-gray-750/70 rounded-xl space-y-2.5">
                          <p className="font-bold text-gray-950 dark:text-white text-xs">Q{idx+1}: {q.question}</p>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                            <div className="p-2 border rounded-lg bg-gray-50 dark:bg-gray-750/40 text-gray-500">
                              Your answer: <span className={`font-semibold ${isCorrect ? "text-emerald-600" : "text-red-500"}`}>
                                {userAns !== undefined ? q.options[userAns] : "[No Answer Submitted]"}
                              </span>
                            </div>
                            <div className="p-2 border border-emerald-200 dark:border-emerald-900/30 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-lg text-emerald-700 dark:text-emerald-400 font-semibold">
                              Correct answer: <span>{q.options[correctAns]}</span>
                            </div>
                          </div>

                          {q.explanation && (
                            <p className="text-[11px] text-gray-400 bg-slate-50 dark:bg-gray-750 p-2.5 rounded-lg border-l-4 border-indigo-500 pl-3">
                              💡 Explanation: {q.explanation}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            ) : (
              // ACTIVE EXAM QUESTION INTERACTION
              <div className="bg-white dark:bg-gray-800 border border-gray-150 dark:border-gray-700 rounded-xl p-6 shadow-sm space-y-6">
                
                {/* Meta details */}
                <div className="flex items-center justify-between pb-3 border-b dark:border-gray-750">
                  <span className="text-[10px] bg-slate-100 dark:bg-gray-750 text-gray-500 font-bold font-mono px-2 py-0.5 rounded-full">
                    QUESTION {currentIdx + 1} OF {testQuestions.length}
                  </span>

                  <button
                    id="flag_current_q"
                    onClick={toggleFlag}
                    className={`text-xs inline-flex items-center space-x-1 font-semibold ${
                      flags[currentIdx] ? "text-amber-500" : "text-gray-400 hover:text-amber-500"
                    }`}
                  >
                    <Flag className={`h-4 w-4 ${flags[currentIdx] ? "fill-amber-400 text-amber-400" : ""}`} />
                    <span>{flags[currentIdx] ? "Flagged for checks" : "Flag Question"}</span>
                  </button>
                </div>

                {/* Question body text */}
                <div className="space-y-5">
                  <h3 className="font-semibold text-gray-950 dark:text-white text-base leading-snug font-sans">
                    {testQuestions[currentIdx]?.question}
                  </h3>

                  {/* Options select */}
                  <div className="space-y-2.5 font-sans">
                    {testQuestions[currentIdx]?.options.map((option, oidx) => {
                      const selected = answers[currentIdx] === oidx;
                      return (
                        <button
                          key={oidx}
                          id={`exam_opt_${oidx}`}
                          onClick={() => handleSelectOption(oidx)}
                          className={`w-full text-left p-3.5 rounded-xl border text-xs transition flex items-center justify-between ${
                            selected
                              ? "bg-indigo-50/50 dark:bg-indigo-950/20 border-indigo-400 text-indigo-900 dark:text-indigo-300 font-bold"
                              : "bg-gray-50/30 dark:bg-gray-750 border-gray-150 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <span className="font-mono text-gray-400 font-bold uppercase">{String.fromCharCode(97 + oidx)}.</span>
                            <span>{option}</span>
                          </div>
                          {selected && <Check className="h-4 w-4 text-indigo-600 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Footer buttons row */}
                <div className="flex justify-between items-center pt-3 border-t dark:border-gray-750">
                  <button
                    id="test_prev_q"
                    onClick={() => setCurrentIdx(prev => Math.max(0, prev - 1))}
                    disabled={currentIdx === 0}
                    className={`text-xs inline-flex items-center space-x-1 font-semibold ${
                      currentIdx === 0 ? "text-gray-300" : "text-gray-500 hover:text-indigo-600"
                    }`}
                  >
                    <ChevronLeft className="h-4.5 w-4.5" />
                    <span>Previous Question</span>
                  </button>

                  <button
                    id="test_next_q"
                    onClick={() => setCurrentIdx(prev => Math.min(testQuestions.length - 1, prev + 1))}
                    disabled={currentIdx + 1 === testQuestions.length}
                    className={`text-xs inline-flex items-center space-x-1 font-semibold ${
                      currentIdx + 1 === testQuestions.length ? "text-gray-300" : "text-gray-500 hover:text-indigo-600"
                    }`}
                  >
                    <span>Next Question</span>
                    <ChevronRight className="h-4.5 w-4.5" />
                  </button>
                </div>

              </div>
            )}

          </div>

        </div>
      ) : (
        // DEFAULT LISTS HOME
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 p-5 rounded-xl shadow-sm space-y-1.5">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
              <Award className="h-5.5 w-5.5 text-indigo-600" />
              <span>Diagnostic Mock Examination Center</span>
            </h2>
            <p className="text-xs text-gray-400">Train against rigorous company specific timelines and logical aptitude assessments</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockTests.map(test => {
              const prevAttemptScore = student.quizScores?.[test.id];

              return (
                <div
                  key={test.id}
                  className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] bg-slate-100 dark:bg-gray-750 text-gray-500 font-bold px-2 py-0.5 rounded uppercase font-mono">
                        {test.category} Examination
                      </span>
                      <span className="text-[10px] text-gray-400 font-mono flex items-center space-x-1">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{test.durationMinutes} Minutes</span>
                      </span>
                    </div>

                    <h3 className="font-extrabold text-gray-950 dark:text-white text-base leading-tight">
                      {test.title}
                    </h3>
                    <p className="text-xs text-gray-500 leading-normal font-sans">
                      Evaluate core concepts including standard recruiter problem structures. Re-tests are permitted.
                    </p>
                    <p className="text-[10px] text-gray-400 font-mono">Exam Parameters: {test.questions.length || 5} MCQs</p>
                  </div>

                  {/* Previous attempt stats */}
                  <div className="pt-2 border-t dark:border-gray-750/70 flex items-center justify-between">
                    {prevAttemptScore ? (
                      <div className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center space-x-1">
                        <CheckCircle className="h-4.5 w-4.5 text-emerald-500" />
                        <span>Best Score: {prevAttemptScore.score}/{prevAttemptScore.total} Correct</span>
                      </div>
                    ) : (
                      <span className="text-[10px] text-gray-400 tracking-wider">NOT ATTEMPTED YET</span>
                    )}

                    <button
                      id={`start_test_${test.id}`}
                      onClick={() => startTestRunner(test.id)}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-1.5 px-4 rounded-lg shadow-sm transition inline-flex items-center space-x-1"
                    >
                      <Play className="h-3 w-3 fill-white" />
                      <span>{prevAttemptScore ? "Retake Exam" : "Start Live"}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
}
