import React, { useState } from "react";
import { 
  Sparkles, CheckCircle2, XCircle, Search, Award, BookOpen, ChevronRight, 
  AlertTriangle, Star, CheckSquare, Square, Zap, Layers, Trophy, Heart 
} from "lucide-react";
import { Student, Job, Internship } from "../types";

interface EligibilityCheckerProps {
  student: Student;
  jobs: Job[];
  internships: Internship[];
}

export function EligibilityChecker({ student, jobs, internships }: EligibilityCheckerProps) {
  // Input simulation overrides
  const [cgpaInput, setCgpaInput] = useState<string>(student.cgpa.toString() || "8.0");
  const [activeSkills, setActiveSkills] = useState<string>(student.skills?.join(", ") || "React, node.js, SQL");
  const [searchTerm, setSearchTerm] = useState("");

  // Sub-tabs: "drives" vs "prep"
  const [checkerTab, setCheckerTab] = useState<"drives" | "prep">("drives");
  const [selectedPrepCompany, setSelectedPrepCompany] = useState<string>("Google");

  // Track completed topics per company using localStorage
  const [completedTopics, setCompletedTopics] = useState<Record<string, string[]>>(() => {
    const saved = localStorage.getItem("careerlaunch_completed_topics");
    return saved ? JSON.parse(saved) : {};
  });

  const handleToggleTopic = (company: string, topicId: string) => {
    setCompletedTopics(prev => {
      const companyTopics = prev[company] || [];
      const updated = companyTopics.includes(topicId)
        ? companyTopics.filter(id => id !== topicId)
        : [...companyTopics, topicId];
      const newState = { ...prev, [company]: updated };
      localStorage.setItem("careerlaunch_completed_topics", JSON.stringify(newState));
      return newState;
    });
  };

  // AI gap analyzer state
  const [isAnalyzingGap, setIsAnalyzingGap] = useState<string | null>(null);
  const [aiGapAnalysis, setAiGapAnalysis] = useState<Record<string, {
    missingSkills: string[];
    certificationAlternative: string[];
    curatedProjectsRecommendations: string[];
    learningResourceKeywords: string[];
  }>>({});

  const numericCgpa = parseFloat(cgpaInput) || 0;
  const parsedSkills = activeSkills.split(",").map(s => s.trim().toLowerCase()).filter(Boolean);

  // Combine jobs and internships for matching eligibility checks
  const allPostings = [
    ...jobs.map(j => ({ ...j, type: "Job" as const })),
    ...internships.map(i => ({ ...i, type: "Internship" as const, eligibilityCgpa: i.eligibilityCgpa || 6.5, salary: i.stipend }))
  ];

  // Map matches
  const checkResults = allPostings.map(post => {
    const cgpaOk = numericCgpa >= post.eligibilityCgpa;
    
    // Check skill requirements
    const matchedSkills: string[] = [];
    const missingSkills: string[] = [];

    post.requirements?.forEach(req => {
      const lowerReq = req.toLowerCase();
      // Look for overlaps
      let found = false;
      parsedSkills.forEach(skill => {
        if (lowerReq.includes(skill) || skill.includes(lowerReq)) {
          found = true;
          if (!matchedSkills.includes(skill)) matchedSkills.push(skill);
        }
      });

      if (!found) {
        missingSkills.push(req);
      }
    });

    const eligibilityPercent = Math.min(
      100,
      Math.round(
        (cgpaOk ? 50 : 10) + 
        (post.requirements && post.requirements.length > 0 
          ? (matchedSkills.length / post.requirements.length) * 50 
          : 50)
      )
    );

    const eligible = cgpaOk && missingSkills.length <= 1; // lenient matching for rating

    return {
      id: post.id,
      company: post.company,
      role: post.role,
      postingType: post.type,
      location: post.location,
      salary: post.salary,
      reqCgpa: post.eligibilityCgpa,
      cgpaOk,
      matchedSkills,
      missingSkills,
      eligibilityPercent,
      eligible
    };
  });

  const filteredResults = checkResults.filter(r => 
    r.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
    r.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRunAiSkillGapCheck = async (company: string, role: string, indexId: string, requiredTechs: string[]) => {
    setIsAnalyzingGap(indexId);
    try {
      const res = await fetch("/api/ai/skill-gap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetCompany: company,
          targetRole: role,
          studentSkills: parsedSkills,
          requiredSkills: requiredTechs
        })
      });
      const data = await res.json();
      if (res.ok) {
        setAiGapAnalysis(prev => ({
          ...prev,
          [indexId]: data
        }));
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzingGap(null);
    }
  };

  const companyPresetData: Record<string, {
    requiredSkills: string[];
    phases: { name: string; desc: string }[];
    topics: { id: string; title: string; rank: "Critical" | "High" | "Medium"; stars: number; desc: string }[];
  }> = {
    Google: {
      requiredSkills: ["Go", "C++", "Python", "Data Structures", "Algorithms", "System Design"],
      phases: [
        { name: "Phase 1: Algorithmic screening analysis", desc: "Focus deeply on asymptotic complexities, nested Big-O analysis, recursion trees, and dynamic programming." },
        { name: "Phase 2: Graph Theory & Combinatorics", desc: "Solve medium/hard graph layouts, recursion, depth first search structures, dynamic memoization." },
        { name: "Phase 3: distributed systems design", desc: "Study distributed services architecture, replication nodes, basic hash tables, and load distribution queues." }
      ],
      topics: [
        { id: "g1", title: "Asymptotic Big-O Analysis & Complexities", rank: "Critical", stars: 3, desc: "Worst-case/best-case bounds, spatial allocations, recursive recurrence trees." },
        { id: "g2", title: "Algorithmic Graph Traversals (DFS/BFS)", rank: "Critical", stars: 3, desc: "Connected nodes, cycle detections, topological sorting arrays." },
        { id: "g3", title: "Dynamic Memoization Pattern Structures", rank: "Critical", stars: 3, desc: "Knapsack, sub-array optimizations, string parsing matching arrays." },
        { id: "g4", title: "Google File System & MapReduce basics", rank: "High", stars: 2, desc: "Distributed sharded blocks, master node architectures, resilient storage." },
        { id: "g5", title: "Memory boundaries, CPU cache alignments", rank: "Medium", stars: 1, desc: "Byte layouts, pointers, stack/heap allocations inside core JVM." }
      ]
    },
    Amazon: {
      requiredSkills: ["Java", "C#", "Object Oriented Design", "System Architecture", "Leadership Principles"],
      phases: [
        { name: "Phase 1: Perfect OOD Design Patterns", desc: "Settle object oriented class paradigms. Brush up concepts of polymorphism, SOLID guidelines, and Factory patterns." },
        { name: "Phase 2: Narrative Leadership alignment", desc: "Amazon values its 16 leadership guidelines. Plan 2 mock stories per principle utilizing standard STAR layout." },
        { name: "Phase 3: Scalable Microservice design", desc: "Plan transactions across distributed DB nodes, ACID guarantees, caching blocks in memory using Redis." }
      ],
      topics: [
        { id: "a1", title: "SOLID Design Guidelines & Patterns", rank: "Critical", stars: 3, desc: "Single-responsibility and interface segregation principles in class design." },
        { id: "a2", title: "STAR Behavioral Strategic Answering Format", rank: "Critical", stars: 3, desc: "Narratives centering Situation, Task, Action, and Quantitative Outcomes." },
        { id: "a3", title: "Load Balancers & In-Memory caching (Redis)", rank: "High", stars: 2, desc: "Proxy, round-robin, content delivery nodes, write-back vs write-through cache." },
        { id: "a4", title: "Relational vs. Non-Relational schemas tradeoff", rank: "High", stars: 2, desc: "Indexing systems, sharding hashes, CAP Theorem constraints." },
        { id: "a5", title: "VPC Subnets & IAM Roles Configurations", rank: "Medium", stars: 1, desc: "Cloud deployment barriers, gateway endpoints, user authorization credentials." }
      ]
    },
    Razorpay: {
      requiredSkills: ["React", "Node.js", "REST APIs", "PostgreSQL", "MongoDB", "Security Foundations"],
      phases: [
        { name: "Phase 1: Advanced UI Lifecycle Controls", desc: "Configure optimized React hook triggers, state synchronizations, and React context memoizations." },
        { name: "Phase 2: Transactional API middle layers", desc: "Create robust custom middleware checking JWT sessions, preventing CORS breaches, rate limiting active paths." },
        { name: "Phase 3: Database Index optimizations", desc: "Fine-tune Postgres execution timelines. Write ACID compliant schemas with double-entry ledgers." }
      ],
      topics: [
        { id: "r1", title: "React State Sync & Lifecycle hooks", rank: "Critical", stars: 3, desc: "Eliminating infinite loops in useEffect hooks, using useTransition, useMemo." },
        { id: "r2", title: "SQL Transaction Blocks (ACID Compliance)", rank: "Critical", stars: 3, desc: "Executing complete commit or rollback pipelines to avoid fintech record leakage." },
        { id: "r3", title: "JWT Authorization Session validation", rank: "High", stars: 2, desc: "Cryptographic signature hashing, bearer patterns, automatic refreshing tokens." },
        { id: "r4", title: "REST API rate limiting safeguards", rank: "High", stars: 2, desc: "Token bucket strategies, IP tracking, CORS protection, status 429 returns." },
        { id: "r5", title: "Redis micro-state sessions", rank: "Medium", stars: 1, desc: "Keeping temporary validation tokens in fast-access lookup maps." }
      ]
    },
    Zoho: {
      requiredSkills: ["Core Java", "Python", "Recursion", "Software Engineering Foundations", "Data Structures"],
      phases: [
        { name: "Phase 1: Pure Algorithmic Nested Loops", desc: "Solving nested matrices, string parsing, sorting structures without leveraging Java standard Collections." },
        { name: "Phase 2: Object-Oriented system schematics", desc: "Model real-world modular structures like dynamic elevators or vehicle booking stations in pure class patterns." },
        { name: "Phase 3: Foundational Database querying", desc: "Suck out query performance, analyze Joins, write stored routines." }
      ],
      topics: [
        { id: "z1", title: "Pure Pointer Array Matrix Manipulation", rank: "Critical", stars: 3, desc: "Traversing custom grids, spiral patterns, custom sort utilities." },
        { id: "z2", title: "System Class Modelling (Elevator/Booking)", rank: "Critical", stars: 3, desc: "Defining interface bounds, property inheritances, robust event loops." },
        { id: "z3", title: "Recursive Backtracking & Tree branch paths", rank: "High", stars: 2, desc: "N-Queens, Sudoku solvers, binary target tree lookup arrays." },
        { id: "z4", title: "Database Normalization & Query plans", rank: "High", stars: 2, desc: "1NF, 2NF, 3NF conversions, query optimization bottlenecks." },
        { id: "z5", title: "Code compression & space optimizations", rank: "Medium", stars: 1, desc: "Reorganizing algorithms to trim garbage collector overheads." }
      ]
    },
    TCS: {
      requiredSkills: ["Java", "Python", "C", "DBMS Concepts", "Aptitude Skills", "Logical Reasoning"],
      phases: [
        { name: "Phase 1: Foundations of Code syntax", desc: "Learn conditional logic, simple arrays, string reversals, bubble sort, basic input streams." },
        { name: "Phase 2: Quantitative speed-distance metrics", desc: "Crack percentage ratios, quick fractions, average scales, logical clock and directions puzzles." },
        { name: "Phase 3: Basic database records", desc: "Understand tables, SELECT filters, aggregate functions, keys." }
      ],
      topics: [
        { id: "t1", title: "Logical Arithmetic speed & averages", rank: "Critical", stars: 3, desc: "Solving speed-distance-time matrices, dynamic ratios within 45 seconds." },
        { id: "t2", title: "Foundational Code structure & syntax parameters", rank: "Critical", stars: 3, desc: "Loops, basic recursion, checking prime numbers, Fibonacci arrays." },
        { id: "t3", title: "RDBMS SELECT query lookups", rank: "High", stars: 2, desc: "WHERE conditions, aggregate GROUP BY routines, simple nested SELECT lines." },
        { id: "t4", title: "Exceptions handling standard wrappers", rank: "High", stars: 2, desc: "Try-catch blocks, final declarations, memory allocation bounds." },
        { id: "t5", title: "Version Control Systems (Git command lines)", rank: "Medium", stars: 1, desc: "Git commit, add, push, pull, simple merge resolution models." }
      ]
    }
  };

  const selectedCompanyData = companyPresetData[selectedPrepCompany] || companyPresetData.Google;
  const companyTopics = completedTopics[selectedPrepCompany] || [];
  const percentMastered = Math.round((companyTopics.length / selectedCompanyData.topics.length) * 100);

  return (
    <div className="space-y-6" id="eligibility_checker_view">
      {/* Simulation form header */}
      <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
              <Award className="h-5.5 w-5.5 text-indigo-600 animate-pulse" />
              <span>Placement Eligibility Portal</span>
            </h2>
            <p className="text-xs text-gray-400">Model test configurations or update your academic ratings to preview qualifying recruiters.</p>
          </div>
          
          {/* Sub tabs selectors */}
          <div className="flex items-center space-x-1.5 p-1 bg-gray-100 dark:bg-gray-750 rounded-xl self-start shrink-0">
            <button
              onClick={() => setCheckerTab("drives")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1 ${
                checkerTab === "drives"
                  ? "bg-white dark:bg-gray-700 text-indigo-600 dark:text-white shadow-sm"
                  : "text-gray-500 hover:text-gray-700 dark:text-gray-400"
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>Qualifying Drives</span>
            </button>
            <button
              onClick={() => setCheckerTab("prep")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1 ${
                checkerTab === "prep"
                  ? "bg-white dark:bg-gray-700 text-indigo-600 dark:text-white shadow-sm"
                  : "text-gray-500 hover:text-gray-700 dark:text-gray-400"
              }`}
            >
              <Trophy className="h-3.5 w-3.5 text-amber-500" />
              <span>Company Preparation Academy</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="eligibility_config_form">
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">DYNAMIC MODEL CGPA</label>
            <input
              id="eligibility_cgpa_model"
              type="number"
              step="0.05"
              min="0"
              max="10"
              className="w-full bg-gray-50 dark:bg-gray-700 border text-gray-900 dark:text-white px-3 py-2 rounded-xl text-xs font-mono font-bold"
              value={cgpaInput}
              onChange={e => setCgpaInput(e.target.value)}
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-gray-500 mb-1">DYNAMIC SKILLS PORTFOLIO (Comma Separated)</label>
            <input
              id="eligibility_skills_model"
              type="text"
              className="w-full bg-gray-50 dark:bg-gray-700 border text-gray-900 dark:text-white px-3 py-2 rounded-xl text-xs font-sans"
              value={activeSkills}
              onChange={e => setActiveSkills(e.target.value)}
            />
          </div>
        </div>
      </div>

      {checkerTab === "drives" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Filter and Listings */}
          <div className="lg:col-span-12 space-y-4">
            <div className="flex items-center justify-between">
              <div className="relative max-w-sm w-full font-sans">
                <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
                <input
                  id="eligibility_search_input"
                  type="text"
                  placeholder="Search eligible drives / roles..."
                  className="w-full bg-white dark:bg-gray-800 border pl-9 pr-4 py-2.5 rounded-xl text-xs"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
              <span className="text-[10px] text-gray-400 font-mono">
                Total Matches: {filteredResults.length} postings evaluated
              </span>
            </div>

            {/* Results rows */}
            <div className="space-y-4">
              {filteredResults.map(res => {
                const gapAnalysisForCard = aiGapAnalysis[res.id];
                const isCheckingGap = isAnalyzingGap === res.id;

                return (
                  <div
                    key={res.id}
                    className={`bg-white dark:bg-gray-800 border rounded-xl p-5 shadow-sm space-y-4 transition ${
                      res.eligible 
                        ? "border-emerald-100 dark:border-emerald-900/30" 
                        : "border-red-100 dark:border-red-955/20"
                    }`}
                  >
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      <div className="flex items-start space-x-3">
                        <div className={`p-2.5 rounded-xl ${res.eligible ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600" : "bg-red-50 dark:bg-red-950/20 text-red-500"}`}>
                          {res.eligible ? <CheckCircle2 className="h-6 w-6" /> : <XCircle className="h-6 w-6" />}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <h4 className="font-bold text-gray-950 dark:text-white text-base leading-tight">
                              {res.company} • {res.role}
                            </h4>
                            <span className="bg-slate-100 dark:bg-gray-750 text-gray-500 text-[9px] px-2 py-0.5 rounded-full font-mono font-bold tracking-wider uppercase">
                              {res.postingType}
                            </span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">Location: {res.location} • Compensation: {res.salary}</p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4 md:text-right font-mono text-xs">
                        <div>
                          <span className="text-gray-400 block text-[10px]">Qualify Rate</span>
                          <span className={`text-base font-extrabold ${res.eligible ? "text-emerald-500" : "text-amber-500"}`}>
                            {res.eligibilityPercent}% Rank
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Requirements checks */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans bg-gray-50 dark:bg-gray-750/30 p-3 rounded-xl">
                      <div className="space-y-1">
                        <span className="font-bold text-gray-400 text-[10px] block uppercase tracking-wider">CGPA REQUIREMENT</span>
                        {res.cgpaOk ? (
                          <p className="text-emerald-600 dark:text-emerald-400 flex items-center space-x-1 font-semibold">
                            <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                            <span>Satisfied ({numericCgpa} &gt;= {res.reqCgpa} minimum requirement)</span>
                          </p>
                        ) : (
                          <p className="text-red-500 dark:text-red-400 flex items-center space-x-1 font-semibold">
                            <XCircle className="h-3.5 w-3.5 shrink-0" />
                            <span>CGPA Deficit ({numericCgpa} is lower than required {res.reqCgpa} barrier)</span>
                          </p>
                        )}
                      </div>

                      <div className="space-y-1 text-xs">
                        <span className="font-bold text-gray-400 text-[10px] block uppercase tracking-wider">SKILLS VALIDATION</span>
                        {res.missingSkills.length === 0 ? (
                          <p className="text-emerald-600 dark:text-emerald-400 flex items-center space-x-1 font-semibold">
                            <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                            <span>All skills fulfilled!</span>
                          </p>
                        ) : (
                          <div className="flex flex-col gap-1 text-gray-600 dark:text-gray-300 pl-4">
                            <p className="text-amber-600 font-medium">Missing/Unmatched expectations:</p>
                            <div className="flex flex-wrap gap-1 mt-0.5">
                              {res.missingSkills.map((sk, i) => (
                                <span key={i} className="bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-200/50 dark:border-amber-950 px-2 py-0.5 rounded text-[10px] font-mono">
                                  {sk}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* AI Bridge Deficits action row */}
                    {!res.eligible && (
                      <div className="border-t dark:border-gray-750/50 pt-3 relative" id="skill_gap_analyzer_block">
                        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                          <p className="text-[11px] text-gray-400 font-sans">
                            You do not currently satisfy qualifying criteria. Let Gemini design a bridging strategy.
                          </p>
                          <button
                            id={`gap_check_${res.id}`}
                            onClick={() => handleRunAiSkillGapCheck(res.company, res.role, res.id, res.missingSkills)}
                            disabled={isCheckingGap}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-indigo-400 text-[10px] font-extrabold px-3.5 py-1.5 rounded-lg shadow-sm transition shrink-0 flex items-center space-x-1"
                          >
                            <Sparkles className="h-3.5 w-3.5 text-indigo-200 animate-pulse" />
                            <span>{isCheckingGap ? "Analyzing with Gemini..." : "Bridge skill Deficit via AI"}</span>
                          </button>
                        </div>

                        {/* Display retrieved AI Gap analysis report */}
                        {gapAnalysisForCard && (
                          <div className="mt-4 p-4 bg-slate-900 border border-gray-800 rounded-xl text-xs space-y-3 font-sans relative">
                            <span className="text-[9px] bg-red-600 text-white font-mono font-bold px-2 py-0.5 rounded absolute right-3 top-3">
                              BRIDGING PLAN
                            </span>

                            <div className="space-y-1 text-slate-100">
                              <h5 className="font-bold text-red-400 flex items-center space-x-1">
                                <AlertTriangle className="h-3.5 w-3.5 text-red-400" />
                                <span>Gap analysis recommendations</span>
                              </h5>
                              <p className="text-slate-300 text-[11px] leading-relaxed font-sans">
                                Focus on completing certifications in <span className="font-mono text-red-300">{gapAnalysisForCard.certificationAlternative?.join(", ") || "Advanced Systems"}</span> to bypass standard screening.
                              </p>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] border-t border-gray-800 pt-2 text-slate-300">
                              <div className="space-y-1">
                                <p className="font-semibold text-slate-200 underline">Recommended portfolio Projects:</p>
                                <ul className="list-disc list-inside space-y-0.5">
                                  {gapAnalysisForCard.curatedProjectsRecommendations?.map((proj, i) => (
                                    <li key={i}>{proj}</li>
                                  ))}
                                </ul>
                              </div>
                              <div className="space-y-1">
                                <p className="font-semibold text-slate-200 underline">Learning Resource Keywords:</p>
                                <div className="flex flex-wrap gap-1 pt-1 font-mono">
                                  {gapAnalysisForCard.learningResourceKeywords?.map((kw, i) => (
                                    <span key={i} className="bg-gray-800 px-1.5 py-0.5 rounded text-[10px]">
                                      {kw}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      ) : (
        /* BRAND NEW: COMPANY PREPARATION & SKILL BENCHMARKS VIEW */
        <div className="space-y-6" id="company_prep_academy_board">
          {/* Company Selection Rail */}
          <div className="bg-white dark:bg-gray-800 border p-4 rounded-xl shadow-sm flex flex-wrap gap-2 items-center">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mr-2">Target Employer:</span>
            {Object.keys(companyPresetData).map((compName) => (
              <button
                key={compName}
                onClick={() => setSelectedPrepCompany(compName)}
                className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${
                  selectedPrepCompany === compName
                    ? "bg-indigo-650 bg-indigo-600 text-white shadow shadow-indigo-650/15"
                    : "bg-gray-50 dark:bg-gray-750 text-gray-600 dark:text-gray-300 hover:bg-gray-100"
                }`}
              >
                {compName}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Skills & Preparation Stages */}
            <div className="lg:col-span-5 space-y-5">
              
              {/* Box 1: Specific Skills Benchmark */}
              <div className="bg-white dark:bg-gray-800 border border-gray-105 rounded-xl p-5 shadow-sm space-y-4">
                <div>
                  <span className="text-[9px] bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                    Skills Audit
                  </span>
                  <h3 className="text-sm font-extrabold text-gray-900 dark:text-white mt-1.5 flex items-center space-x-1">
                    <Zap className="h-4 w-4 text-indigo-500" />
                    <span>Skills Benchmarks for {selectedPrepCompany}</span>
                  </h3>
                  <p className="text-[11px] text-gray-400 mt-1 leading-normal">
                    The specific technical and professional tags required to apply for a placement drive at {selectedPrepCompany}.
                  </p>
                </div>

                <div className="space-y-2.5">
                  {selectedCompanyData.requiredSkills.map((sk, idx) => {
                    const isMatched = parsedSkills.some(p => p.includes(sk.toLowerCase()) || sk.toLowerCase().includes(p));
                    return (
                      <div 
                        key={idx}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition duration-200 ${
                          isMatched 
                            ? "bg-emerald-50/30 dark:bg-emerald-950/10 border-emerald-100 dark:border-emerald-950/20" 
                            : "bg-red-50/25 dark:bg-red-955/5 border-red-50 dark:border-red-950/20"
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          <span className={`h-2 w-2 rounded-full ${isMatched ? "bg-emerald-550 bg-emerald-500" : "bg-red-500"}`} />
                          <span className="font-semibold text-gray-800 dark:text-gray-250">{sk}</span>
                        </div>
                        {isMatched ? (
                          <span className="text-[10px] font-extrabold text-emerald-600 dark:text-emerald-450 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded-full font-sans uppercase">
                            Matched
                          </span>
                        ) : (
                          <span className="text-[10px] font-extrabold text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-950/20 px-2 py-0.5 rounded-full font-sans uppercase">
                            Required
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Box 2: How to Prepare timeline */}
              <div className="bg-white dark:bg-gray-800 border border-gray-105 rounded-xl p-5 shadow-sm space-y-4">
                <div>
                  <span className="text-[9px] bg-amber-55 bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                    Separate Phase Guide
                  </span>
                  <h3 className="text-sm font-extrabold text-gray-900 dark:text-white mt-1.5">
                    How to Prepare Strategy Guideline
                  </h3>
                  <p className="text-[11px] text-gray-400 mt-1 leading-normal">
                    Follow this sequential preparation pipeline to systematically pass {selectedPrepCompany}'s screening benchmarks.
                  </p>
                </div>

                <div className="relative pl-5 border-l border-indigo-100 dark:border-gray-700 space-y-4 py-1">
                  {selectedCompanyData.phases.map((phs, i) => (
                    <div key={i} className="relative">
                      <span className="absolute -left-[27px] top-0.5 h-4 w-4 bg-indigo-600 rounded-full text-[9px] text-white flex items-center justify-center font-bold">
                        {i + 1}
                      </span>
                      <div>
                        <h4 className="text-[11px] font-bold text-gray-800 dark:text-white">{phs.name}</h4>
                        <p className="text-[10px] text-gray-500 mt-0.5 leading-relaxed font-sans">{phs.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Right: What to Learn Ranked with Importance Checklist */}
            <div className="lg:col-span-7">
              <div className="bg-white dark:bg-gray-800 border border-gray-105 rounded-xl p-5 shadow-sm space-y-5">
                
                {/* Mastery meter header */}
                <div className="flex items-start justify-between gap-4 border-b pb-4 dark:border-gray-750">
                  <div className="space-y-1">
                    <span className="text-[9px] bg-indigo-50 dark:bg-indigo-950/30 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider">
                      Study Curriculum
                    </span>
                    <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
                      What to Learn (Ranked with Importance)
                    </h3>
                    <p className="text-xs text-gray-400 font-sans leading-normal">
                      Master these critical domains. Tick off topics to gauge your placement readiness dynamically.
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[9px] font-bold text-gray-400 block uppercase tracking-wider">Mastery Rate</span>
                    <span className="text-lg font-extrabold text-indigo-600 dark:text-indigo-400 font-mono">
                      {percentMastered}% Complete
                    </span>
                    <div className="w-24 bg-gray-100 dark:bg-gray-700 h-1.5 rounded-full overflow-hidden mt-1 self-end">
                      <div className="bg-indigo-650 bg-indigo-600 h-full transition-all duration-300" style={{ width: `${percentMastered}%` }}></div>
                    </div>
                  </div>
                </div>

                {/* Checklist loop of ranked topics */}
                <div className="space-y-4">
                  {selectedCompanyData.topics.map((tpc) => {
                    const isCompleted = companyTopics.includes(tpc.id);
                    return (
                      <div 
                        key={tpc.id}
                        className={`p-4 rounded-xl border transition-all duration-150 flex items-start space-x-3.5 cursor-pointer ${
                          isCompleted 
                            ? "bg-slate-50/50 dark:bg-gray-750/10 border-gray-150 dark:border-gray-750/80" 
                            : "bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-750/50 hover:border-indigo-200 hover:shadow-sm"
                        }`}
                        onClick={() => handleToggleTopic(selectedPrepCompany, tpc.id)}
                      >
                        {/* Interactive custom mock checkbox */}
                        <div className="mt-0.5 shrink-0 text-indigo-600 dark:text-indigo-400">
                          {isCompleted ? (
                            <CheckSquare className="h-5 w-5 text-indigo-600 dark:text-indigo-400 fill-indigo-50 dark:fill-indigo-950/20" />
                          ) : (
                            <Square className="h-5 w-5 text-gray-300 dark:text-gray-600" />
                          )}
                        </div>

                        {/* Title, description & badges */}
                        <div className="flex-1 space-y-1 text-xs">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className={`font-extrabold text-xs transition ${isCompleted ? "text-gray-400 line-through" : "text-gray-900 dark:text-white"}`}>
                              {tpc.title}
                            </span>

                            {/* Priority Rank Indicator Badge */}
                            <div className="flex items-center space-x-1.5">
                              {tpc.rank === "Critical" && (
                                <span className="bg-red-50 dark:bg-red-955/20 text-red-650 text-red-500 font-extrabold text-[9px] px-2 py-0.5 rounded uppercase tracking-wider border border-red-100 dark:border-red-950/30">
                                  Critical (Rank A)
                                </span>
                              )}
                              {tpc.rank === "High" && (
                                <span className="bg-amber-50 dark:bg-amber-950/25 text-amber-700 dark:text-amber-400 font-extrabold text-[9px] px-2 py-0.5 rounded uppercase tracking-wider border border-amber-200/40 dark:border-amber-950/30">
                                  High (Rank B)
                                </span>
                              )}
                              {tpc.rank === "Medium" && (
                                <span className="bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 font-extrabold text-[9px] px-2 py-0.5 rounded uppercase tracking-wider border border-indigo-100 dark:border-indigo-950/30">
                                  Standard (Rank C)
                                </span>
                              )}
                              
                              {/* Difficulty / Priority stars */}
                              <div className="flex items-center text-amber-400">
                                {Array.from({ length: tpc.stars }).map((_, i) => (
                                  <Star key={i} className="h-3 w-3 fill-amber-400 text-amber-400" />
                                ))}
                              </div>
                            </div>
                          </div>

                          <p className="text-[11px] text-gray-400 leading-normal font-sans">
                            {tpc.desc}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="bg-slate-50 dark:bg-gray-750/30 p-3 rounded-xl text-[10px] text-gray-400 font-sans leading-relaxed text-center">
                  💡 <strong>Pro-Tip:</strong> Complete all "Critical" Rank A items before scheduling your placement eligibility interviews. Topics are formulated specifically around recruiters' historical questioning boards.
                </div>

              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
