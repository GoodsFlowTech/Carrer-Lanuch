import React, { useState } from "react";
import { Search, MapPin, Laptop, Award, Calendar, Check, AlertTriangle, RefreshCw, Star } from "lucide-react";
import { Internship, Student } from "../types";

interface InternshipSectionProps {
  student: Student;
  internships: Internship[];
  onApplyIntern: (internId: string) => Promise<boolean>;
  onReload: () => void;
}

export function InternshipSection({ student, internships, onApplyIntern, onReload }: InternshipSectionProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState(""); // Remote, In-Office, Hybrid
  const [selectedIntern, setSelectedIntern] = useState<Internship | null>(internships[0] || null);

  const [submitting, setSubmitting] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);

  const filtered = internships.filter(i => {
    const matchesSearch = i.company.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          i.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          i.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === "" || i.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const handleApply = async (internId: string) => {
    setSubmitting(internId);
    setErrorText(null);
    try {
      const res = await fetch(`/api/internships/${internId}/apply`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${student.id}`
        }
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorText(data.error || "Failed to finalize internship application.");
      } else {
        onReload();
        // Update local state instance
        if (selectedIntern && selectedIntern.id === internId) {
          setSelectedIntern({ ...selectedIntern, applied: true });
        }
      }
    } catch (e) {
      setErrorText("Database server timed out during registration submission.");
    } finally {
      setSubmitting(null);
    }
  };

  return (
    <div className="space-y-6" id="internships_section_view">
      {/* Filtering row */}
      <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 p-5 rounded-xl shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
              <Laptop className="h-5 w-5 text-indigo-600" />
              <span>Internship Drives Hub</span>
            </h2>
            <p className="text-xs text-gray-400">Exclusive Remote, In-office, and Hybrid paid student contracts</p>
          </div>
          <div>
            <button
              onClick={() => { onReload(); setErrorText(null); }}
              className="p-1.5 hover:bg-gray-50 border rounded-lg dark:hover:bg-gray-750 text-gray-500"
              title="Refresh lists"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4.5 w-4.5 text-gray-400" />
            <input
              id="intern_search_input"
              type="text"
              placeholder="Search internship companies, tags, techs..."
              className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 pl-9 pr-4 py-2 rounded-xl text-sm leading-tight focus:ring-2 focus:ring-indigo-500 text-gray-900 dark:text-white"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>

          <select
            id="intern_type_select"
            className="bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 px-3 py-2 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 text-gray-900 dark:text-white"
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
          >
            <option value="">All Formats (Remote / In-Office)</option>
            <option value="Remote">Remote (Work from Home)</option>
            <option value="In-Office">In-Office</option>
            <option value="Hybrid">Hybrid Models</option>
          </select>
        </div>
      </div>

      {/* Main Splits Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Internship cards */}
        <div className="lg:col-span-5 space-y-3">
          {filtered.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-gray-800 border rounded-xl">
              <Laptop className="h-10 w-10 text-gray-300 mx-auto" />
              <p className="text-sm text-gray-500 mt-2">No active internship opportunities matched your terms.</p>
            </div>
          ) : (
            filtered.map(intern => {
              const eligible = student.cgpa >= intern.eligibilityCgpa;
              const isSelected = selectedIntern?.id === intern.id;

              return (
                <div
                  key={intern.id}
                  onClick={() => { setSelectedIntern(intern); setErrorText(null); }}
                  className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between space-y-3 relative ${
                    isSelected
                      ? "bg-indigo-50/40 dark:bg-indigo-950/20 border-indigo-300 dark:border-indigo-950"
                      : "bg-white dark:bg-gray-800 border-gray-100 dark:border-gray-700 hover:shadow-sm"
                  }`}
                >
                  <div className="flex space-x-3">
                    <img
                      src={intern.logoUrl || "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=100&h=100&fit=crop&q=80"}
                      className="h-10 w-10 rounded-lg object-cover bg-gray-50 border border-gray-100"
                      alt={intern.company}
                    />
                    <div>
                      <h4 className="font-bold text-gray-950 dark:text-white text-sm leading-tight">{intern.role}</h4>
                      <p className="text-xs text-gray-500">{intern.company} • {intern.location}</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5 text-[9px] font-mono">
                    <span className="bg-emerald-50 dark:bg-emerald-950/25 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded-full font-bold">
                      {intern.stipend}
                    </span>
                    <span className="bg-amber-50 dark:bg-amber-950/20 text-amber-600 px-2 py-0.5 rounded-full">
                      {intern.duration} ({intern.type})
                    </span>
                    {intern.applied ? (
                      <span className="bg-emerald-500 text-white font-semibold tracking-wide px-2 py-0.5 rounded-full">
                        APPLIED
                      </span>
                    ) : eligible ? (
                      <span className="bg-indigo-50 dark:bg-indigo-950/20 text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full font-semibold">
                        CGPA ok
                      </span>
                    ) : (
                      <span className="bg-red-50 dark:bg-red-950/20 text-red-600 px-2 py-0.5 rounded-full font-bold">
                        CGPA &lt; {intern.eligibilityCgpa}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Active Intern Details */}
        <div className="lg:col-span-7">
          {selectedIntern ? (
            <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-6 shadow-sm space-y-6">
              {errorText && (
                <div className="p-4 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-xl text-xs flex items-start space-x-2">
                  <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{errorText}</span>
                </div>
              )}

              {/* Company banner area */}
              <div className="flex justify-between items-start gap-4">
                <div className="flex space-x-4">
                  <img
                    src={selectedIntern.logoUrl || "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=100&h=100&fit=crop&q=80"}
                    className="h-14 w-14 rounded-xl object-cover bg-gray-50 border shadow-sm"
                    alt={selectedIntern.company}
                  />
                  <div className="space-y-1">
                    <h3 className="font-extrabold text-gray-950 dark:text-white text-lg tracking-tight leading-tight">{selectedIntern.role}</h3>
                    <p className="text-sm text-gray-500 font-sans">{selectedIntern.company} • {selectedIntern.location}</p>
                    <div className="flex items-center space-x-4 text-xs font-mono text-gray-400 pt-1">
                      <span className="bg-emerald-50 dark:bg-emerald-950/25 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold">
                        {selectedIntern.stipend}
                      </span>
                      <span>Contract Duration: {selectedIntern.duration} • {selectedIntern.type}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-end space-y-2">
                  <button
                    id={`apply_intern_btn_${selectedIntern.id}`}
                    onClick={() => handleApply(selectedIntern.id)}
                    disabled={selectedIntern.applied || submitting === selectedIntern.id}
                    className={`px-5 py-2 rounded-xl text-xs font-bold shadow-sm transition ${
                      selectedIntern.applied
                        ? "bg-slate-100 dark:bg-gray-750 text-gray-400 cursor-not-allowed"
                        : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/10"
                    }`}
                  >
                    {submitting === selectedIntern.id ? "Applying..." : selectedIntern.applied ? "Applied" : "Apply Internship"}
                  </button>
                  <p className="text-[10px] text-gray-400 font-mono">Ends {selectedIntern.deadline}</p>
                </div>
              </div>

              <hr className="border-gray-100 dark:border-gray-750" />

              {/* Eligibility stats */}
              <div className="grid grid-cols-2 gap-4 bg-gray-50 dark:bg-gray-750/50 rounded-xl p-4 text-xs">
                <div>
                  <span className="text-gray-400 font-mono block">Required Eligibility threshold</span>
                  <span className="font-bold text-gray-800 dark:text-white font-mono text-sm">
                    {selectedIntern.eligibilityCgpa || 6.0} CGPA Minimal
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 font-mono block">Your Active GPA</span>
                  <span className={`font-extrabold font-mono text-sm ${student.cgpa >= selectedIntern.eligibilityCgpa ? "text-emerald-500" : "text-red-500"}`}>
                    {student.cgpa || 0} CGPA
                  </span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 dark:text-white text-sm">Opportunity Summary</h4>
                <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed font-sans">
                  {selectedIntern.description}
                </p>
              </div>

              {/* Requirements */}
              <div className="space-y-2">
                <h4 className="font-bold text-gray-900 dark:text-white text-sm">Key Qualifications</h4>
                <ul className="list-disc list-inside text-xs text-gray-600 dark:text-gray-300 leading-relaxed space-y-1 pl-1 font-sans">
                  {selectedIntern.requirements?.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>

            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 border p-12 text-center rounded-xl">
              <Laptop className="h-12 w-12 text-gray-350 mx-auto" />
              <p className="text-sm text-gray-500 mt-2 font-sans">Select any internship on the left to inspect guidelines</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
