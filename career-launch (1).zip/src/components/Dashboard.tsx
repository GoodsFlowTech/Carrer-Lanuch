import React from "react";
import { Sparkles, Calendar, Award, BookOpen, Briefcase, ChevronRight, CheckCircle, Bell, ArrowUpRight } from "lucide-react";
import { Student, Job, Internship, Notification, PreparationTopic } from "../types";

interface DashboardProps {
  student: Student;
  jobs: Job[];
  internships: Internship[];
  notifications: Notification[];
  topics: PreparationTopic[];
  onNavigate: (tab: string) => void;
}

export function Dashboard({ student, jobs, internships, notifications, topics, onNavigate }: DashboardProps) {
  // Compute progress statistics
  const completedTopicsCount = Object.keys(student.progress || {}).filter(key => student.progress?.[key]).length;
  const totalTopicsCount = topics.length || 4; // fallback static count to prevent division by zero
  const prepPercentage = Math.round((completedTopicsCount / totalTopicsCount) * 100) || 0;

  // Active drives & internships
  const activeJobs = jobs.filter(j => new Date(j.deadline) > new Date()).slice(0, 3);
  const activeInterns = internships.filter(i => new Date(i.deadline) > new Date()).slice(0, 3);

  // Filter urgent notifications
  const urgentNotifications = notifications.filter(n => n.important);
  const regularNotifications = notifications.filter(n => !n.important).slice(0, 3);

  return (
    <div className="space-y-6" id="dashboard_panel">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-2xl p-6 md:p-8 relative overflow-hidden shadow-lg shadow-indigo-900/10 border border-indigo-950">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none p-4 select-none">
          <Sparkles className="h-44 w-44 text-indigo-400 rotate-12" />
        </div>
        <div className="z-10 relative space-y-3 max-w-2xl">
          <div className="inline-flex items-center space-x-2 bg-indigo-500/20 px-3 py-1 rounded-full border border-indigo-500/30 text-indigo-300 text-xs font-mono">
            <Sparkles className="h-3 w-3" />
            <span>AI Career Assistant Active</span>
          </div>
          <h2 className="text-3xl font-bold tracking-tight font-sans">
            Welcome back, {student.name}!
          </h2>
          <p className="text-indigo-200 text-sm leading-relaxed">
            Welcome to your placement workspace. You have completed <span className="font-semibold text-white font-mono">{completedTopicsCount}</span> prep modules. Expand your skills, analyze your resume, and qualify for upcoming opportunities!
          </p>
          <div className="pt-2 flex flex-wrap gap-3">
            <button
              id="dash_nav_resume"
              onClick={() => onNavigate("Resume Builder")}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium px-4  rounded-lg shadow transition"
            >
              Analyze Your Resume
            </button>
            <button
              id="dash_nav_prep"
              onClick={() => onNavigate("Placement Preparation")}
              className="bg-white/10 hover:bg-white/15 text-white border border-white/20 text-xs font-medium px-4  rounded-lg transition"
            >
              Start Prep Quiz
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Metric 1: Prep Progress */}
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider font-sans">Prep Completed</span>
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/30 rounded-lg text-emerald-600 dark:text-emerald-400">
              <CheckCircle className="h-5 w-5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-bold text-gray-900 dark:text-white font-mono">{prepPercentage}%</span>
              <span className="text-xs text-gray-500 font-mono">({completedTopicsCount}/{totalTopicsCount})</span>
            </div>
            {/* Range Line */}
            <div className="w-full bg-gray-100 dark:bg-gray-750 rounded-full h-1.5 mt-2">
              <div
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${prepPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Metric 2: Profile Rating */}
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider font-sans">Profile Integrity</span>
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/30 rounded-lg text-indigo-600 dark:text-indigo-400">
              <Award className="h-5 w-5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-bold text-gray-900 dark:text-white font-mono">{student.profileCompleted}%</span>
              <span className="text-xs text-gray-500">Rating</span>
            </div>
            {/* Range Line */}
            <div className="w-full bg-gray-100 dark:bg-gray-750 rounded-full h-1.5 mt-2">
              <div
                className="bg-indigo-600 h-1.5 rounded-full transition-all duration-500"
                style={{ width: `${student.profileCompleted}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Metric 3: Active Drives */}
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider font-sans">Active Drives</span>
            <div className="p-2 bg-sky-50 dark:bg-sky-950/30 rounded-lg text-sky-600 dark:text-sky-400">
              <Briefcase className="h-5 w-5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-bold text-gray-900 dark:text-white font-mono">{jobs.length}</span>
              <span className="text-xs text-slate-500 font-mono">Employers</span>
            </div>
            <p className="text-xs text-gray-400 font-sans mt-2">
              {jobs.filter(j => student.jobApplications?.includes(j.id)).length} Applications Submitted
            </p>
          </div>
        </div>

        {/* Metric 4: Target Internships */}
        <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider font-sans">Total Interns</span>
            <div className="p-2 bg-amber-50 dark:bg-amber-950/30 rounded-lg text-amber-600 dark:text-amber-400">
              <BookOpen className="h-5 w-5" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-bold text-gray-900 dark:text-white font-mono">{internships.length}</span>
              <span className="text-xs text-slate-500">Live Contracts</span>
            </div>
            <p className="text-xs text-gray-400 font-sans mt-2">
              Including remote and paid opportunities
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Drives Feed */}
        <div className="lg:col-span-2 space-y-6">
          {/* Section: Placement Drives list */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-50 dark:border-gray-750">
              <div className="flex items-center space-x-2">
                <Briefcase className="h-5 w-5 text-indigo-600" />
                <h3 className="font-semibold text-gray-900 dark:text-white text-base">Immediate Placement Drives</h3>
              </div>
              <button
                id="dash_all_jobs_btn"
                onClick={() => onNavigate("Jobs")}
                className="text-xs text-indigo-600 hover:underline font-medium inline-flex items-center space-x-1"
              >
                <span>View All Jobs</span>
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            <div className="space-y-3">
              {activeJobs.map(job => (
                <div
                  key={job.id}
                  className="p-3 border border-gray-50 dark:border-gray-750 hover:bg-gray-50 dark:hover:bg-gray-750/70 rounded-xl transition flex items-start justify-between"
                >
                  <div className="flex space-x-3">
                    <img
                      src={job.logoUrl || "https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=100&h=100&fit=crop&q=80"}
                      className="h-10 w-10 rounded-lg object-cover bg-gray-50 dark:bg-gray-700 border border-gray-100"
                      alt={job.company}
                    />
                    <div>
                      <h4 className="font-semibold text-gray-950 dark:text-white text-sm leading-tight">{job.role}</h4>
                      <p className="text-xs text-gray-500 font-sans mt-0.5">{job.company} • {job.location}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="text-[10px] bg-slate-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-full font-mono font-bold">
                          {job.salary}
                        </span>
                        <span className="text-[10px] bg-red-50 dark:bg-red-950/30 text-red-600 px-2 py-0.5 rounded-full font-mono">
                          Ends {job.deadline}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <button
                      id={`dash_apply_job_${job.id}`}
                      onClick={() => onNavigate("Jobs")}
                      className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 dark:hover:bg-indigo-950 px-3 py-1.5 rounded-lg transition"
                    >
                      Apply Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Internships Drives */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-50 dark:border-gray-750">
              <div className="flex items-center space-x-2">
                <BookOpen className="h-5 w-5 text-indigo-600" />
                <h3 className="font-semibold text-gray-900 dark:text-white text-base">Key Academic Internships</h3>
              </div>
              <button
                id="dash_all_interns_btn"
                onClick={() => onNavigate("Internships")}
                className="text-xs text-indigo-600 hover:underline font-medium inline-flex items-center space-x-1"
              >
                <span>View All Internships</span>
                <ChevronRight className="h-3 w-3" />
              </button>
            </div>

            <div className="space-y-3">
              {activeInterns.map(intern => (
                <div
                  key={intern.id}
                  className="p-3 border border-gray-50 dark:border-gray-750 hover:bg-gray-50 dark:hover:bg-gray-750/70 rounded-xl transition flex items-start justify-between"
                >
                  <div className="flex space-x-3">
                    <img
                      src={intern.logoUrl || "https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=100&h=100&fit=crop&q=80"}
                      className="h-10 w-10 rounded-lg object-cover bg-gray-50 dark:bg-gray-700 border border-gray-100"
                      alt={intern.company}
                    />
                    <div>
                      <h4 className="font-semibold text-gray-950 dark:text-white text-sm leading-tight">{intern.role}</h4>
                      <p className="text-xs text-gray-500 font-sans mt-0.5">{intern.company} • {intern.location}</p>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="text-[10px] bg-slate-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded-full font-mono font-bold">
                          {intern.stipend}
                        </span>
                        <span className="text-[10px] bg-amber-50 dark:bg-amber-950/20 text-amber-600 px-2 py-0.5 rounded-full">
                          {intern.duration} ({intern.type})
                        </span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <button
                      id={`dash_apply_intern_${intern.id}`}
                      onClick={() => onNavigate("Internships")}
                      className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition"
                    >
                      Select
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Notifications Feed */}
        <div className="space-y-6">
          {/* Section: Real Urgent Alert Feed */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-gray-50 dark:border-gray-750">
              <div className="flex items-center space-x-2">
                <Bell className="h-5 w-5 text-indigo-600" />
                <h3 className="font-semibold text-gray-900 dark:text-white text-base">Alerts & Announcements</h3>
              </div>
            </div>

            <div className="space-y-3">
              {urgentNotifications.map(not => (
                <div
                  key={not.id}
                  className="p-3 bg-red-50/50 dark:bg-red-950/10 border border-red-100 dark:border-red-900/30 rounded-xl relative space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] bg-red-500 text-white font-semibold font-mono tracking-wider px-2 py-0.5 rounded-full">
                      CRITICAL DRIVE
                    </span>
                    <span className="text-[10px] text-gray-400 font-mono">{not.date}</span>
                  </div>
                  <h4 className="font-semibold text-red-950 dark:text-red-400 text-xs leading-snug">{not.title}</h4>
                  <p className="text-[11px] text-gray-600 dark:text-gray-300 leading-normal">{not.content}</p>
                </div>
              ))}

              {regularNotifications.map(not => (
                <div
                  key={not.id}
                  className="p-3 border border-gray-50 dark:border-gray-750  hover:bg-gray-50 dark:hover:bg-gray-750/50 rounded-xl space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 px-2,5 py-0.5 rounded-full capitalize font-mono">
                      {not.category}
                    </span>
                    <span className="text-[9px] text-gray-400 font-mono">{not.date}</span>
                  </div>
                  <h4 className="font-semibold text-gray-900 dark:text-white text-xs leading-snug">{not.title}</h4>
                  <p className="text-[11px] text-gray-500 dark:text-gray-300 leading-normal">{not.content}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Ready Checklist */}
          <div className="bg-gradient-to-br from-indigo-50 to-indigo-100/50 dark:from-slate-800 dark:to-slate-800/80 border border-indigo-100/80 dark:border-slate-700 rounded-xl p-5 shadow-sm space-y-3">
            <h4 className="font-bold text-gray-900 dark:text-white text-sm font-sans flex items-center space-x-1.5">
              <span>Your Placement Checklists</span>
            </h4>
            <ul className="text-xs space-y-2.5 text-gray-600 dark:text-gray-300 font-sans">
              <li className="flex items-start space-x-2">
                <CheckCircle className={`h-4 w-4 shrink-0 mt-0.5 ${student.cgpa > 0 ? "text-emerald-500" : "text-gray-300"}`} />
                <span>Validate CGPA Eligibility ({student.cgpa || "Pending"})</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle className={`h-4 w-4 shrink-0 mt-0.5 ${student.resume?.summary ? "text-emerald-500" : "text-gray-300"}`} />
                <span>Build & Upload Resume PDF</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle className={`h-4 w-4 shrink-0 mt-0.5 ${prepPercentage > 30 ? "text-emerald-500" : "text-gray-300"}`} />
                <span>Complete the first 3 Aptitude / Technical Roadmaps</span>
              </li>
              <li className="flex items-start space-x-2">
                <CheckCircle className={`h-4 w-4 shrink-0 mt-0.5 ${Object.keys(student.quizScores || {}).length > 0 ? "text-emerald-500" : "text-gray-300"}`} />
                <span>Complete Aptitude Mock Test 1</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
