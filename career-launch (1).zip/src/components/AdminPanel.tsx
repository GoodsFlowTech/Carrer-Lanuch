import React, { useState, useEffect } from "react";
import { Sparkles, Users, Briefcase, Bell, Plus, Trash2, LineChart, CheckCircle2, ChevronRight, Laptop } from "lucide-react";
import { Student, Job, Internship, Notification } from "../types";

interface AdminPanelProps {
  students: Student[];
  jobs: Job[];
  internships: Internship[];
  notifications: Notification[];
  adminToken: string;
  onRefresh: () => void;
}

export function AdminPanel({ students, jobs, internships, notifications, adminToken, onRefresh }: AdminPanelProps) {
  // Post states
  const [jobTitle, setJobTitle] = useState("");
  const [jobCompany, setJobCompany] = useState("");
  const [jobSalary, setJobSalary] = useState("₹12 LPA");
  const [jobLoc, setJobLoc] = useState("Bangalore");
  const [jobCgpa, setJobCgpa] = useState("7.5");
  const [jobRequirements, setJobRequirements] = useState("React, Node.js, SQL, Java");
  const [jobDesc, setJobDesc] = useState("Responsible for writing clean Express APIs and high precision modular React containers.");

  // Internship states
  const [internTitle, setInternTitle] = useState("");
  const [internCompany, setInternCompany] = useState("");
  const [internStipend, setInternStipend] = useState("₹45,000 / month");
  const [internDuration, setInternDuration] = useState("3 Months");
  const [internType, setInternType] = useState("Remote");
  const [internCgpa, setInternCgpa] = useState("7.0");
  const [internRequirements, setInternRequirements] = useState("Python, Django, AWS, JavaScript");

  // Notification states
  const [notTitle, setNotTitle] = useState("");
  const [notContent, setNotContent] = useState("");
  const [notCat, setNotCat] = useState("Drive Alert");
  const [notUrgent, setNotUrgent] = useState(false);

  const [loading, setLoading] = useState(false);
  const [errorWord, setErrorWord] = useState<string | null>(null);
  const [successWord, setSuccessWord] = useState<string | null>(null);

  // Compute key stats for analytics
  const totalStudents = students.length || 1;
  const avgCgpaRaw = students.reduce((acc, current) => acc + (current.cgpa || 0), 0) / totalStudents;
  const avgCgpa = avgCgpaRaw ? avgCgpaRaw.toFixed(2) : "0.00";

  // Distribute department breakdowns
  const deptCountMap: Record<string, number> = {};
  students.forEach(s => {
    deptCountMap[s.department] = (deptCountMap[s.department] || 0) + 1;
  });

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorWord(null);
    setSuccessWord(null);
    if (!jobTitle || !jobCompany || !jobSalary) {
      setErrorWord("Please enter Job Title, Company, and CTC CTC parameters.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/admin/job", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          role: jobTitle,
          company: jobCompany,
          location: jobLoc,
          salary: jobSalary,
          eligibilityCgpa: parseFloat(jobCgpa) || 7.0,
          deadline: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
          description: jobDesc,
          requirements: jobRequirements.split(",").map(r => r.trim()).filter(Boolean)
        })
      });
      if (res.ok) {
        setSuccessWord("Completed recruitment process posting successfully!");
        setJobTitle("");
        setJobCompany("");
        onRefresh();
      } else {
        setErrorWord("Failed to create posting.");
      }
    } catch (err: any) {
      setErrorWord(err.message || "Failed post request");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateInternship = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorWord(null);
    setSuccessWord(null);
    if (!internTitle || !internCompany) {
      setErrorWord("Must specify Role title and Company.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/admin/internship", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          role: internTitle,
          company: internCompany,
          location: internType === "Remote" ? "Delhi (Remote)" : "Pune",
          stipend: internStipend,
          duration: internDuration,
          type: internType,
          eligibilityCgpa: parseFloat(internCgpa) || 6.5,
          deadline: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
          description: "Exclusive engineering design position mapped with internship projects.",
          requirements: internRequirements.split(",").map(r => r.trim()).filter(Boolean)
        })
      });
      if (res.ok) {
        setSuccessWord("New contract internship listed!");
        setInternTitle("");
        setInternCompany("");
        onRefresh();
      } else {
        setErrorWord("Failed to create intern posting.");
      }
    } catch (err: any) {
      setErrorWord(err.message || "Failed post");
    } finally {
      setLoading(false);
    }
  };

  const handleSendNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorWord(null);
    setSuccessWord(null);
    if (!notTitle || !notContent) {
      setErrorWord("Both Notification headline and content body are required.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/admin/notification", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken}`
        },
        body: JSON.stringify({
          title: notTitle,
          content: notContent,
          important: notUrgent,
          category: notCat,
          date: "Today"
        })
      });
      if (res.ok) {
        setSuccessWord("Broadcast alert issued cleanly to all student boards.");
        setNotTitle("");
        setNotContent("");
        onRefresh();
      } else {
        setErrorWord("Failed notification post.");
      }
    } catch (err) {
      setErrorWord("Failed push dispatch notification.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6" id="admin_control_hub">
      {/* Simulation status messages */}
      {errorWord && (
        <div className="p-3 bg-red-50 text-red-600 rounded-xl border border-red-200 text-xs">
          <span>{errorWord}</span>
        </div>
      )}
      {successWord && (
        <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl border border-emerald-200 text-xs text-center flex items-center justify-center space-x-1 font-bold">
          <CheckCircle2 className="h-4.5 w-4.5" />
          <span>{successWord}</span>
        </div>
      )}

      {/* Analytics widgets row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        
        <div className="bg-white dark:bg-gray-800 border p-5 rounded-xl shadow-sm text-center">
          <span className="text-gray-400 font-mono block text-[10px] uppercase tracking-wider font-semibold">Registered students</span>
          <span className="text-3xl font-extrabold text-indigo-600 font-mono">{students.length}</span>
          <p className="text-[10px] text-gray-500 font-sans mt-1">Verified with register IDs</p>
        </div>

        <div className="bg-white dark:bg-gray-800 border p-5 rounded-xl shadow-sm text-center">
          <span className="text-gray-400 font-mono block text-[10px] uppercase tracking-wider font-semibold">Average GPA metrics</span>
          <span className="text-3xl font-extrabold text-emerald-500 font-mono">{avgCgpa}</span>
          <p className="text-[10px] text-gray-500 font-sans mt-1">Acceptable recruiter criteria</p>
        </div>

        <div className="bg-white dark:bg-gray-800 border p-5 rounded-xl shadow-sm text-center">
          <span className="text-gray-400 font-mono block text-[10px] uppercase tracking-wider font-semibold">Active Drive Openings</span>
          <span className="text-3xl font-extrabold text-sky-500 font-mono">{jobs.length}</span>
          <p className="text-[10px] text-gray-500 font-sans mt-1">Full CTC opportunities</p>
        </div>

        <div className="bg-white dark:bg-gray-800 border p-5 rounded-xl shadow-sm text-center">
          <span className="text-gray-400 font-mono block text-[10px] uppercase tracking-wider font-semibold">Live Intern Contracts</span>
          <span className="text-3xl font-extrabold text-amber-500 font-mono">{internships.length}</span>
          <p className="text-[10px] text-gray-500 font-sans mt-1">Remote / Hybrid formats</p>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Management Inputs Forms */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Post New Job Card Form */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 pb-2 border-b">
              <Briefcase className="h-5 w-5 text-indigo-600" />
              <h3 className="font-extrabold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Publish Placement Drive</h3>
            </div>

            <form onSubmit={handleCreateJob} className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs" id="admin_job_form">
              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">DRIVE ROLE TITLE</label>
                <input
                  type="text"
                  placeholder="e.g. Associate Security Analyst"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white"
                  value={jobTitle}
                  onChange={e => setJobTitle(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">ORGANIZATION / COMPANY</label>
                <input
                  type="text"
                  placeholder="e.g. Oracle India"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white"
                  value={jobCompany}
                  onChange={e => setJobCompany(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">CTC SALARY PACKAGE</label>
                <input
                  type="text"
                  placeholder="e.g. ₹15 LPA"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white font-mono"
                  value={jobSalary}
                  onChange={e => setJobSalary(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">MINIMUM TARGET CGPA</label>
                <input
                  type="number"
                  step="0.05"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white font-mono"
                  value={jobCgpa}
                  onChange={e => setJobCgpa(e.target.value)}
                />
              </div>

              <div className="md:col-span-2">
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">CORE SKILLS EXPECTED (Comma Separated)</label>
                <input
                  type="text"
                  placeholder="React, CSS, SQL, Java"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white"
                  value={jobRequirements}
                  onChange={e => setJobRequirements(e.target.value)}
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="md:col-span-2 w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-400 font-bold text-white py-2 rounded-xl text-xs transition"
              >
                {loading ? "Publishing drive..." : "Publish Job Drive Opportunity"}
              </button>
            </form>
          </div>

          {/* Post New Internship Form */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 pb-2 border-b">
              <Laptop className="h-5 w-5 text-indigo-600" />
              <h3 className="font-extrabold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Publish Academic Internship</h3>
            </div>

            <form onSubmit={handleCreateInternship} className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs" id="admin_intern_form">
              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">INTERNSHIP ROLE TITLE</label>
                <input
                  type="text"
                  placeholder="Fullstack Intern"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white"
                  value={internTitle}
                  onChange={e => setInternTitle(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">COMPANY NAME</label>
                <input
                  type="text"
                  placeholder="Amazon DevOps"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white"
                  value={internCompany}
                  onChange={e => setInternCompany(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">STIPEND RATE</label>
                <input
                  type="text"
                  placeholder="₹35,000 / month"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900 dark:text-white font-mono"
                  value={internStipend}
                  onChange={e => setInternStipend(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">FORMAT FORMAT</label>
                <select
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-950 dark:text-white"
                  value={internType}
                  onChange={e => setInternType(e.target.value)}
                >
                  <option>Remote</option>
                  <option>In-Office</option>
                  <option>Hybrid</option>
                </select>
              </div>

              <button
                type="submit"
                className="md:col-span-2 w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 rounded-xl text-xs transition animate-pulse-slow"
              >
                Publish Internship Drive
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Students Ledger & Announcement feeds */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Dispatch Announcement */}
          <div className="bg-white dark:bg-gray-800 border border-gray-100 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 pb-2 border-b">
              <Bell className="h-5 w-5 text-indigo-600" />
              <h3 className="font-extrabold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Broadcast notification</h3>
            </div>

            <form onSubmit={handleSendNotification} className="space-y-3 text-xs" id="admin_notification_form">
              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">NOTIFY headline</label>
                <input
                  type="text"
                  placeholder="e.g. CGPA validation criteria revised..."
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900"
                  value={notTitle}
                  onChange={e => setNotTitle(e.target.value)}
                />
              </div>

              <div>
                <label className="font-bold text-gray-400 uppercase tracking-widest text-[9px] mb-1 block">ALERT CONTENT BODY</label>
                <textarea
                  rows={2}
                  placeholder="Ensure to confirm that your profile CGPA records match..."
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 focus:ring-1 focus:ring-indigo-500 rounded-lg text-gray-900"
                  value={notContent}
                  onChange={e => setNotContent(e.target.value)}
                />
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="urgent_alert_toggle"
                  checked={notUrgent}
                  onChange={() => setNotUrgent(!notUrgent)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                />
                <label htmlFor="urgent_alert_toggle" className="text-[10px] text-gray-500 font-semibold cursor-pointer">
                  Mark as URGENT (Critical drive flag)
                </label>
              </div>

              <button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2 rounded-xl font-sans transition"
              >
                Send Broadcast Message
              </button>
            </form>
          </div>

          {/* Enrolled Students Ledger List */}
          <div className="bg-white dark:bg-gray-800 border rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <h3 className="font-extrabold text-gray-950 dark:text-white text-sm uppercase tracking-wider flex items-center space-x-1.5">
                <Users className="h-5 w-5 text-indigo-600" />
                <span>Authorized Ledger list</span>
              </h3>
            </div>

            <div className="space-y-3 max-h-[40vh] overflow-y-auto custom-scrollbar">
              {students.map(std => (
                <div key={std.id} className="p-3 border rounded-xl bg-gray-50 dark:bg-gray-750/30 text-xs space-y-1">
                  <div className="flex justify-between font-bold">
                    <span className="text-gray-900 dark:text-white">{std.name}</span>
                    <span className="font-mono text-[10px] text-indigo-600 font-bold">{std.registerNo}</span>
                  </div>
                  <p className="text-[10px] text-gray-500">{std.department} • Year {std.graduationYear}</p>
                  <div className="flex items-center justify-between pt-1 border-t dark:border-gray-700/60 font-mono text-[9px] text-gray-400">
                    <span>Performance: <strong className="text-emerald-500 font-bold">{std.cgpa} CGPA</strong></span>
                    <span>Profile completed: {std.profileCompleted}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
