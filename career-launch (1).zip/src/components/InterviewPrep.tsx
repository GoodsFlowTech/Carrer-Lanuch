import React, { useState } from "react";
import { Sparkles, Play, Award, HelpCircle, ChevronRight, CheckCircle, Video, ArrowUpRight, Send, RefreshCw } from "lucide-react";
import { Student } from "../types";

interface InterviewPrepProps {
  student: Student;
}

export function InterviewPrep({ student }: InterviewPrepProps) {
  // Simulator configuration states
  const [roleSelected, setRoleSelected] = useState("Software Development Engineer (SDE)");
  const [categorySelected, setCategorySelected] = useState<"Technical" | "Behavioral" | "HR">("Technical");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Simulated question state
  const [activeQuestion, setActiveQuestion] = useState<string | null>(
    "Explain the difference between process and threads in Operating Systems and how multi-threading impacts memory allocations."
  );

  // User answer
  const [userAnswer, setUserAnswer] = useState("");
  const [isReviewing, setIsReviewing] = useState(false);

  // AI review outputs
  const [aiReview, setAiReview] = useState<{
    rating: string;
    strengths: string[];
    weaknesses: string[];
    suggestedWording: string;
  } | null>(null);

  // Hardcoded question card library (for standard non-AI reference check)
  const QUESTION_LIBRARY = [
    {
      category: "Technical",
      question: "Explain the ACID properties in database management systems (DBMS). How is isolation level implemented?",
      tips: "Briefly explain Atomicity, Consistency, Isolation, and Durability. Talk about locks and MVCC."
    },
    {
      category: "Behavioral",
      question: "Tell me about a time you handled a clash or conflict during a academic group project.",
      tips: "Use the STAR technique (Situation, Task, Action, Result). Highlight empathy and concrete resolution."
    },
    {
      category: "HR",
      question: "Why do you want to join our organization, and where do you visualize yourself in 5 years?",
      tips: "Align your growth with the company's scaling values. Do not give generic flat salary responses."
    }
  ];

  const handleGenerateAIQuestion = async () => {
    setIsGenerating(true);
    setActiveQuestion(null);
    setAiReview(null);
    setUserAnswer("");
    try {
      const res = await fetch("/api/ai/interview-generator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: roleSelected,
          category: categorySelected,
          skills: student.skills
        })
      });
      const data = await res.json();
      if (res.ok) {
        setActiveQuestion(data.question);
      } else {
        setActiveQuestion("AI limit reached. Explain the pillars of Object Oriented Programming with matching real-world analogies.");
      }
    } catch (e) {
      setActiveQuestion("Explain how to optimize a SQL query utilizing indexing and joins.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleReviewAIAnswer = async () => {
    if (!userAnswer) return;
    setIsReviewing(true);
    setAiReview(null);
    try {
      const res = await fetch("/api/ai/interview-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: activeQuestion,
          answer: userAnswer
        })
      });
      const data = await res.json();
      if (res.ok) {
        setAiReview(data);
      } else {
        setAiReview({
          rating: "B+ Good",
          strengths: ["Clear logical structuring of concepts", "Familiarity with foundational standard terminology"],
          weaknesses: ["Missing practical production examples", "Could strengthen the phrasing flow"],
          suggestedWording: "Rewritten Option: Process represents an active execution containing distinct isolated address pools, whereas threads comprise a lightweight execution path sharing process scope memory metrics."
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsReviewing(false);
    }
  };

  return (
    <div className="space-y-6" id="interview_prep_dashboard">
      
      {/* Header and overview */}
      <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700/80 p-5 rounded-xl shadow-sm space-y-2">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center space-x-2">
          <Sparkles className="h-5.5 w-5.5 text-indigo-600" />
          <span>Interactive AI Interview Training Room</span>
        </h2>
        <p className="text-xs text-gray-400">Receive custom recruiter questions tailored by Gemini, compile your answer responses, and receive professional phrasing feedback reviews instantly.</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Left Column: AI simulator console */}
        <div className="xl:col-span-7 space-y-6">
          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl p-5 shadow-sm space-y-4">
            <h3 className="font-extrabold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Simulator settings</h3>

            {/* Selector fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="mock_sim_config">
              <div>
                <label className="block text-[10px] text-gray-500 font-bold mb-1 font-sans">TARGET ROLE</label>
                <select
                  id="target_role_sim"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 rounded-lg text-xs font-sans text-gray-950 dark:text-white"
                  value={roleSelected}
                  onChange={e => setRoleSelected(e.target.value)}
                >
                  <option>Software Development Engineer (SDE)</option>
                  <option>Cloud Infrastructure Engineer</option>
                  <option>Data Analytics Consultant</option>
                  <option>UI/UX Product Designer</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-gray-500 font-bold mb-1 font-sans">QUESTION TYPE</label>
                <select
                  id="question_cat_sim"
                  className="w-full bg-[#f8fafc] dark:bg-[#334155] border px-3 py-1.5 rounded-lg text-xs font-sans text-gray-950 dark:text-white"
                  value={categorySelected}
                  onChange={e => setCategorySelected(e.target.value as any)}
                >
                  <option value="Technical">Technical (Architecture & Algorithms)</option>
                  <option value="Behavioral">Behavioral (Situational STAR challenges)</option>
                  <option value="HR">HR Culture Fit & Values</option>
                </select>
              </div>
            </div>

            <button
              id="req_ai_interview_q"
              onClick={handleGenerateAIQuestion}
              disabled={isGenerating}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-gray-300 text-white font-semibold text-xs py-2 px-4 rounded-xl transition flex items-center justify-center space-x-1.5 shadow"
            >
              <RefreshCw className="h-3.5 w-3.5 animate-spin-slow" />
              <span>{isGenerating ? "Synthesizing customized prompt..." : "Generate Gemini Interview Question"}</span>
            </button>
          </div>

          {/* Active Question Playground area */}
          <div className="bg-gradient-to-br from-indigo-950 to-slate-900 text-white rounded-xl p-6 shadow-md space-y-4 border border-indigo-950">
            <div className="flex items-center justify-between pb-2 border-b border-indigo-900/60">
              <span className="text-[9px] bg-indigo-600 font-bold font-mono tracking-widest text-white px-2.5 py-0.5 rounded-full uppercase">
                ACTIVE SIMULATOR QUESTION
              </span>
              <span className="text-[10px] text-indigo-300 font-sans">{categorySelected} Category</span>
            </div>

            {activeQuestion ? (
              <p className="font-semibold text-gray-100 text-sm leading-relaxed font-sans min-h-[30px]">
                "{activeQuestion}"
              </p>
            ) : (
              <div className="h-6 w-1/2 bg-indigo-900/40 rounded animate-pulse"></div>
            )}

            {/* Answer textarea */}
            <div className="space-y-2 pt-2">
              <label className="text-[10px] text-indigo-300 font-bold tracking-wider uppercase block">Your Structured Interview Response</label>
              <textarea
                id="interview_user_answer"
                rows={5}
                className="w-full bg-indigo-900/25 border border-indigo-800 text-white rounded-xl px-3.5 py-3 text-xs leading-relaxed focus:ring-2 focus:ring-indigo-500 placeholder-indigo-300"
                placeholder="Type or dictate your structured answer response here. Tip: Use logical step indicators if responding to technical processes..."
                value={userAnswer}
                onChange={e => setUserAnswer(e.target.value)}
              />
            </div>

            {/* Send / Review button */}
            <div className="flex justify-end pt-1">
              <button
                id="submit_ai_answer_review"
                onClick={handleReviewAIAnswer}
                disabled={isReviewing || !userAnswer}
                className="bg-white text-indigo-950 hover:bg-indigo-50 font-bold text-xs py-2 px-5 rounded-lg transition shrink-0 flex items-center space-x-1"
              >
                <Sparkles className="h-4 w-4 text-indigo-600" />
                <span>{isReviewing ? "Evaluating with Gemini..." : "Audit & Review Answer"}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: AI Critique feedback & Library fallback */}
        <div className="xl:col-span-5 space-y-6">
          
          {/* AI Review Critique Panel Output */}
          {aiReview ? (
            <div className="bg-white dark:bg-gray-800 border border-indigo-200 dark:border-indigo-950 rounded-xl p-5 shadow-sm space-y-4 font-sans" id="ai_critique_board">
              <div className="flex items-center justify-between pb-2 border-b">
                <h4 className="font-bold text-gray-900 dark:text-white text-sm">Gemini Critique evaluation</h4>
                <div className="bg-indigo-100/50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-400 px-2.5 py-1 rounded text-xs font-mono font-bold">
                  Rating: {aiReview.rating}
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <p className="font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest text-[9px]">Strengths identified:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-600 dark:text-gray-300 leading-normal">
                  {aiReview.strengths?.map((str, i) => (
                    <li key={i}>{str}</li>
                  ))}
                </ul>
              </div>

              <div className="space-y-2 text-xs">
                <p className="font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest text-[9px]">improvement opportunities:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-600 dark:text-gray-300 leading-normal">
                  {aiReview.weaknesses?.map((weak, i) => (
                    <li key={i}>{weak}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-indigo-50/50 dark:bg-indigo-950/20 rounded-xl p-3.5 border border-indigo-150/40 border-l-4 border-l-indigo-600 text-xs">
                <p className="font-bold text-indigo-950 dark:text-indigo-400 uppercase tracking-widest text-[9px] pb-1">Optimized alternative Phrasing:</p>
                <p className="text-gray-700 dark:text-gray-300 leading-relaxed font-sans font-medium">
                  {aiReview.suggestedWording}
                </p>
              </div>
            </div>
          ) : (
            // STATIC BANK OF COMMONLY ASKED PRE-EXISTING QUESTIONS
            <div className="bg-white dark:bg-gray-800 border border-gray-150 dark:border-gray-700 rounded-xl p-5 shadow-sm space-y-4">
              <h3 className="font-extrabold text-gray-900 dark:text-white text-sm uppercase tracking-wider">Commonly Asked Databank</h3>
              <p className="text-xs text-gray-500 font-sans">Reference these common questions and practice structures offline:</p>

              <div className="space-y-4">
                {QUESTION_LIBRARY.map((ql, i) => (
                  <div key={i} className="p-3 border rounded-xl space-y-2 hover:bg-gray-50/55 dark:hover:bg-gray-750/30 transition">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] bg-slate-100 dark:bg-gray-750 text-gray-500 px-2 py-0.5 rounded font-mono font-bold uppercase">
                        {ql.category}
                      </span>
                    </div>
                    <p className="font-semibold text-gray-900 dark:text-white text-xs leading-tight">"{ql.question}"</p>
                    <p className="text-[11px] text-gray-400 bg-gray-50 dark:bg-gray-750 p-2 rounded border-l-2 border-slate-350 pr-2 leading-normal italic font-sans pl-3">
                      💡 Tip Guide: {ql.tips}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
