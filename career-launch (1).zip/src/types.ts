export interface Student {
  id: string;
  registerNo: string;
  name: string;
  email: string;
  department: string;
  cgpa: number;
  skills: string[];
  graduationYear: number;
  profileCompleted: number; // percentage
  resume?: ResumeData;
  jobApplications?: string[]; // jobIds
  internshipApplications?: string[]; // internshipIds
  savedJobs?: string[]; // jobIds
  progress?: Record<string, boolean>; // topicId -> completed
  quizScores?: Record<string, { score: number; total: number; date: string }>;
  role?: 'student' | 'admin';
}

export interface EducationItem {
  id: string;
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startYear: string;
  endYear: string;
  grade: string;
}

export interface ExperienceItem {
  id: string;
  company: string;
  role: string;
  startDate: string;
  endDate: string;
  description: string;
  location: string;
  isRemote: boolean;
}

export interface ProjectItem {
  id: string;
  title: string;
  description: string;
  technologies: string[];
  link?: string;
}

export interface ResumeData {
  title: string;
  name: string;
  email: string;
  phone: string;
  github?: string;
  linkedin?: string;
  location: string;
  summary: string;
  education: EducationItem[];
  experience: ExperienceItem[];
  projects: ProjectItem[];
  skills: string[];
  certifications: string[];
}

export interface Job {
  id: string;
  company: string;
  logoUrl?: string;
  role: string;
  location: string;
  type: string; // 'Full-time' | 'Contract' | etc.
  salary: string;
  deadline: string;
  description: string;
  requirements: string[];
  eligibilityCgpa: number;
  applied?: boolean;
  saved?: boolean;
}

export interface Internship {
  id: string;
  company: string;
  logoUrl?: string;
  role: string;
  location: string;
  duration: string;
  stipend: string;
  type: string; // 'Remote' | 'In-Office' | 'Hybrid'
  deadline: string;
  description: string;
  requirements: string[];
  eligibilityCgpa: number;
  applied?: boolean;
  saved?: boolean;
}

export interface Notification {
  id: string;
  title: string;
  content: string;
  date: string;
  category: 'placement' | 'internship' | 'system' | 'mock-test';
  important: boolean;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctOptionIndex: number;
  explanation: string;
}

export interface MockTest {
  id: string;
  title: string;
  category: 'Aptitude' | 'Technical' | 'Mixed' | 'Company-Specific';
  durationMinutes: number;
  questions: Question[];
}

export interface PreparationTopic {
  id: string;
  title: string;
  category: 'Aptitude' | 'Reasoning' | 'Verbal' | 'Technical';
  subCategory?: string; // e.g. DSA, DBMS, OOPS, OS, CN
  theory: string;
  notes: string[];
  videoLinks: { title: string; url: string }[];
  practiceQuestions: { question: string; answer: string; hint?: string }[];
  quiz: Question[];
}
